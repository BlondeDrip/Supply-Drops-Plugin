package me.atilt.supplydrops.api.model;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/Interaction.class */
public interface Interaction<T, U> extends BiConsumer<T, U>, BiFunction<T, U, Boolean> {
}

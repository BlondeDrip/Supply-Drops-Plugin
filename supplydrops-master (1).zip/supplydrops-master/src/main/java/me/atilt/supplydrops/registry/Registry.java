package me.atilt.supplydrops.registry;

import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/registry/Registry.class */
public interface Registry<K, V> extends Iterable<Map.Entry<K, V>>, AutoCloseable {
    @Nullable
    V register(@Nonnull K k, @Nonnull V v);

    void register(@Nonnull Map<? extends K, ? extends V> map);

    @Nullable
    V unregister(@Nonnull K k);

    @Nullable
    V get(@Nonnull K k);

    @Nonnull
    V getOrDefault(@Nonnull K k, @Nonnull V v);

    int size();

    @Nonnull
    Map<K, V> all();
}

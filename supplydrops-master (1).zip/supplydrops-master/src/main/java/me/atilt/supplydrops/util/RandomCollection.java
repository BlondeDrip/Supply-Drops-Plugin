package me.atilt.supplydrops.util;

import java.util.NavigableMap;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.ThreadLocalRandom;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/RandomCollection.class */
public class RandomCollection<E> {
    private final NavigableMap<Double, E> map;
    private final Random random;
    private double total;

    public RandomCollection() {
        this(ThreadLocalRandom.current());
    }

    public RandomCollection(Random random) {
        this.map = new TreeMap();
        this.total = 0.0d;
        this.random = random;
    }

    public RandomCollection<E> add(double weight, E result) {
        if (weight <= 0.0d) {
            return this;
        }
        this.total += weight;
        this.map.put(Double.valueOf(this.total), result);
        return this;
    }

    public E next() {
        double value = this.random.nextDouble() * this.total;
        return this.map.higherEntry(Double.valueOf(value)).getValue();
    }

    public void reset() {
        this.total = 0.0d;
        this.map.clear();
    }
}

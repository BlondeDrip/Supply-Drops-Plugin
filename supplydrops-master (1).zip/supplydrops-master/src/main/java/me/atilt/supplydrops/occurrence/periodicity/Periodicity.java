package me.atilt.supplydrops.occurrence.periodicity;

import java.time.Duration;
import java.time.Instant;
import java.util.function.BooleanSupplier;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/occurrence/periodicity/Periodicity.class */
public interface Periodicity extends BooleanSupplier, ConfigurationSerializable {
    @Nullable
    Instant origin();

    @Nullable
    Instant current();

    @Nullable
    Instant next();

    @Nonnull
    Duration every();

    @Nonnull
    Duration until();

    void start();

    boolean test();

    @Override // java.util.function.BooleanSupplier
    @Deprecated
    default boolean getAsBoolean() {
        return test();
    }
}

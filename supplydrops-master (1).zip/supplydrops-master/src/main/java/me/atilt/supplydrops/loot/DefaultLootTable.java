package me.atilt.supplydrops.loot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.loot.probability.Probability;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/loot/DefaultLootTable.class */
public final class DefaultLootTable implements LootTable {
    private final List<LootEntry<?>> entries = new ArrayList();

    public DefaultLootTable(@Nonnull List<LootEntry<?>> entries) {
        this.entries.addAll(entries);
    }

    @Override // me.atilt.supplydrops.loot.LootTable
    @Nonnull
    public List<LootEntry<?>> entries() {
        return Collections.unmodifiableList(this.entries);
    }

    @Override // me.atilt.supplydrops.loot.LootTable
    public void add(@Nonnull LootEntry<?> entry) {
        this.entries.add(entry);
    }

    @Override // me.atilt.supplydrops.loot.LootTable
    public void remove(@Nonnull LootEntry<?> entry) {
        this.entries.remove(entry);
    }

    @Override // me.atilt.supplydrops.loot.LootTable
    public boolean empty() {
        return this.entries.isEmpty();
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.loot.LootTable, java.util.function.Supplier
    @Nonnull
    public List<LootEntry<?>> get() {
        List<LootEntry<?>> computed = new ArrayList<>(this.entries.size() * 2);
        for (LootEntry<?> entry : this.entries) {
            for (int i = 0; i < entry.rolls(); i++) {
                Probability probability = entry.probability();
                if (probability.test()) {
                    computed.add(entry);
                }
            }
        }
        return computed;
    }

    @Override // java.lang.Iterable
    @Nonnull
    public Iterator<LootEntry<?>> iterator() {
        return entries().iterator();
    }

    @Nonnull
    public Map<String, Object> serialize() {
        return Collections.singletonMap("entries", this.entries);
    }

    @Nonnull
    public static LootTable deserialize(@Nonnull Map<String, Object> tree) {
        return new DefaultLootTable((List) tree.get("entries"));
    }
}

package me.atilt.supplydrops.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.concurrent.ThreadLocalRandom;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Randoms.class */
public final class Randoms {
    public static BigDecimal get(BigDecimal min, BigDecimal max, int scale, RoundingMode roundingMode) {
        BigDecimal randomValue = max.subtract(min).multiply(BigDecimal.valueOf(ThreadLocalRandom.current().nextDouble())).add(min);
        return randomValue.setScale(scale, roundingMode);
    }
}

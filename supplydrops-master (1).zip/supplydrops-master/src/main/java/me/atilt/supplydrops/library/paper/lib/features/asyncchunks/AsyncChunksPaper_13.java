package me.atilt.supplydrops.library.paper.lib.features.asyncchunks;

import java.util.concurrent.CompletableFuture;
import org.bukkit.Chunk;
import org.bukkit.World;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/asyncchunks/AsyncChunksPaper_13.class */
public class AsyncChunksPaper_13 implements AsyncChunks {
    @Override // me.atilt.supplydrops.library.paper.lib.features.asyncchunks.AsyncChunks
    public CompletableFuture<Chunk> getChunkAtAsync(World world, int x, int z, boolean gen, boolean isUrgent) {
        return world.getChunkAtAsync(x, z, gen);
    }
}

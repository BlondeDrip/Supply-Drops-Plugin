package me.atilt.supplydrops.config;

import java.util.function.Supplier;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/config/Placeholder.class */
public interface Placeholder {
    @Nonnull
    String key();

    @Nonnull
    Supplier<String> value();
}

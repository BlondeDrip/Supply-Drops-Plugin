package me.atilt.supplydrops.config;

import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.bukkit.entity.Entity;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/config/Message.class */
public interface Message {
    @Nullable
    String string();

    @Nullable
    String parse();

    @Nonnull
    List<Placeholder> placeholders();

    void send(@Nonnull Entity entity);
}

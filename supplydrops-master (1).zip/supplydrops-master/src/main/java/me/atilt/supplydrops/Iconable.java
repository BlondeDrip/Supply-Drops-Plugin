package me.atilt.supplydrops;

import java.util.function.Supplier;
import javax.annotation.Nonnull;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/Iconable.class */
public interface Iconable {
    @Nonnull
    Supplier<ItemStack> icon();
}

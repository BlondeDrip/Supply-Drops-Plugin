package me.atilt.supplydrops.library.paper.lib.features.asyncteleport;

import java.util.concurrent.CompletableFuture;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.event.player.PlayerTeleportEvent;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/asyncteleport/AsyncTeleportPaper_13.class */
public class AsyncTeleportPaper_13 implements AsyncTeleport {
    @Override // me.atilt.supplydrops.library.paper.lib.features.asyncteleport.AsyncTeleport
    public CompletableFuture<Boolean> teleportAsync(Entity entity, Location location, PlayerTeleportEvent.TeleportCause cause) {
        return entity.teleportAsync(location, cause);
    }
}

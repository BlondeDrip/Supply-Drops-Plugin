package me.atilt.supplydrops.model.registry;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.Model;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/registry/EntityTriplet.class */
public final class EntityTriplet {
    private final Model model;
    private final Limb limb;
    private final SupplyDrop supplyDrop;

    public EntityTriplet(@Nonnull Model model, @Nonnull Limb limb, @Nonnull SupplyDrop supplyDrop) {
        this.model = model;
        this.limb = limb;
        this.supplyDrop = supplyDrop;
    }

    @Nonnull
    public Model getModel() {
        return this.model;
    }

    @Nonnull
    public Limb getLimb() {
        return this.limb;
    }

    public SupplyDrop getSupplyDrop() {
        return this.supplyDrop;
    }
}

package me.atilt.supplydrops.api.model.util;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/util/FastMath.class */
public final class FastMath {
    private static final int BIG_ENOUGH_INT = 16384;
    private static final double BIG_ENOUGH_FLOOR = 16384.0d;
    private static final double BIG_ENOUGH_ROUND = 16384.5d;
    private static final int SIN_BITS = 12;
    private static final int SIN_MASK = ((-1) << SIN_BITS) ^ (-1);
    private static final int SIN_COUNT = SIN_MASK + 1;
    private static final float radFull = 6.2831855f;
    private static final float degFull = 360.0f;
    private static final float radToIndex = SIN_COUNT / radFull;
    private static final float degToIndex = SIN_COUNT / degFull;
    private static final float[] sin = new float[SIN_COUNT];
    private static final float[] cos = new float[SIN_COUNT];

    private FastMath() {
        throw new UnsupportedOperationException("This class cannot be instantiated");
    }

    static {
        for (int i = 0; i < SIN_COUNT; i++) {
            sin[i] = (float) Math.sin(((i + 0.5f) / SIN_COUNT) * radFull);
            cos[i] = (float) Math.cos(((i + 0.5f) / SIN_COUNT) * radFull);
        }
        for (int i2 = 0; i2 < 360; i2 += 90) {
            sin[((int) (i2 * degToIndex)) & SIN_MASK] = (float) Math.sin((i2 * 3.141592653589793d) / 180.0d);
            cos[((int) (i2 * degToIndex)) & SIN_MASK] = (float) Math.cos((i2 * 3.141592653589793d) / 180.0d);
        }
    }

    public static float sin(float rad) {
        return sin[((int) (rad * radToIndex)) & SIN_MASK];
    }

    public static float cos(float rad) {
        return cos[((int) (rad * radToIndex)) & SIN_MASK];
    }

    public static float sinDeg(float deg) {
        return sin[((int) (deg * degToIndex)) & SIN_MASK];
    }

    public static float cosDeg(float deg) {
        return cos[((int) (deg * degToIndex)) & SIN_MASK];
    }

    public static int floor(float x) {
        return ((int) (x + BIG_ENOUGH_FLOOR)) - 16384;
    }

    public static int round(float x) {
        return ((int) (x + BIG_ENOUGH_ROUND)) - 16384;
    }

    public static int ceil(float x) {
        return 16384 - ((int) (BIG_ENOUGH_FLOOR - x));
    }

    public static int floor(double x) {
        return ((int) (x + BIG_ENOUGH_FLOOR)) - 16384;
    }

    public static int round(double x) {
        return ((int) (x + BIG_ENOUGH_ROUND)) - 16384;
    }

    public static int ceil(double x) {
        return 16384 - ((int) (BIG_ENOUGH_FLOOR - x));
    }
}

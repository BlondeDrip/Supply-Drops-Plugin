package me.atilt.supplydrops.api.model;

import java.util.function.Consumer;
import java.util.function.Function;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/Schema.class */
public interface Schema<T> extends Function<T, T>, Consumer<T>, AutoCloseable {
    public static final Schema<Object> EMPTY = new Schema<Object>() { // from class: me.atilt.supplydrops.api.model.Schema.2
        @Override // me.atilt.supplydrops.api.model.Schema
        @Nonnull
        /* renamed from: clone */
        public Schema<Object> clone() {
            return EMPTY;
        }

        @Override // java.util.function.Consumer
        public void accept(Object o) {
        }
    };

    @Nonnull
    Schema<T> clone();

    default boolean shouldApply(@Nonnull T object) {
        return true;
    }

    @Nonnull
    default Schema<T> merge(@Nonnull final Schema<? super T> other) {
        return new Schema<T>() { // from class: me.atilt.supplydrops.api.model.Schema.1
            @Override // me.atilt.supplydrops.api.model.Schema, java.lang.AutoCloseable
            public void close() {
                try {
                    Schema.this.close();
                    other.close();
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }

            @Override // me.atilt.supplydrops.api.model.Schema
            @Nonnull
            /* renamed from: clone */
            public Schema<T> clone() {
                return Schema.this.clone().merge(other.clone());
            }

            @Override // java.util.function.Consumer
            public void accept(@Nonnull T t) {
                Schema.this.accept(t);
                other.accept(t);
            }

            @Override // me.atilt.supplydrops.api.model.Schema, java.util.function.Function
            @Nonnull
            public T apply(@Nonnull T entity) {
                Schema.this.apply(entity);
                other.apply(entity);
                return entity;
            }
        };
    }

    @Override // java.util.function.Function
    @Nonnull
    default T apply(@Nonnull T entity) {
        if (shouldApply(entity)) {
            accept(entity);
        }
        return entity;
    }

    @Override // java.lang.AutoCloseable
    default void close() throws Exception {
    }
}

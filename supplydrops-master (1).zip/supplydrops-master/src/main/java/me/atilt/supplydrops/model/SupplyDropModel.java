package me.atilt.supplydrops.model;

import java.util.List;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.api.model.Interaction;
import me.atilt.supplydrops.api.model.ModelMeta;
import me.atilt.supplydrops.api.model.util.Vector3d;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import org.bukkit.entity.Player;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/SupplyDropModel.class */
public final class SupplyDropModel extends AudiencedModel {
    private final SupplyDropInteraction supplyDropInteraction = new SupplyDropInteraction();

    @Override // me.atilt.supplydrops.api.model.Interactable
    @Nonnull
    public Interaction<Player, SupplyDrop> interaction() {
        return null;
    }

    @Override // me.atilt.supplydrops.api.model.Model
    @Nonnull
    public ModelMeta meta() {
        return new ModelMeta("Supply Drop", "1.0.0", List.of("Atilt"));
    }

    @Override // me.atilt.supplydrops.api.model.ModelEntity, me.atilt.supplydrops.api.model.limb.Limb
    public Vector3d offset() {
        return new Vector3d(0.5d, 0.0d, 0.5d);
    }
}

package me.atilt.supplydrops.util;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Collections.class */
public final class Collections {
    private Collections() {
        throw new UnsupportedOperationException("This class cannot be instantiated");
    }

    @Nonnull
    public static <T, U> List<U> transform(@Nonnull List<T> list, @Nonnull Function<T, U> transformer) {
        List<U> transformed = new ArrayList<>(list.size());
        for (T object : list) {
            transformed.add(transformer.apply(object));
        }
        return transformed;
    }
}

package me.atilt.supplydrops.api.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import org.jetbrains.annotations.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/DefaultStateDeserializer.class */
public class DefaultStateDeserializer implements StateDeserializer {
    private final Map<SerializedState, Supplier<EntitySchema<?>>> mappings = new HashMap();
    private final Map<Class<? extends SerializedState>, Function<SerializedState, Supplier<EntitySchema<?>>>> internals = new HashMap<Class<? extends SerializedState>, Function<SerializedState, Supplier<EntitySchema<?>>>>() { // from class: me.atilt.supplydrops.api.model.DefaultStateDeserializer.1
        {
            put(ArmorStandMockData.class, state -> {
                return () -> {
                    return new ArmorStandSchema((ArmorStandMockData) state);
                };
            });
        }
    };

    @Override // me.atilt.supplydrops.api.model.StateDeserializer
    @Nullable
    public <T extends SerializedState> StateDeserializer supply(@Nonnull T state, @Nonnull Function<T, Supplier<EntitySchema<?>>> schemaProvider) {
        return this;
    }

    @Override // me.atilt.supplydrops.api.model.StateDeserializer
    @Nullable
    public <T extends SerializedState> StateDeserializer supplyAll(@Nonnull List<T> state, @Nonnull Function<T, Supplier<EntitySchema<?>>> schemaProvider) {
        for (T serialized : state) {
            supply(serialized, schemaProvider);
        }
        return this;
    }

    @Override // java.util.function.Function
    public Supplier<EntitySchema<?>> apply(SerializedState state) {
        return this.internals.get(state.getClass()).apply(state);
    }
}

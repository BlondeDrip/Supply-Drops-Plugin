package me.atilt.supplydrops.api.model;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import org.bukkit.plugin.Plugin;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/DefaultIntModelFactory.class */
public class DefaultIntModelFactory implements IntModelFactory {
    private final Plugin plugin;
    private final Int2ObjectMap<ModelConveyor<? extends Model>> conveyors = new Int2ObjectOpenHashMap();
    private static final IntModelFactory.IdGenerator ID_GENERATOR = new IntModelFactory.IdGenerator();

    @Override // me.atilt.supplydrops.api.model.ModelFactory
    @Nonnull
    @Deprecated
    public /* bridge */ /* synthetic */ Model manufacture(@Nonnull Integer num, @Nonnull List list) {
        return manufacture2(num, (List<SerializedState>) list);
    }

    @Override // me.atilt.supplydrops.api.model.ModelFactory
    @Nullable
    @Deprecated
    public /* bridge */ /* synthetic */ ModelConveyor submit(@Nonnull Integer num, @Nonnull ModelConveyor modelConveyor) {
        return submit2(num, (ModelConveyor<? extends Model>) modelConveyor);
    }

    public DefaultIntModelFactory(@Nonnull Plugin plugin) {
        this.plugin = plugin;
    }

    @Override // me.atilt.supplydrops.api.model.IntModelFactory
    @Nullable
    public ModelConveyor<? extends Model> submitInt(int id, @Nonnull ModelConveyor<? extends Model> conveyor) {
        return this.conveyors.put(id,conveyor);
    }

    @Override // me.atilt.supplydrops.api.model.IntModelFactory
    @Nonnull
    public Model manufactureInt(int id) {
        ModelConveyor<? extends Model> modelConveyor = this.conveyors.get(id);
        validate(modelConveyor);
        List<SerializedState> states = modelConveyor.defaultStates().get();
        if (states.isEmpty()) {
            throw new IllegalStateException("missing entity schemas");
        }
        Model model = modelConveyor.handle().get();
        for (SerializedState state : states) {
            EntitySchema<?> entitySchema = modelConveyor.schemas().apply(state).get();
            EntityRenderer<?> entityRenderer = modelConveyor.renderers().apply(entitySchema);
            Limb limb = modelConveyor.limbs().apply(entityRenderer, entitySchema);
            model.bind(limb);
        }
        return model;
    }

    @Override // me.atilt.supplydrops.api.model.IntModelFactory
    @Nonnull
    public Model manufactureInt(int id, @Nonnull List<SerializedState> states) {
        if (states.isEmpty()) {
            throw new IllegalStateException("missing states");
        }
        ModelConveyor<? extends Model> modelConveyor = this.conveyors.get(id);
        validate(modelConveyor);
        Model model = modelConveyor.handle().get();
        for (SerializedState state : states) {
            EntitySchema<?> entitySchema = modelConveyor.schemas().apply(state).get();
            EntityRenderer<?> entityRenderer = modelConveyor.renderers().apply(entitySchema);
            Limb limb = modelConveyor.limbs().apply(entityRenderer, entitySchema);
            model.bind(limb);
        }
        return model;
    }

    @Override // me.atilt.supplydrops.api.model.ModelFactory
    @Nonnull
    public Plugin plugin() {
        return this.plugin;
    }

    @Override // me.atilt.supplydrops.api.model.ModelFactory
    @Nonnull
    public Map<Integer, ModelConveyor<? extends Model>> conveyors() {
        return Collections.unmodifiableMap(this.conveyors);
    }

    @Override // me.atilt.supplydrops.api.model.ModelFactory
    @Nonnull
    public <T extends Model> DefaultModelConveyor.Builder<T> conveyorBuilder() {
        return new DefaultModelConveyor.Builder<>();
    }

    @Nullable
    @Deprecated
    /* renamed from: submit  reason: avoid collision after fix types in other method */
    public ModelConveyor<? extends Model> submit2(@Nonnull Integer id, @Nonnull ModelConveyor<? extends Model> conveyor) {
        return submitInt(id.intValue(), conveyor);
    }

    @Override // me.atilt.supplydrops.api.model.ModelFactory
    @Nonnull
    public Model manufacture(@Nonnull Integer id) {
        return manufactureInt(id.intValue());
    }

    @Nonnull
    @Deprecated
    /* renamed from: manufacture  reason: avoid collision after fix types in other method */
    public Model manufacture2(@Nonnull Integer id, @Nonnull List<SerializedState> providers) {
        return manufactureInt(id.intValue(), providers);
    }

    private void validate(@Nullable ModelConveyor<? extends Model> conveyor) {
        if (conveyor == null) {
            throw new IllegalStateException("missing model conveyor");
        }
    }
}

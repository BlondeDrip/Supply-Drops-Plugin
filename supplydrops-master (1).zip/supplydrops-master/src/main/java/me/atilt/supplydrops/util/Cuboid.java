package me.atilt.supplydrops.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Cuboid.class */
public final class Cuboid implements ConfigurationSerializable {
    private String world;
    private final long min;
    private final long max;
    private final LazySupplier<Set<Block>> BLOCKS = new DefaultLazySupplier(() -> {
        Set<Block> blocks = new HashSet<>(volume());
        int minX = getMinBlockX();
        int minY = getMinBlockY();
        int minZ = getMinBlockZ();
        int maxX = getMaxBlockX();
        int maxY = getMaxBlockY();
        int maxZ = getMaxBlockZ();
        World bukkitWorld = Bukkit.getWorld(this.world);
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    blocks.add(bukkitWorld.getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    });

    public Cuboid(Location loc1, Location loc2) {
        if (!loc1.getWorld().equals(loc2.getWorld())) {
            throw new IllegalArgumentException("The two locations are not in the same world.");
        }
        this.world = loc1.getWorld().getName();
        if (loc1.equals(loc2)) {
            this.min = Worlds.locationKey(loc1);
            this.max = this.min;
            return;
        }
        int minX = Math.min(loc1.getBlockX(), loc2.getBlockX());
        int minY = Math.min(loc1.getBlockY(), loc2.getBlockY());
        int minZ = Math.min(loc1.getBlockZ(), loc2.getBlockZ());
        this.min = Worlds.locationKey(new Location(loc1.getWorld(), minX, minY, minZ));
        int maxX = Math.max(loc1.getBlockX(), loc2.getBlockX());
        int maxY = Math.max(loc1.getBlockY(), loc2.getBlockY());
        int maxZ = Math.max(loc1.getBlockZ(), loc2.getBlockZ());
        this.max = Worlds.locationKey(new Location(loc1.getWorld(), maxX, maxY, maxZ));
    }

    public String getWorld() {
        return this.world;
    }

    @Nonnull
    public Location getMin() {
        return new Location(Bukkit.getWorld(this.world), getMinBlockX(), getMinBlockY(), getMinBlockZ());
    }

    @Nonnull
    public Location getMax() {
        return new Location(Bukkit.getWorld(this.world), getMaxBlockX(), getMaxBlockY(), getMaxBlockZ());
    }

    public int getMinBlockX() {
        return Worlds.keyX(this.min);
    }

    public int getMinBlockY() {
        return Worlds.keyY(this.min);
    }

    public int getMinBlockZ() {
        return Worlds.keyZ(this.min);
    }

    public int getMaxBlockX() {
        return Worlds.keyX(this.max);
    }

    public int getMaxBlockY() {
        return Worlds.keyY(this.max);
    }

    public int getMaxBlockZ() {
        return Worlds.keyZ(this.max);
    }

    public boolean contains(@Nonnull Location location) {
        if (!location.getWorld().getName().equals(this.world)) {
            return false;
        }
        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();
        return x >= getMinBlockX() && x <= getMaxBlockX() && y >= getMinBlockY() && y <= getMaxBlockY() && z >= getMinBlockZ() && z <= getMaxBlockZ();
    }

    @Nullable
    public Cuboid expand(int x, int y, int z) {
        World found = Bukkit.getWorld(this.world);
        if (found == null) {
            return null;
        }
        Location loc1 = Worlds.keyLocation(found, this.min);
        Location loc2 = Worlds.keyLocation(found, this.max);
        loc1.add(x, y, z);
        loc2.add(x, y, z);
        return new Cuboid(loc1, loc2);
    }

    @Nullable
    public Cuboid shrink(int x, int y, int z) {
        return expand(-x, -y, -z);
    }

    @Nonnegative
    public int volume() {
        int dx = Math.abs(getMinBlockX() - getMaxBlockX()) + 1;
        int dy = Math.abs(getMinBlockY() - getMaxBlockY()) + 1;
        int dz = Math.abs(getMinBlockZ() - getMaxBlockZ()) + 1;
        return dx * dy * dz;
    }

    public int randomX() {
        return ThreadLocalRandom.current().nextInt(getMinBlockX(), getMaxBlockX() + 1);
    }

    public int randomY() {
        return ThreadLocalRandom.current().nextInt(getMinBlockY(), getMaxBlockY() + 1);
    }

    public int randomZ() {
        return ThreadLocalRandom.current().nextInt(getMinBlockZ(), getMaxBlockZ() + 1);
    }

    public void traverse(Consumer<Block> found) {
        for (Block block : this.BLOCKS.get()) {
            found.accept(block);
        }
    }

    @Nonnull
    public Map<String, Object> serialize() {
        Map<String, Object> tree = new HashMap<>(3);
        tree.put("min", getMin());
        tree.put("max", getMax());
        return tree;
    }

    @Nonnull
    public static Cuboid deserialize(@Nonnull Map<String, Object> tree) {
        return new Cuboid((Location) tree.get("min"), (Location) tree.get("max"));
    }
}

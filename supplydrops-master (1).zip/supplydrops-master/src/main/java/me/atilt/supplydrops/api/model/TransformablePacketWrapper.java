package me.atilt.supplydrops.api.model;

import java.util.function.BiFunction;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/TransformablePacketWrapper.class */
public interface TransformablePacketWrapper<R, P> extends PacketWrapper<P> {
    @Nonnull
    BiFunction<R, PacketWrapper<P>, PacketWrapper<P>> transformation();
}

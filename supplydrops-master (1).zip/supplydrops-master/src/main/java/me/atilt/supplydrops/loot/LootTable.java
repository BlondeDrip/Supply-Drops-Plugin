package me.atilt.supplydrops.loot;

import java.util.List;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/loot/LootTable.class */
public interface LootTable extends Supplier<List<LootEntry<?>>>, Iterable<LootEntry<?>>, ConfigurationSerializable {
    @Nonnull
    List<LootEntry<?>> entries();

    void add(@Nonnull LootEntry<?> lootEntry);

    void remove(@Nonnull LootEntry<?> lootEntry);

    boolean empty();

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.util.function.Supplier
    @Nonnull
    List<LootEntry<?>> get();
}

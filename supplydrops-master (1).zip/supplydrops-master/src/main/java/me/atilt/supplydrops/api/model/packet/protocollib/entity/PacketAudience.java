package me.atilt.supplydrops.api.model.packet.protocollib.entity;

import java.util.List;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.packet.Audience;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import org.bukkit.entity.Entity;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/PacketAudience.class */
public interface PacketAudience<E extends Entity, P> extends Audience<E> {
    @Nonnull
    List<PacketWrapper<P>> packets();
}

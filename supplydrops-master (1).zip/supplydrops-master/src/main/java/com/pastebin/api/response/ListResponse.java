package com.pastebin.api.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import java.util.List;
@JacksonXmlRootElement(localName = "response")
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/response/ListResponse.class */
public class ListResponse {
    @JacksonXmlProperty(localName = "paste")
    @JacksonXmlElementWrapper(useWrapping = false)
    private List<ListResponseItem> items;

    public List<ListResponseItem> getItems() {
        return this.items;
    }

    public void setItems(List<ListResponseItem> items) {
        this.items = items;
    }
}

package me.atilt.supplydrops.api.model.entity.living.packet.protocol;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketContainer;
import java.util.UUID;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.DataWatcherBuilder;
import me.atilt.supplydrops.api.model.entity.living.LivingEntity;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolAudience;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.EntityEquipmentPacket;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.EntityMetadataPacket;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.PacketAudience;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/entity/living/packet/protocol/ProtocolLivingEntity.class */
public class ProtocolLivingEntity extends ProtocolEntity implements LivingEntity {
    private final ItemStack[] equipment;
    private boolean invisible;

    public ProtocolLivingEntity(@Nonnull EntityType type, int id, @Nonnull UUID uuid, @Nonnull PacketAudience<Player, PacketContainer> audience) {
        super(type, id, uuid, audience);
        this.equipment = new ItemStack[6];
    }

    public ProtocolLivingEntity(@Nonnull EntityType type, int id, @Nonnull UUID uuid) {
        this(type, id, uuid, ProtocolAudience.builder().bind(id).build());
    }

    @Override // me.atilt.supplydrops.api.model.entity.living.LivingEntity
    @Nonnull
    public ItemStack[] getEquipment() {
        return this.equipment;
    }

    @Override // me.atilt.supplydrops.api.model.entity.living.LivingEntity
    public void setEquipment(@Nonnull EquipmentSlot slot, @Nonnull ItemStack itemStack) {
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.ENTITY_EQUIPMENT, packetWrapper -> {
            return (packetWrapper == null ? EntityEquipmentPacket.newBuilder() : EntityEquipmentPacket.newBuilder(packetWrapper)).entityId(id()).equipment(EntityEquipmentPacket.ProtocolSlot.fromBukkit(slot), itemStack).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), audience());
        this.equipment[slot.ordinal()] = itemStack;
    }

    @Override // me.atilt.supplydrops.api.model.entity.living.LivingEntity
    public void setEquipment(@Nonnull ItemStack[] equipment) {
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.ENTITY_EQUIPMENT, packetWrapper -> {
            return (packetWrapper == null ? EntityEquipmentPacket.newBuilder() : EntityEquipmentPacket.newBuilder(packetWrapper)).entityId(id()).equipment(equipment).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), audience());
        System.arraycopy(equipment, 0, this.equipment, 0, this.equipment.length);
    }

    @Override // me.atilt.supplydrops.api.model.entity.living.LivingEntity
    public boolean isInvisible() {
        return this.invisible;
    }

    @Override // me.atilt.supplydrops.api.model.entity.living.LivingEntity
    public void setInvisible(boolean invisible) {
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.ENTITY_METADATA, packetWrapper -> {
            return (packetWrapper == null ? EntityMetadataPacket.newBuilder() : EntityMetadataPacket.newBuilder(packetWrapper)).entityId(id()).dataWatcher(DataWatcherBuilder.newBuilder(this.dataWatcher).addObject(0, Byte.valueOf(modifyBits(supplyBytes(this.dataWatcher, 0), 5, invisible))).build()).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), audience());
        this.invisible = invisible;
    }
}

package me.atilt.supplydrops.api.model.packet.protocollib.entity;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketContainer;
import com.google.common.base.Preconditions;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.ProtocolVersion;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketBuilder;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityDestroyPacket.class */
public class EntityDestroyPacket implements ProtocolPacketWrapper {
    private final PacketContainer handle;

    public EntityDestroyPacket(@Nonnull PacketContainer handle) {
        Preconditions.checkArgument(handle.getType() == PacketType.Play.Server.ENTITY_DESTROY, "packet mismatch");
        this.handle = handle;
    }

    public EntityDestroyPacket() {
        this(new PacketContainer(PacketType.Play.Server.ENTITY_DESTROY));
    }

    @Nonnull
    public static Builder newBuilder() {
        return new Builder();
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    public PacketContainer handle() {
        return this.handle;
    }

    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    /* renamed from: deepClone */
    public PacketWrapper<PacketContainer> deepClone() {
        return new EntityDestroyPacket(this.handle.deepClone());
    }

    @Override // me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper
    @Nonnull
    public PacketType type() {
        return this.handle.getType();
    }

    @Override // java.lang.AutoCloseable
    public void close() {
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityDestroyPacket$Builder.class */
    public static class Builder extends ProtocolPacketBuilder {
        private Builder(@Nonnull PacketContainer handle) {
            super(handle);
        }

        private Builder() {
            this(new PacketContainer(PacketType.Play.Server.ENTITY_DESTROY));
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        public Builder copy() {
            return new Builder(this.handle.deepClone());
        }

        @Override // me.atilt.supplydrops.api.model.packet.PacketBuilder
        @Nonnull
        /* renamed from: buildPacket */
        public PacketWrapper<PacketContainer> buildPacket() {
            return new EntityDestroyPacket(this.handle);
        }

        @Nonnull
        public Builder entityIds(int... ids) {
            if (ProtocolVersion.runningVersion().isAtLeast(ProtocolVersion.v1_17_R1)) {
                this.handle.getIntLists().write(0, intList(ids));
            } else {
                this.handle.getIntegerArrays().write(0, ids);
            }
            return this;
        }

        private List<Integer> intList(int... ints) {
            List<Integer> intList = new ArrayList<>(ints.length);
            for (int anInt : ints) {
                intList.add(Integer.valueOf(anInt));
            }
            return intList;
        }
    }
}

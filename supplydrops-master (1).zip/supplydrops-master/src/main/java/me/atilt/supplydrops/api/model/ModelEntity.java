package me.atilt.supplydrops.api.model;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.api.model.entity.Entity;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import me.atilt.supplydrops.api.model.util.Vector3d;
import org.bukkit.Location;
import org.bukkit.util.Vector;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/ModelEntity.class */
public abstract class ModelEntity implements Model {
    private final List<Limb> limbs = new LinkedList();
    private Location location;
    private Vector velocity;

    @Override // me.atilt.supplydrops.api.model.limb.Limb
    @Nonnull
    public EntityRenderer<?> renderer() {
        return new EntityRenderer<Entity>() { // from class: me.atilt.supplydrops.api.model.ModelEntity.1
            @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
            @Nullable
            public Entity entity() {
                return null;
            }

            @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
            public boolean rendered() {
                return false;
            }

            @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
            public void render(@Nonnull Location location) {
                ModelEntity.this.render(location);
            }

            @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
            public void unrender() {
                ModelEntity.this.unrender();
            }
        };
    }

    public void render(@Nonnull Location location) {
        this.location = location.clone();
        for (Limb limb : this.limbs) {
            limb.renderer().render(this.location.clone());
        }
    }

    @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
    @Nullable
    public Entity entity() {
        return null;
    }

    @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
    public boolean rendered() {
        return true;
    }

    @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
    public void unrender() {
        try {
            close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override // me.atilt.supplydrops.api.model.limb.CompositeLimb
    @Nonnull
    public List<Limb> limbs() {
        return Collections.unmodifiableList(this.limbs);
    }

    @Override // me.atilt.supplydrops.api.model.Composite
    @Nonnull
    public ModelEntity bind(@Nonnull Limb composite) {
        this.limbs.add(composite);
        return this;
    }

    @Override // me.atilt.supplydrops.api.model.Composite
    /* renamed from: bindAll */
    public Composite<Limb> bindAll(@Nonnull Collection<Limb> composites) {
        this.limbs.addAll(composites);
        return this;
    }

    @Override // me.atilt.supplydrops.api.model.limb.Limb
    @Nullable
    public Location getLocation() {
        return this.location;
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void move(double x, double y, double z) {
        for (Limb limb : this.limbs) {
            limb.move(x, y, z);
        }
        this.location.add(x, y, z);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void move(double x, double y, double z, float yaw, float pitch) {
        for (Limb limb : this.limbs) {
            limb.move(x, y, z, yaw, pitch);
        }
        this.location.add(x, y, z);
        this.location.setYaw(yaw);
        this.location.setPitch(pitch);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void teleport(@Nonnull Location location) {
        this.location = location.clone();
        for (Limb limb : this.limbs) {
            Location rotated = Vectors.rotateTo(limb.getLocation(), location, limb.offset().getX(), limb.offset().getY(), limb.offset().getZ());
            limb.teleport(rotated);
        }
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void rotate(@Nonnull Location location) {
        Location origin = this.location;
        origin.setDirection(Vectors.direction(origin, location));
        teleport(origin);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void rotate(float degrees) {
        this.location.setYaw(clampYaw(this.location.getYaw() + degrees));
        teleport(this.location);
    }

    @Override // me.atilt.supplydrops.api.model.limb.Limb
    @Nullable
    public Vector3d offset() {
        return Vector3d.ZERO;
    }

    private float clampYaw(float yaw) {
        while (yaw < -180.0f) {
            yaw += 360.0f;
        }
        while (yaw >= 180.0f) {
            yaw -= 360.0f;
        }
        return yaw;
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void setVelocity(@Nonnull Vector velocity) {
        for (Limb limb : this.limbs) {
            limb.setVelocity(velocity);
        }
        this.velocity = velocity;
        this.location.add(velocity);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public Vector getVelocity() {
        return this.velocity == null ? new Vector() : this.velocity;
    }

    @Override // java.lang.AutoCloseable
    public void close() throws Exception {
        for (Limb limb : this.limbs) {
            limb.close();
        }
        this.location = null;
    }
}

package me.atilt.supplydrops.api.model.limb;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.api.model.Interactable;
import me.atilt.supplydrops.api.model.Navigable;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import me.atilt.supplydrops.api.model.util.Vector3d;
import org.bukkit.Location;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/limb/Limb.class */
public interface Limb extends Navigable, Interactable, AutoCloseable {
    @Nullable
    Location getLocation();

    @Nullable
    Vector3d offset();

    @Nonnull
    EntityRenderer<?> renderer();
}

package com.pastebin.api.request;

import java.util.Map;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/request/Request.class */
public interface Request {
    Map<String, String> getParameters();
}

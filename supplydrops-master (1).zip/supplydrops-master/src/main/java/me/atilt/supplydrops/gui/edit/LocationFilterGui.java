package me.atilt.supplydrops.gui.edit;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.distributor.DefaultDistributionParameters;
import me.atilt.supplydrops.distributor.location.SuitableLocation;
import me.atilt.supplydrops.gui.SupplyDropGui;
import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.Icon;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/LocationFilterGui.class */
public class LocationFilterGui extends Gui {
    private final SupplyDrop supplyDrop;
    private final Integer model;
    private final SupplyDropsPlugin plugin;
    private final Set<SuitableLocation> suitableLocations;

    public LocationFilterGui(@Nonnull Player player, @Nonnull SupplyDrop supplyDrop, @Nonnull Integer model, @Nonnull SupplyDropsPlugin plugin) {
        super(player, "supplydrops-location-filter-gui", Text.color("Editing &lfilters&r for " + supplyDrop.meta().name()), 6);
        this.supplyDrop = supplyDrop;
        this.model = model;
        this.suitableLocations = new HashSet(supplyDrop.distributor().parameters().suitableLocations());
        this.plugin = plugin;
    }

    @Override // mc.obliviate.inventory.Gui
    public void onOpen(InventoryOpenEvent event) {
        fillRow(SupplyDropGui.PLACEHOLDER, 4);
        addItem(49, new Icon(Material.BARRIER).setName(Text.color("&cBack to editor")).onClick(clickEvent -> {
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
            new SupplyDropEditorGui(this.player, this.supplyDrop, this.model, this.plugin).open();
        }));
        build();
    }

    @Override // mc.obliviate.inventory.Gui
    public void onClose(InventoryCloseEvent event) {
        this.supplyDrop.distributor().parameters(DefaultDistributionParameters.newBuilder().adapt(this.supplyDrop.distributor().parameters()).suitableLocations(new ArrayList(this.suitableLocations)).build());
    }

    private void build() {
        int i = 0;
        for (SuitableLocation suitableLocation : SuitableLocation.ALL) {
            boolean enabled = this.suitableLocations.contains(suitableLocation);
            Icon lore = new Icon(suitableLocation.icon().get().clone()).setLore(Text.color(suitableLocation.description().get(), line -> {
                return Text.color("&7") + line;
            }));
            String[] strArr = new String[2];
            strArr[0] = " ";
            strArr[1] = Text.color("&aStatus: &e" + (enabled ? "Enabled" : "Disabled"));
            Icon icon = lore.appendLore(strArr).onClick(clickEvent -> {
                if (!this.suitableLocations.add(suitableLocation)) {
                    this.suitableLocations.remove(suitableLocation);
                }
                this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
                build();
            });
            if (enabled) {
                icon.getItem().addUnsafeEnchantment(Enchantment.DURABILITY, 1);
            } else {
                icon.getItem().removeEnchantment(Enchantment.DURABILITY);
            }
            int i2 = i;
            i++;
            addItem(i2, icon);
        }
    }
}

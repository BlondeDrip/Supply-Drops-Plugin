package me.atilt.supplydrops.distributor;

import java.util.List;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.distributor.location.SuitableLocation;
import me.atilt.supplydrops.util.Cuboid;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/distributor/DistributionParameters.class */
public interface DistributionParameters extends ConfigurationSerializable {
    @Nonnull
    Cuboid cuboid();

    @Nonnull
    List<SuitableLocation> suitableLocations();
}

package com.pastebin.api.request;

import java.util.HashMap;
import java.util.Map;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/request/UserRequest.class */
public class UserRequest implements Request {
    @Override // com.pastebin.api.request.Request
    public Map<String, String> getParameters() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("api_option", "userdetails");
        return parameters;
    }
}

package me.atilt.supplydrops.library.paper.lib.features.bedspawnlocation;

import java.util.concurrent.CompletableFuture;
import me.atilt.supplydrops.library.paper.lib.PaperLib;
import org.bukkit.Location;
import org.bukkit.entity.Player;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/bedspawnlocation/BedSpawnLocationPaper.class */
public class BedSpawnLocationPaper implements BedSpawnLocation {
    @Override // me.atilt.supplydrops.library.paper.lib.features.bedspawnlocation.BedSpawnLocation
    public CompletableFuture<Location> getBedSpawnLocationAsync(Player player, boolean isUrgent) {
        Location bedLocation = player.getPotentialBedLocation();
        if (bedLocation == null || bedLocation.getWorld() == null) {
            return CompletableFuture.completedFuture(null);
        }
        return PaperLib.getChunkAtAsync(bedLocation.getWorld(), bedLocation.getBlockX() >> 4, bedLocation.getBlockZ() >> 4, false, isUrgent).thenCompose(chunk -> {
            return CompletableFuture.completedFuture(player.getBedSpawnLocation());
        });
    }
}

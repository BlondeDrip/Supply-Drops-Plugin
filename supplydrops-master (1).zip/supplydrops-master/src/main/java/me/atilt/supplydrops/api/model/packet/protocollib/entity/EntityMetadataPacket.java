package me.atilt.supplydrops.api.model.packet.protocollib.entity;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.WrappedDataWatcher;
import com.google.common.base.Preconditions;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.DataWatcherBuilder;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.ProtocolVersion;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketBuilder;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityMetadataPacket.class */
public final class EntityMetadataPacket implements ProtocolPacketWrapper {
    private final PacketContainer handle;

    public EntityMetadataPacket(@Nonnull PacketContainer handle) {
        Preconditions.checkArgument(handle.getType() == PacketType.Play.Server.ENTITY_METADATA, "packet mismatch");
        this.handle = handle;
    }

    public EntityMetadataPacket() {
        this(new PacketContainer(PacketType.Play.Server.ENTITY_METADATA));
    }

    @Nonnull
    public static Builder newBuilder(@Nonnull PacketWrapper<PacketContainer> wrapper) {
        return new Builder(wrapper.handle());
    }

    @Nonnull
    public static Builder newBuilder() {
        return new Builder();
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    public PacketContainer handle() {
        return this.handle;
    }

    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    /* renamed from: deepClone */
    public PacketWrapper<PacketContainer> deepClone() {
        return new EntityMetadataPacket(this.handle.deepClone());
    }

    @Override // me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper
    @Nonnull
    public PacketType type() {
        return this.handle.getType();
    }

    @Override // java.lang.AutoCloseable
    public void close() throws Exception {
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityMetadataPacket$Builder.class */
    public static class Builder extends ProtocolPacketBuilder {
        private Builder(@Nonnull PacketContainer handle) {
            super(handle);
        }

        private Builder() {
            this(new PacketContainer(PacketType.Play.Server.ENTITY_METADATA));
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        public Builder copy() {
            return new Builder(this.handle.deepClone());
        }

        @Override // me.atilt.supplydrops.api.model.packet.PacketBuilder
        @Nonnull
        /* renamed from: buildPacket */
        public PacketWrapper<PacketContainer> buildPacket() {
            return new EntityMetadataPacket(this.handle);
        }

        @Nonnull
        public Builder entityId(int id) {
            this.handle.getIntegers().write(0, Integer.valueOf(id));
            return this;
        }

        public Builder dataWatcher(@Nonnull WrappedDataWatcher dataWatcher) {
            if (ProtocolVersion.runningVersion().isAtLeast(ProtocolVersion.v1_19_R2)) {
                this.handle.getDataValueCollectionModifier().write(0, DataWatcherBuilder.objectsToValues(dataWatcher));
            } else {
                this.handle.getWatchableCollectionModifier().write(0, dataWatcher.getWatchableObjects());
            }
            return this;
        }
    }
}

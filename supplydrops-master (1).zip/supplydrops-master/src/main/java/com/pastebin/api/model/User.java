package com.pastebin.api.model;

import com.pastebin.api.AccountType;
import com.pastebin.api.Visibility;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/model/User.class */
public class User {
    private String username;
    private String formatShort;
    private String expiration;
    private String avatarUrl;
    private Visibility privacy;
    private String website;
    private String email;
    private String location;
    private AccountType accountType;

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFormatShort() {
        return this.formatShort;
    }

    public void setFormatShort(String formatShort) {
        this.formatShort = formatShort;
    }

    public String getExpiration() {
        return this.expiration;
    }

    public void setExpiration(String expiration) {
        this.expiration = expiration;
    }

    public String getAvatarUrl() {
        return this.avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public Visibility getPrivacy() {
        return this.privacy;
    }

    public void setPrivacy(Visibility privacy) {
        this.privacy = privacy;
    }

    public String getWebsite() {
        return this.website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLocation() {
        return this.location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public AccountType getAccountType() {
        return this.accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    public String toString() {
        return "User{username='" + this.username + "', formatShort='" + this.formatShort + "', expiration='" + this.expiration + "', avatarUrl='" + this.avatarUrl + "', privacy=" + this.privacy + ", website='" + this.website + "', email='" + this.email + "', location='" + this.location + "', accountType=" + this.accountType + '}';
    }
}

package me.atilt.supplydrops.distributor.location;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.util.DefaultLazySupplier;
import me.atilt.supplydrops.util.ItemStackBuilder;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/distributor/location/AirBoxLocation.class */
public class AirBoxLocation implements SuitableLocation {
    public static final AirBoxLocation INSTANCE = new AirBoxLocation();

    private AirBoxLocation() {
    }

    @Override // java.util.function.Predicate
    public boolean test(Block block) {
        return !block.isLiquid() && (!block.getType().isSolid() || block.getType().isAir());
    }

    @Override // me.atilt.supplydrops.Iconable
    @Nonnull
    public Supplier<ItemStack> icon() {
        return new DefaultLazySupplier(() -> {
            return ItemStackBuilder.of(Material.GLASS_BOTTLE).name(Text.color("&fAir Box Filter")).allFlags().build();
        });
    }

    @Override // me.atilt.supplydrops.Descriptable
    @Nonnull
    public Supplier<List<String>> description() {
        return new DefaultLazySupplier(() -> {
            return Arrays.asList("Determines there should be a 'box' of air blocks around", "the spawn location of the supply drop.");
        });
    }

    @Nonnull
    public Map<String, Object> serialize() {
        return Collections.singletonMap("name", getClass().getSimpleName());
    }

    @Nonnull
    public static SuitableLocation deserialize(@Nonnull Map<String, Object> tree) {
        return INSTANCE;
    }
}

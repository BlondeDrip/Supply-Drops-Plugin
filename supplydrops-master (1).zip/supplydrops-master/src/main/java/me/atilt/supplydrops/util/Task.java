package me.atilt.supplydrops.util;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Task.class */
public interface Task extends Runnable {
    default boolean running() {
        return true;
    }
}

package me.atilt.supplydrops.api.model.packet.protocollib.entity;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.EnumWrappers;
import com.comphenix.protocol.wrappers.Pair;
import com.google.common.base.Preconditions;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.ProtocolVersion;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketBuilder;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityEquipmentPacket.class */
public final class EntityEquipmentPacket implements ProtocolPacketWrapper {
    private final PacketContainer handle;

    public EntityEquipmentPacket(@Nonnull PacketContainer handle) {
        Preconditions.checkArgument(handle.getType() == PacketType.Play.Server.ENTITY_EQUIPMENT, "packet mismatch");
        this.handle = handle;
    }

    @Nonnull
    public static Builder newBuilder(@Nonnull PacketWrapper<PacketContainer> handle) {
        return new Builder(handle.handle());
    }

    @Nonnull
    public static Builder newBuilder() {
        return new Builder();
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    public PacketContainer handle() {
        return this.handle;
    }

    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    /* renamed from: deepClone */
    public PacketWrapper<PacketContainer> deepClone() {
        return new EntityEquipmentPacket(this.handle.deepClone());
    }

    @Override // me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper
    @Nonnull
    public PacketType type() {
        return this.handle.getType();
    }

    @Override // java.lang.AutoCloseable
    public void close() {
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityEquipmentPacket$Builder.class */
    public static class Builder extends ProtocolPacketBuilder {
        private Builder(@Nonnull PacketContainer handle) {
            super(handle);
        }

        private Builder() {
            this(new PacketContainer(PacketType.Play.Server.ENTITY_EQUIPMENT));
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        public Builder copy() {
            return new Builder(this.handle.deepClone());
        }

        @Override // me.atilt.supplydrops.api.model.packet.PacketBuilder
        @Nonnull
        /* renamed from: buildPacket */
        public PacketWrapper<PacketContainer> buildPacket() {
            return new EntityEquipmentPacket(this.handle);
        }

        @Nonnull
        public Builder entityId(int id) {
            this.handle.getIntegers().write(0, Integer.valueOf(id));
            return this;
        }

        public Builder equipment(ItemStack[] equipment) {
            ProtocolVersion runningVersion = ProtocolVersion.runningVersion();
            if (runningVersion.isAtLeast(ProtocolVersion.v1_16_R1)) {
                List<Pair<EnumWrappers.ItemSlot, ItemStack>> data = new ArrayList<>(Math.min(equipment.length, 6));
                for (int slot = 0; slot < equipment.length && slot <= 5; slot++) {
                    data.add(new Pair<>(ProtocolSlot.ITEM_SLOTS[slot], equipment[slot]));
                }
                this.handle.getSlotStackPairLists().write(0, data);
                return this;
            }
            throw new UnsupportedOperationException("Unable to set unsupported packet data");
        }

        public Builder equipment(ProtocolSlot slot, ItemStack itemStack) {
            ProtocolVersion runningVersion = ProtocolVersion.runningVersion();
            if (runningVersion.isAtLeast(ProtocolVersion.v1_16_R1)) {
                List<Pair<EnumWrappers.ItemSlot, ItemStack>> equipment = (List) this.handle.getSlotStackPairLists().read(0);
                boolean swapped = false;
                Iterator<Pair<EnumWrappers.ItemSlot, ItemStack>> it = equipment.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    Pair<EnumWrappers.ItemSlot, ItemStack> items = it.next();
                    if (items.getFirst() == slot.asWrapper()) {
                        items.setSecond(itemStack);
                        swapped = true;
                        break;
                    }
                }
                if (!swapped) {
                    equipment.add(new Pair<>(EnumWrappers.ItemSlot.valueOf(slot.name()), itemStack));
                }
                this.handle.getSlotStackPairLists().write(0, equipment);
            } else {
                if (runningVersion.isAtLeast(ProtocolVersion.v1_9_R1)) {
                    this.handle.getItemSlots().write(0, slot.asWrapper());
                } else {
                    this.handle.getIntegers().write(1, Integer.valueOf(slot.slot()));
                }
                this.handle.getItemModifier().write(0, itemStack);
            }
            return this;
        }
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityEquipmentPacket$ProtocolSlot.class */
    public enum ProtocolSlot {
        HAND,
        OFF_HAND,
        FEET,
        LEGS,
        CHEST,
        HEAD;
        
        static final ProtocolSlot[] SLOTS = values();
        static final EnumWrappers.ItemSlot[] ITEM_SLOTS = EnumWrappers.ItemSlot.values();
        static final EquipmentSlot[] EQUIPMENT_SLOTS = EquipmentSlot.values();

        public static boolean offhandSupport() {
            return ProtocolVersion.runningVersion().isAtMost(ProtocolVersion.v1_8_R3);
        }

        @Nonnull
        public static ProtocolSlot fromBukkit(@Nonnull EquipmentSlot slot) {
            return SLOTS[slot.ordinal()];
        }

        @Nonnegative
        public int slot() {
            if (offhandSupport()) {
                return ordinal();
            }
            if (this == HAND) {
                return 0;
            }
            return ordinal() - 1;
        }

        @Nonnull
        public EnumWrappers.ItemSlot asWrapper() {
            return ITEM_SLOTS[ordinal()];
        }

        @Nonnull
        public EquipmentSlot asBukkit() {
            return EQUIPMENT_SLOTS[ordinal()];
        }
    }
}

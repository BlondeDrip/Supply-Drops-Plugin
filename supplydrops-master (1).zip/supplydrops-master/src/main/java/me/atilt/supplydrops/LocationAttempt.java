package me.atilt.supplydrops;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/LocationAttempt.class */
public class LocationAttempt {
    private boolean lastAttempt;
    private int total;

    public LocationAttempt(boolean lastAttempt, int total) {
        this.lastAttempt = lastAttempt;
        this.total = total;
    }

    public boolean getLast() {
        return this.lastAttempt;
    }

    public void setLast(boolean attempt) {
        this.lastAttempt = attempt;
    }

    public int getTotal() {
        return this.total;
    }

    public void incrementTotal() {
        this.total++;
    }
}

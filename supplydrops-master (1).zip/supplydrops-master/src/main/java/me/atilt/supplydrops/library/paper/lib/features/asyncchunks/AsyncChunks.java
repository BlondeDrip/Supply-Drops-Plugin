package me.atilt.supplydrops.library.paper.lib.features.asyncchunks;

import java.util.concurrent.CompletableFuture;
import org.bukkit.Chunk;
import org.bukkit.World;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/asyncchunks/AsyncChunks.class */
public interface AsyncChunks {
    CompletableFuture<Chunk> getChunkAtAsync(World world, int i, int i2, boolean z, boolean z2);

    default CompletableFuture<Chunk> getChunkAtAsync(World world, int x, int z, boolean gen) {
        return getChunkAtAsync(world, x, z, gen, false);
    }
}

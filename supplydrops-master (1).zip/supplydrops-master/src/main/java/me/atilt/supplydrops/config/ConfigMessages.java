package me.atilt.supplydrops.config;

import java.util.function.Function;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.util.Text;
import org.bukkit.configuration.ConfigurationSection;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/config/ConfigMessages.class */
public final class ConfigMessages {
    private ConfigurationSection section;

    public void reload(SupplyDropsPlugin plugin) {
        this.section = plugin.getConfig().getConfigurationSection("messages");
    }

    public String getString(@Nonnull String path, @Nullable Function<String, String> mapper) {
        return mapper == null ? getGlobalString(path) : mapper.apply(getGlobalString(path));
    }

    public String getString(@Nonnull String path) {
        return getString(path, null);
    }

    private String getGlobalString(@Nonnull String path) {
        return Text.color(this.section.getString(path).replace("%prefix%", prefix()).replace("\\n", "\n"));
    }

    public String prefix() {
        return this.section.getString("prefix");
    }
}

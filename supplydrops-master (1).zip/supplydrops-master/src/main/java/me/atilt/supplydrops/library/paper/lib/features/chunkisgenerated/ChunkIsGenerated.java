package me.atilt.supplydrops.library.paper.lib.features.chunkisgenerated;

import org.bukkit.World;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/chunkisgenerated/ChunkIsGenerated.class */
public interface ChunkIsGenerated {
    boolean isChunkGenerated(World world, int i, int i2);
}

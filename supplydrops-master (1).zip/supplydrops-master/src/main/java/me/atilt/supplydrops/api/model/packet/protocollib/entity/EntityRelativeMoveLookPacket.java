package me.atilt.supplydrops.api.model.packet.protocollib.entity;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketContainer;
import com.google.common.base.Preconditions;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.ProtocolVersion;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketBuilder;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper;
import org.bukkit.util.Vector;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityRelativeMoveLookPacket.class */
public final class EntityRelativeMoveLookPacket implements ProtocolPacketWrapper {
    private final PacketContainer handle;

    public EntityRelativeMoveLookPacket(@Nonnull PacketContainer handle) {
        Preconditions.checkArgument(handle.getType() == PacketType.Play.Server.REL_ENTITY_MOVE_LOOK, "packet mismatch");
        this.handle = handle;
    }

    public EntityRelativeMoveLookPacket() {
        this(new PacketContainer(PacketType.Play.Server.REL_ENTITY_MOVE_LOOK));
    }

    @Nonnull
    public static Builder newBuilder(@Nonnull PacketWrapper<PacketContainer> wrapper) {
        return new Builder(wrapper.handle());
    }

    @Nonnull
    public static Builder newBuilder() {
        return new Builder();
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    public PacketContainer handle() {
        return this.handle;
    }

    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    /* renamed from: deepClone */
    public PacketWrapper<PacketContainer> deepClone() {
        return new EntityRelativeMoveLookPacket(this.handle.deepClone());
    }

    @Override // me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper
    @Nonnull
    public PacketType type() {
        return this.handle.getType();
    }

    @Override // java.lang.AutoCloseable
    public void close() {
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityRelativeMoveLookPacket$Builder.class */
    public static class Builder extends ProtocolPacketBuilder {
        private Builder(@Nonnull PacketContainer handle) {
            super(handle);
        }

        private Builder() {
            this(new PacketContainer(PacketType.Play.Server.REL_ENTITY_MOVE_LOOK));
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        public Builder copy() {
            return new Builder(this.handle.deepClone());
        }

        @Override // me.atilt.supplydrops.api.model.packet.PacketBuilder
        @Nonnull
        /* renamed from: buildPacket */
        public PacketWrapper<PacketContainer> buildPacket() {
            return new EntityRelativeMoveLookPacket(this.handle);
        }

        @Nonnull
        public Builder entityId(int id) {
            this.handle.getIntegers().write(0, Integer.valueOf(id));
            return this;
        }

        public Builder velocity(double x, double y, double z) {
            this.handle.getBooleans().writeSafely(2, true);
            ProtocolVersion runningVersion = ProtocolVersion.runningVersion();
            if (runningVersion.isAtLeast(ProtocolVersion.v1_14_R1)) {
                this.handle.getShorts().write(0, Short.valueOf((short) (x * 4096.0d))).write(1, Short.valueOf((short) (y * 4096.0d))).write(2, Short.valueOf((short) (z * 4096.0d)));
            } else if (runningVersion.isAtLeast(ProtocolVersion.v1_9_R1)) {
                this.handle.getIntegers().write(1, Integer.valueOf((int) (x * 4096.0d))).write(2, Integer.valueOf((int) (y * 4096.0d))).write(3, Integer.valueOf((int) (z * 4096.0d)));
            } else {
                this.handle.getBytes().write(0, Byte.valueOf((byte) (x * 32.0d))).write(1, Byte.valueOf((byte) (y * 32.0d))).write(2, Byte.valueOf((byte) (z * 32.0d)));
            }
            return this;
        }

        @Nonnull
        public Builder velocity(@Nonnull Vector vector) {
            return velocity(vector.getX(), vector.getY(), vector.getZ());
        }

        @Nonnull
        public Builder rotation(float yaw, float pitch) {
            this.handle.getBytes().write(0, Byte.valueOf((byte) ((yaw * 256.0f) / 360.0f))).write(1, Byte.valueOf((byte) ((pitch * 256.0f) / 360.0f)));
            this.handle.getBooleans().writeSafely(1, true);
            return this;
        }

        @Nonnull
        public Builder ground(boolean ground) {
            this.handle.getBooleans().write(0, Boolean.valueOf(ground));
            return this;
        }
    }
}

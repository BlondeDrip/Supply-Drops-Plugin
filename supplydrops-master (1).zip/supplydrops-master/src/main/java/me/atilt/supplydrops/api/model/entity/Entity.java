package me.atilt.supplydrops.api.model.entity;

import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.api.model.Navigable;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/entity/Entity.class */
public interface Entity extends Navigable {
    @Nonnull
    EntityType bukkitType();

    int id();

    @Nonnull
    UUID uuid();

    boolean valid();

    @Nullable
    Location location();

    void spawn(@Nonnull Location location);

    void despawn();
}

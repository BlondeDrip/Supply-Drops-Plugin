package me.atilt.supplydrops.listener;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.EnumWrappers;
import com.comphenix.protocol.wrappers.WrappedEnumEntityUseAction;
import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import me.atilt.supplydrops.model.registry.EntityTriplet;
import me.atilt.supplydrops.model.registry.ModelMap;
import me.atilt.supplydrops.supplydrop.ModelData;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.LazySupplier;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/listener/PacketListener.class */
public class PacketListener extends PacketAdapter {
    private final SupplyDropsPlugin plugin;

    public PacketListener(@Nonnull SupplyDropsPlugin plugin) {
        super(new PacketAdapter.AdapterParameteters().plugin(plugin).types(new PacketType[]{PacketType.Play.Client.USE_ENTITY}));
        this.plugin = plugin;
    }

    /* JADX WARN: Type inference failed for: r0v64, types: [me.atilt.supplydrops.api.model.entity.Entity] */
    public void onPacketReceiving(PacketEvent event) {
        int entityId;
        LazySupplier<AudiencedModel> handle;
        PacketContainer container = event.getPacket();
        if (((WrappedEnumEntityUseAction) container.getEnumEntityUseActions().read(0)).getAction() == EnumWrappers.EntityUseAction.ATTACK || (entityId = ((Integer) container.getIntegers().read(0)).intValue()) > -42000) {
            return;
        }
        ModelMap modelMap = this.plugin.getModelRegistry().modelMap();
        EntityTriplet binding = modelMap.getId(entityId);
        if (binding == null) {
            Iterator<Map.Entry<Integer, SupplyDrop>> it = this.plugin.supplyDropRegistry().iterator();
            while (it.hasNext()) {
                Map.Entry<Integer, SupplyDrop> supplyDropEntry = it.next();
                SupplyDrop supplyDrop = supplyDropEntry.getValue();
                ModelData modelData = supplyDrop.modelData();
                if (modelData != null && !modelData.empty() && (handle = modelData.getHandle()) != null) {
                    AudiencedModel audiencedModel = handle.get();
                    if (audiencedModel.rendered()) {
                        for (Limb limb : audiencedModel.limbs()) {
                            EntityRenderer<?> renderer = limb.renderer();
                            if (renderer.rendered() && renderer.entity().id() == entityId) {
                                EntityTriplet entityTriplet = new EntityTriplet(audiencedModel, limb, supplyDrop);
                                binding = entityTriplet;
                                modelMap.putId(entityId, entityTriplet);
                            }
                        }
                    }
                }
            }
        }
        if (binding != null) {
            Player player = event.getPlayer();
            EntityTriplet finalBinding = binding;
            Bukkit.getScheduler().runTask(this.plugin, () -> {
                SupplyDrop supplyDrop2 = finalBinding.getSupplyDrop();
                supplyDrop2.interaction().accept(player, finalBinding.getSupplyDrop());
            });
        }
    }
}

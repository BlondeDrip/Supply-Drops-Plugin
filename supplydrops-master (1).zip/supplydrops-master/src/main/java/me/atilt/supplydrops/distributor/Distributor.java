package me.atilt.supplydrops.distributor;

import java.util.function.Consumer;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.LocationAttempt;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/distributor/Distributor.class */
public interface Distributor<T> extends ConfigurationSerializable {
    @Nonnull
    DistributionParameters parameters();

    void parameters(@Nonnull DistributionParameters distributionParameters);

    void distribute(@Nonnull T t, int i, Consumer<LocationAttempt> consumer);
}

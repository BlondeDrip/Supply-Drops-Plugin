package me.atilt.supplydrops.command;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.supplydrop.ModelData;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/command/DebugCommand.class */
public class DebugCommand implements CommandExecutor {
    private final SupplyDropsPlugin plugin;

    public DebugCommand(SupplyDropsPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(@Nonnull CommandSender commandSender, @Nonnull Command command, @Nonnull String s, @Nonnull String[] strings) {
        if (!commandSender.hasPermission(Permission.COMMAND_ADMIN.name())) {
            commandSender.sendMessage("Unknown Command");
            return true;
        } else if (commandSender instanceof Entity) {
            for (SupplyDrop supplyDrop : this.plugin.supplyDropRegistry().all().values()) {
                ModelData modelData = supplyDrop.modelData();
                if (!modelData.empty()) {
                    AudiencedModel audiencedModel = modelData.getHandle().get();
                    audiencedModel.audience().addAll(Bukkit.getOnlinePlayers());
                }
            }
            return true;
        } else {
            return true;
        }
    }
}

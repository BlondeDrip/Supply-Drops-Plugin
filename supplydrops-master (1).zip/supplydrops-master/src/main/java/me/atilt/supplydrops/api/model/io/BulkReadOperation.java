package me.atilt.supplydrops.api.model.io;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiFunction;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/io/BulkReadOperation.class */
public class BulkReadOperation<T> {
    private BiFunction<Path, InputStream, T> readOperation;
    private final ConcurrentFileAccessor<T> fileAccessor;

    public BulkReadOperation(ConcurrentFileAccessor<T> fileAccessor) {
        this.fileAccessor = fileAccessor;
    }

    public BulkReadOperation<T> operation(BiFunction<Path, InputStream, T> readOperation) {
        this.readOperation = readOperation;
        return this;
    }

    public CompletableFuture<Collection<T>> applyAsync(Collection<Path> paths) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return apply(paths);
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
        }, this.fileAccessor.getExecutorService());
    }

    public Collection<T> apply(Collection<Path> paths) throws IOException {
        this.fileAccessor.getLock().lock();
        List<T> data = new ArrayList<>(paths.size());
        if (paths.isEmpty()) {
            this.fileAccessor.getLock().unlock();
            return data;
        }
        try {
            for (Path path : paths) {
                InputStream inputStream = Files.newInputStream(path, new OpenOption[0]);
                data.add(this.readOperation.apply(path, inputStream));
                if (inputStream != null) {
                    inputStream.close();
                }
            }
            return data;
        } finally {
            this.fileAccessor.getLock().unlock();
        }
    }
}

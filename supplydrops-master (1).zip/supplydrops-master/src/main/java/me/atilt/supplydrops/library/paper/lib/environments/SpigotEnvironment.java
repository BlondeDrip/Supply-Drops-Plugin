package me.atilt.supplydrops.library.paper.lib.environments;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/environments/SpigotEnvironment.class */
public class SpigotEnvironment extends CraftBukkitEnvironment {
    @Override // me.atilt.supplydrops.library.paper.lib.environments.CraftBukkitEnvironment, me.atilt.supplydrops.library.paper.lib.environments.Environment
    public String getName() {
        return "Spigot";
    }

    @Override // me.atilt.supplydrops.library.paper.lib.environments.Environment
    public boolean isSpigot() {
        return true;
    }
}

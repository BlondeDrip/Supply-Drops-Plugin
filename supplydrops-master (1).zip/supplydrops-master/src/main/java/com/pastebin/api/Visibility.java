package com.pastebin.api;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/Visibility.class */
public enum Visibility {
    PRIVATE(2, "Private"),
    UNLISTED(1, "Unlisted"),
    PUBLIC(0, "Public");
    
    private final int code;
    private final String name;

    Visibility(int code, String name) {
        this.code = code;
        this.name = name;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Visibility find(int code) {
        Visibility[] values;
        for (Visibility value : values()) {
            if (value.getCode() == code) {
                return value;
            }
        }
        return null;
    }

    public int getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}

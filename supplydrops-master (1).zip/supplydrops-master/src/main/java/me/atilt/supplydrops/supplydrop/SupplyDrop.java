package me.atilt.supplydrops.supplydrop;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.ColorData;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.distributor.Distributor;
import me.atilt.supplydrops.loot.LootTable;
import me.atilt.supplydrops.loot.probability.Probability;
import me.atilt.supplydrops.model.SupplyDropInteraction;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/supplydrop/SupplyDrop.class */
public interface SupplyDrop extends ConfigurationSerializable, AutoCloseable {
    int id();

    @Nonnull
    SupplyDropMeta meta();

    @Nonnull
    LootTable lootTable();

    void lootTable(@Nonnull LootTable lootTable);

    Distributor<SupplyDrop> distributor();

    void distributor(@Nonnull Distributor<SupplyDrop> distributor);

    @Nonnull
    Probability probability();

    void probability(@Nonnull Probability probability);

    int rolls();

    void rolls(int i);

    @Nonnull
    AudiencedModel model();

    @Nonnull
    ModelData modelData();

    void model(@Nonnull ModelData modelData);

    @Nonnull
    SupplyDropInteraction interaction();

    @Nullable
    LandingData landingData();

    void setLandingData(@Nullable LandingData landingData);

    @Nullable
    Ownership getPlayerOwned();

    void setPlayerOwned(@Nullable Ownership ownership);

    SupplyDrop newPlayer(@Nonnull Ownership ownership);

    @Nonnull
    ColorData colorData();

    void colorData(@Nonnull ColorData colorData);

    void updateColor();

    @Nullable
    LastSpawn lastSpawn();

    void lastSpawn(@Nullable LastSpawn lastSpawn);

    boolean canSpawn();

    void setCanSpawn(boolean z);

    void close();
}

package me.atilt.supplydrops.library.paper.lib.features.bedspawnlocation;

import java.util.concurrent.CompletableFuture;
import org.bukkit.Location;
import org.bukkit.entity.Player;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/bedspawnlocation/BedSpawnLocation.class */
public interface BedSpawnLocation {
    CompletableFuture<Location> getBedSpawnLocationAsync(Player player, boolean z);
}

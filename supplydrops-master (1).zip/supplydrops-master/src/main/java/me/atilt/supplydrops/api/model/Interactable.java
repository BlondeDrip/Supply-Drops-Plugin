package me.atilt.supplydrops.api.model;

import javax.annotation.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/Interactable.class */
public interface Interactable {
    @Nullable
    Interaction interaction();
}

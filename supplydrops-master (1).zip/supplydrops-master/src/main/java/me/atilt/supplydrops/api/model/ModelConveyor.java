package me.atilt.supplydrops.api.model;

import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.entity.Entity;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import me.atilt.supplydrops.api.model.schema.SerializedState;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/ModelConveyor.class */
public interface ModelConveyor<T> {
    @Nonnull
    Supplier<T> handle();

    @Nonnull
    Function<SerializedState, Supplier<EntitySchema<?>>> schemas();

    @Nonnull
    Function<Schema<? extends Entity>, EntityRenderer<?>> renderers();

    @Nonnull
    BiFunction<EntityRenderer<?>, Schema<? extends Entity>, Limb> limbs();

    @Nonnull
    Supplier<List<SerializedState>> defaultStates();
}

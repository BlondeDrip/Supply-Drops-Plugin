package me.atilt.supplydrops.library.paper.lib.environments;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/environments/CraftBukkitEnvironment.class */
public class CraftBukkitEnvironment extends Environment {
    @Override // me.atilt.supplydrops.library.paper.lib.environments.Environment
    public String getName() {
        return "CraftBukkit";
    }
}

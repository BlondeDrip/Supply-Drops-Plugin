package me.atilt.supplydrops.model.io.write;

import java.nio.file.Path;
import java.util.Collection;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.Model;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/io/write/ModelWriter.class */
public interface ModelWriter {
    @Nonnull
    Path target();

    void supply(@Nonnull Supplier<Collection<Model>> supplier);
}

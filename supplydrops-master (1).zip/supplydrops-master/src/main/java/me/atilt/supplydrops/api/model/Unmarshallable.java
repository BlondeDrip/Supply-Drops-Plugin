package me.atilt.supplydrops.api.model;

import java.io.IOException;
import javax.annotation.Nullable;
import me.atilt.supplydrops.api.model.schema.SerializedState;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/Unmarshallable.class */
public interface Unmarshallable<T extends SerializedState> {
    @Nullable
    T next() throws IOException;
}

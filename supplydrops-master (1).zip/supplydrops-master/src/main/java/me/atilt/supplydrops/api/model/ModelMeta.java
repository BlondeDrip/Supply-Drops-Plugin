package me.atilt.supplydrops.api.model;

import java.util.Collections;
import java.util.List;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/ModelMeta.class */
public final class ModelMeta {
    private final String name;
    private final String version;
    private final List<String> authors;

    public ModelMeta(String name, String version, List<String> authors) {
        this.name = name;
        this.version = version;
        this.authors = authors;
    }

    public String getName() {
        return this.name;
    }

    public String getVersion() {
        return this.version;
    }

    public List<String> getAuthors() {
        return Collections.unmodifiableList(this.authors);
    }
}

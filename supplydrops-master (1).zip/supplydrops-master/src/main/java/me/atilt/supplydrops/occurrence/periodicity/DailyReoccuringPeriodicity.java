package me.atilt.supplydrops.occurrence.periodicity;

import java.time.Duration;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.chrono.ChronoLocalDate;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/occurrence/periodicity/DailyReoccuringPeriodicity.class */
public final class DailyReoccuringPeriodicity extends ReoccurringPeriodicity {
    private final ZonedDateTime time;

    public DailyReoccuringPeriodicity(@Nonnull ZonedDateTime time) {
        super(Duration.ofDays(1L));
        this.time = time;
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.ReoccurringPeriodicity, me.atilt.supplydrops.occurrence.periodicity.Periodicity
    @Nullable
    public Instant origin() {
        return this.time.toInstant();
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.ReoccurringPeriodicity, me.atilt.supplydrops.occurrence.periodicity.Periodicity
    public Instant next() {
        return this.time.toInstant();
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.ReoccurringPeriodicity, me.atilt.supplydrops.occurrence.periodicity.Periodicity
    public boolean test() {
        return ZonedDateTime.now().toLocalDate().compareTo((ChronoLocalDate) this.time.toLocalDate()) >= 0;
    }
}

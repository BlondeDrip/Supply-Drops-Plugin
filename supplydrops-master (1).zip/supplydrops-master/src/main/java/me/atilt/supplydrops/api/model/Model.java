package me.atilt.supplydrops.api.model;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.limb.CompositeLimb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/Model.class */
public interface Model extends CompositeLimb, EntityRenderer {
    @Nonnull
    ModelMeta meta();
}

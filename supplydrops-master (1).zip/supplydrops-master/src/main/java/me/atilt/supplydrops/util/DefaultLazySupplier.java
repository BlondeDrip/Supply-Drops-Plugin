package me.atilt.supplydrops.util;

import java.util.function.Supplier;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/DefaultLazySupplier.class */
public final class DefaultLazySupplier<T> implements LazySupplier<T> {
    private final Supplier<T> handle;
    private T value;

    public DefaultLazySupplier(@Nonnull Supplier<T> handle) {
        this.handle = handle;
    }

    @Override // me.atilt.supplydrops.util.LazySupplier
    public Supplier<T> handle() {
        return this.handle;
    }

    @Override // java.util.function.Supplier
    public T get() {
        if (this.value == null) {
            this.value = this.handle.get();
        }
        return this.value;
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        try {
            if (this.value instanceof AutoCloseable) {
                try {
                    ((AutoCloseable) this.value).close();
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        } finally {
            this.value = null;
        }
    }
}

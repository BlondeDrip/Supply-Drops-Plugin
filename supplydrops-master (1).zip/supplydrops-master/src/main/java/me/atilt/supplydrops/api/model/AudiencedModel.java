package me.atilt.supplydrops.api.model;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.entity.living.packet.PacketEntity;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.packet.Audience;
import me.atilt.supplydrops.api.model.packet.protocollib.CompositeAudience;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import org.bukkit.Location;
import org.bukkit.entity.Player;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/AudiencedModel.class */
public abstract class AudiencedModel extends ModelEntity {
    private final CompositeAudience<Player> players = new CompositeAudience<>();

    @Nonnull
    public Audience<Player> audience() {
        return this.players;
    }

    @Override // me.atilt.supplydrops.api.model.ModelEntity, me.atilt.supplydrops.api.model.render.EntityRenderer
    public void render(@Nonnull Location location) {
        super.render(location);
        for (Limb limb : limbs()) {
            EntityRenderer<?> renderer = limb.renderer();
            Object entity = renderer.entity();
            if (entity instanceof PacketEntity) {
                this.players.bind((Audience<Player>) ((PacketEntity) entity).audience());
            }
        }
    }
}

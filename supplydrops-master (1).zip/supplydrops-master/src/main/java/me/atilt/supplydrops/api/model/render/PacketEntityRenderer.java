package me.atilt.supplydrops.api.model.render;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.EntitySchema;
import me.atilt.supplydrops.api.model.entity.living.packet.PacketEntity;
import org.bukkit.Location;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/render/PacketEntityRenderer.class */
public class PacketEntityRenderer implements EntityRenderer<PacketEntity<?>> {
    private final PacketEntity<?> entity;
    private final EntitySchema<PacketEntity<?>> schema;

    public PacketEntityRenderer(@Nonnull PacketEntity<?> entity, @Nonnull EntitySchema<PacketEntity<?>> schema) {
        this.entity = entity;
        this.schema = schema;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
    public PacketEntity<?> entity() {
        return this.entity;
    }

    @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
    public boolean rendered() {
        return this.entity.valid();
    }

    @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
    public void render(@Nonnull Location location) {
        this.entity.spawn(location);
        this.schema.apply(this.entity);
    }

    @Override // me.atilt.supplydrops.api.model.render.EntityRenderer
    public void unrender() {
        this.entity.despawn();
    }
}

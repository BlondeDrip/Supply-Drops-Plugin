package me.atilt.supplydrops.supplydrop;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.ColorData;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.api.model.entity.living.LivingEntity;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import me.atilt.supplydrops.distributor.DefaultDistributionParameters;
import me.atilt.supplydrops.distributor.Distributor;
import me.atilt.supplydrops.distributor.SupplyDropDistributor;
import me.atilt.supplydrops.loot.DefaultLootTable;
import me.atilt.supplydrops.loot.LootTable;
import me.atilt.supplydrops.loot.probability.Probability;
import me.atilt.supplydrops.loot.probability.StaticProbability;
import me.atilt.supplydrops.model.SupplyDropInteraction;
import me.atilt.supplydrops.registry.SupplyDropRegistry;
import me.atilt.supplydrops.supplydrop.Color;
import org.bukkit.Tag;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/supplydrop/DefaultSupplyDrop.class */
public final class DefaultSupplyDrop implements SupplyDrop {
    private final int id;
    private final SupplyDropMeta meta;
    private LootTable lootTable;
    private Distributor<SupplyDrop> distributor;
    private Probability probability;
    private int rolls;
    private ModelData modelData;
    private ColorData colorData;
    private LastSpawn lastSpawn;
    private boolean canSpawn = true;
    private final SupplyDropInteraction supplyDropInteraction = new SupplyDropInteraction();
    private LandingData landingData;
    private Ownership ownership;

    public DefaultSupplyDrop(int id, @Nonnull SupplyDropMeta meta, @Nonnull LootTable lootTable, @Nonnull Distributor<SupplyDrop> distributor, @Nonnull Probability probability, int rolls, @Nonnull ModelData model, @Nonnull ColorData colorData, @Nonnull LastSpawn lastSpawn) {
        this.rolls = 1;
        this.id = id;
        this.meta = meta;
        this.lootTable = lootTable;
        this.distributor = distributor;
        this.probability = probability;
        this.rolls = rolls;
        this.modelData = model;
        this.colorData = colorData;
        this.lastSpawn = lastSpawn;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nonnull
    public SupplyDropInteraction interaction() {
        return this.supplyDropInteraction;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nullable
    public LandingData landingData() {
        return this.landingData;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void setLandingData(@Nullable LandingData landingData) {
        this.landingData = landingData;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public int id() {
        return this.id;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nonnull
    public SupplyDropMeta meta() {
        return this.meta;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nonnull
    public LootTable lootTable() {
        return this.lootTable;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void lootTable(@Nonnull LootTable lootTable) {
        this.lootTable = lootTable;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public Distributor<SupplyDrop> distributor() {
        return this.distributor;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void distributor(@Nonnull Distributor<SupplyDrop> distributor) {
        this.distributor = distributor;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nonnull
    public Probability probability() {
        return this.probability;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void probability(@Nonnull Probability probability) {
        this.probability = probability;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public int rolls() {
        return this.rolls;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void rolls(int rolls) {
        this.rolls = rolls;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nonnull
    public AudiencedModel model() {
        return this.modelData.getHandle().get();
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nonnull
    public ModelData modelData() {
        return this.modelData;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void model(@Nonnull ModelData modelData) {
        this.modelData = modelData;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nullable
    public Ownership getPlayerOwned() {
        return this.ownership;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void setPlayerOwned(@Nullable Ownership ownership) {
        this.ownership = ownership;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public SupplyDrop newPlayer(@Nonnull Ownership ownership) {
        int id = SupplyDropRegistry.nextId();
        DefaultSupplyDrop created = new DefaultSupplyDrop(id, new SupplyDropMeta(meta().name(), Instant.now()), new DefaultLootTable(new ArrayList(this.lootTable.entries())), new SupplyDropDistributor(DefaultDistributionParameters.newBuilder().suitableLocations(new ArrayList(this.distributor.parameters().suitableLocations())).range(ownership.getLocation(), ownership.getLocation()).build()), new StaticProbability(BigDecimal.valueOf(1.0d)), 1, this.modelData.duplicate(), this.colorData.duplicate(), null);
        created.setPlayerOwned(ownership);
        SupplyDropsPlugin.self().supplyDropRegistry().register(id, (SupplyDrop) created);
        return created;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop, java.lang.AutoCloseable
    public void close() {
        if (this.supplyDropInteraction != null) {
            this.supplyDropInteraction.clear();
        }
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nonnull
    public ColorData colorData() {
        if (this.colorData == null) {
            ColorData defaultDisplay = ColorData.defaultDisplay();
            this.colorData = defaultDisplay;
            return defaultDisplay;
        }
        return this.colorData;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void colorData(@Nonnull ColorData colorData) {
        this.colorData = colorData;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void updateColor() {
        AudiencedModel audiencedModel;
        if (this.modelData.empty() || (audiencedModel = this.modelData.getHandle().get()) == null || !audiencedModel.rendered() || audiencedModel.getLocation() == null) {
            return;
        }
        for (Limb limb : audiencedModel.limbs()) {
            EntityRenderer<?> renderer = limb.renderer();
            if (renderer.rendered()) {
                Object entity = renderer.entity();
                if (entity instanceof LivingEntity) {
                    ItemStack[] equipment = ((LivingEntity) entity).getEquipment();
                    for (int i = 0; i < equipment.length; i++) {
                        ItemStack in = equipment[i];
                        if (in != null) {
                            if (Tag.WOOL.isTagged(in.getType())) {
                                equipment[i] = new ItemStack(colorData().getParachuteColor().get(Color.BlockType.WOOL));
                            }
                            if (in.getType().name().contains("CONCRETE")) {
                                equipment[i] = new ItemStack(colorData().getBoxColor().get(Color.BlockType.CONCRETE));
                            }
                        }
                    }
                    ((LivingEntity) entity).setEquipment(equipment);
                }
            }
        }
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    @Nullable
    public LastSpawn lastSpawn() {
        return this.lastSpawn;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void lastSpawn(@Nullable LastSpawn lastSpawn) {
        this.lastSpawn = lastSpawn;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public boolean canSpawn() {
        return this.canSpawn;
    }

    @Override // me.atilt.supplydrops.supplydrop.SupplyDrop
    public void setCanSpawn(boolean canSpawn) {
        this.canSpawn = canSpawn;
    }

    @Nonnull
    public Map<String, Object> serialize() {
        Map<String, Object> tree = new HashMap<>(6, 1.02f);
        tree.put("id", Integer.valueOf(this.id));
        tree.put("meta", this.meta);
        tree.put("loot-table", this.lootTable);
        tree.put("distributor", this.distributor);
        tree.put("probability", this.probability);
        tree.put("rolls", Integer.valueOf(this.rolls));
        tree.put("model", this.modelData);
        tree.put("color", this.colorData);
        tree.put("lastSpawn", this.lastSpawn);
        return tree;
    }

    @Nonnull
    public static SupplyDrop deserialize(@Nonnull Map<String, Object> tree) {
        return new DefaultSupplyDrop(((Number) tree.get("id")).intValue(), (SupplyDropMeta) tree.get("meta"), (LootTable) tree.get("loot-table"), (Distributor) tree.get("distributor"), (Probability) tree.get("probability"), tree.containsKey("rolls") ? ((Number) tree.get("rolls")).intValue() : 1, (ModelData) tree.get("model"), (ColorData) tree.get("color"), (LastSpawn) tree.get("last-spawn"));
    }
}

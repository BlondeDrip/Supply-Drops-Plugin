package com.pastebin.api.request;

import java.util.HashMap;
import java.util.Map;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/request/ShowPasteRequest.class */
public class ShowPasteRequest implements Request {
    private final String pasteKey;

    private ShowPasteRequest(String pasteKey) {
        this.pasteKey = pasteKey;
    }

    public static ShowPasteRequest pasteKey(String pasteKey) {
        return new Builder(pasteKey).build();
    }

    @Override // com.pastebin.api.request.Request
    public Map<String, String> getParameters() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("api_paste_key", this.pasteKey);
        parameters.put("api_option", "show_paste");
        return parameters;
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/request/ShowPasteRequest$Builder.class */
    public static class Builder {
        private final String pasteKey;

        public Builder(String pasteKey) {
            this.pasteKey = pasteKey;
        }

        public ShowPasteRequest build() {
            return new ShowPasteRequest(this.pasteKey);
        }
    }
}

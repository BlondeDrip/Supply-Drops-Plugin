package me.atilt.supplydrops.library.paper.lib.environments;

import me.atilt.supplydrops.library.paper.lib.features.asyncchunks.AsyncChunksPaper_13;
import me.atilt.supplydrops.library.paper.lib.features.asyncchunks.AsyncChunksPaper_15;
import me.atilt.supplydrops.library.paper.lib.features.asyncchunks.AsyncChunksPaper_9_12;
import me.atilt.supplydrops.library.paper.lib.features.asyncteleport.AsyncTeleportPaper;
import me.atilt.supplydrops.library.paper.lib.features.asyncteleport.AsyncTeleportPaper_13;
import me.atilt.supplydrops.library.paper.lib.features.bedspawnlocation.BedSpawnLocationPaper;
import me.atilt.supplydrops.library.paper.lib.features.blockstatesnapshot.BlockStateSnapshotOptionalSnapshots;
import me.atilt.supplydrops.library.paper.lib.features.chunkisgenerated.ChunkIsGeneratedApiExists;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.HumanEntity;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/environments/PaperEnvironment.class */
public class PaperEnvironment extends SpigotEnvironment {
    public PaperEnvironment() {
        if (isVersion(13, 1)) {
            this.asyncChunksHandler = new AsyncChunksPaper_13();
            this.asyncTeleportHandler = new AsyncTeleportPaper_13();
        } else if (isVersion(9) && !isVersion(13)) {
            this.asyncChunksHandler = new AsyncChunksPaper_9_12();
            this.asyncTeleportHandler = new AsyncTeleportPaper();
        }
        if (isVersion(12)) {
            this.isGeneratedHandler = new ChunkIsGeneratedApiExists();
            this.blockStateSnapshotHandler = new BlockStateSnapshotOptionalSnapshots();
        }
        if (isVersion(15, 2)) {
            try {
                World.class.getDeclaredMethod("getChunkAtAsyncUrgently", Location.class);
                this.asyncChunksHandler = new AsyncChunksPaper_15();
                HumanEntity.class.getDeclaredMethod("getPotentialBedLocation", new Class[0]);
                this.bedSpawnLocationHandler = new BedSpawnLocationPaper();
            } catch (NoSuchMethodException e) {
            }
        }
    }

    @Override // me.atilt.supplydrops.library.paper.lib.environments.SpigotEnvironment, me.atilt.supplydrops.library.paper.lib.environments.CraftBukkitEnvironment, me.atilt.supplydrops.library.paper.lib.environments.Environment
    public String getName() {
        return "Paper";
    }

    @Override // me.atilt.supplydrops.library.paper.lib.environments.Environment
    public boolean isPaper() {
        return true;
    }
}

package me.atilt.supplydrops.library.paper.lib.features.asyncteleport;

import java.util.concurrent.CompletableFuture;
import me.atilt.supplydrops.library.paper.lib.PaperLib;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.event.player.PlayerTeleportEvent;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/asyncteleport/AsyncTeleportPaper.class */
public class AsyncTeleportPaper implements AsyncTeleport {
    @Override // me.atilt.supplydrops.library.paper.lib.features.asyncteleport.AsyncTeleport
    public CompletableFuture<Boolean> teleportAsync(Entity entity, Location location, PlayerTeleportEvent.TeleportCause cause) {
        int x = location.getBlockX() >> 4;
        int z = location.getBlockZ() >> 4;
        return PaperLib.getChunkAtAsyncUrgently(location.getWorld(), x, z, true).thenApply(chunk -> {
            return Boolean.valueOf(entity.teleport(location, cause));
        });
    }
}

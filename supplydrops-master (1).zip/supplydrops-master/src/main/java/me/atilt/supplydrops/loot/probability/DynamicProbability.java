package me.atilt.supplydrops.loot.probability;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.util.Randoms;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/loot/probability/DynamicProbability.class */
public final class DynamicProbability implements Probability {
    private final BigDecimal min;
    private final BigDecimal max;

    public DynamicProbability(@Nonnegative BigDecimal min, @Nonnegative BigDecimal max) {
        this.min = min.compareTo(max) < 0 ? min : max;
        this.max = min.compareTo(max) < 0 ? max : min;
    }

    public BigDecimal average() {
        return this.min.add(this.max).divide(new BigDecimal("2.0"), 2, RoundingMode.CEILING);
    }

    public BigDecimal min() {
        return this.min;
    }

    public BigDecimal max() {
        return this.max;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.loot.probability.Probability, java.util.function.Supplier
    public BigDecimal get() {
        return Randoms.get(this.min, this.max, 2, RoundingMode.CEILING);
    }

    @Override // me.atilt.supplydrops.loot.probability.Probability
    public boolean test() {
        BigDecimal probability = get();
        return probability.compareTo(BigDecimal.ZERO) > 0 && ThreadLocalRandom.current().nextDouble() <= probability.doubleValue();
    }

    @Override // java.lang.Comparable
    public int compareTo(@Nonnull Probability other) {
        if (other instanceof DynamicProbability) {
            return ((DynamicProbability) other).average().compareTo(average());
        }
        return other.get().compareTo(average());
    }

    @Nonnull
    public Map<String, Object> serialize() {
        Map<String, Object> tree = new HashMap<>(2, 1.5f);
        tree.put("min", this.min.toString());
        tree.put("max", this.max.toString());
        return tree;
    }

    @Nonnull
    public static Probability deserialize(@Nonnull Map<String, Object> tree) {
        return new DynamicProbability(new BigDecimal((String) tree.get("min")), new BigDecimal((String) tree.get("max")));
    }
}

package me.atilt.supplydrops.api.model.io;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiFunction;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/io/ReadOperation.class */
public class ReadOperation<T> {
    private BiFunction<Path, InputStream, T> readFunction;
    private CompressionType compressionType = CompressionType.NONE;
    private final ConcurrentFileAccessor<T> fileAccessor;

    public ReadOperation(ConcurrentFileAccessor<T> fileAccessor) {
        this.fileAccessor = fileAccessor;
    }

    public ReadOperation<T> compressionType(CompressionType compressionType) {
        this.compressionType = compressionType;
        return this;
    }

    public ReadOperation<T> operation(BiFunction<Path, InputStream, T> readFunction) {
        this.readFunction = readFunction;
        return this;
    }

    @Nonnull
    public CompletableFuture<T> applyAsync(Path path, InputStream inputStream) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return apply(path, inputStream);
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
        }, this.fileAccessor.getExecutorService());
    }

    public T apply(Path path, InputStream inputStream) throws IOException {
        this.fileAccessor.getLock().lock();
        try {
            InputStream in = this.compressionType.getDecompressionStream(inputStream);
            T apply = this.readFunction.apply(path, in);
            if (in != null) {
                in.close();
            }
            return apply;
        } finally {
            this.fileAccessor.getLock().unlock();
        }
    }
}

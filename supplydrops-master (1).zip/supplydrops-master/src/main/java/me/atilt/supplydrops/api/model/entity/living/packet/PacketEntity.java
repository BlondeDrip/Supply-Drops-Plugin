package me.atilt.supplydrops.api.model.entity.living.packet;

import java.util.UUID;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.entity.Entity;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.PacketAudience;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/entity/living/packet/PacketEntity.class */
public abstract class PacketEntity<P> implements Entity {
    private final EntityType type;
    private final int id;
    private final UUID uuid;
    protected Location location;
    protected Vector velocity = new Vector();
    protected boolean valid;
    private final PacketAudience<Player, P> audience;

    public PacketEntity(@Nonnull EntityType type, int id, @Nonnull UUID uuid, @Nonnull PacketAudience<Player, P> audience) {
        this.type = type;
        this.id = id;
        this.uuid = uuid;
        this.audience = audience;
    }

    @Nonnull
    public PacketAudience<Player, P> audience() {
        return this.audience;
    }

    @Override // me.atilt.supplydrops.api.model.entity.Entity
    @Nonnull
    public EntityType bukkitType() {
        return this.type;
    }

    @Override // me.atilt.supplydrops.api.model.entity.Entity
    public int id() {
        return this.id;
    }

    @Override // me.atilt.supplydrops.api.model.entity.Entity
    @Nonnull
    public UUID uuid() {
        return this.uuid;
    }

    @Override // me.atilt.supplydrops.api.model.entity.Entity
    public boolean valid() {
        return this.valid;
    }

    @Override // me.atilt.supplydrops.api.model.entity.Entity
    @Nullable
    public Location location() {
        return this.location;
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public Vector getVelocity() {
        return this.velocity;
    }
}

package me.atilt.supplydrops.api.model;

import javax.annotation.Nonnull;
import org.bukkit.Location;
import org.bukkit.util.Vector;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/Navigable.class */
public interface Navigable {
    void move(double d, double d2, double d3);

    void move(double d, double d2, double d3, float f, float f2);

    void teleport(@Nonnull Location location);

    void rotate(@Nonnull Location location);

    void rotate(float f);

    void setVelocity(@Nonnull Vector vector);

    Vector getVelocity();
}

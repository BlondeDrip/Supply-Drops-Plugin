package me.atilt.supplydrops.supplydrop;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.util.Text;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/supplydrop/SupplyDropMeta.class */
public final class SupplyDropMeta implements ConfigurationSerializable {
    private String name;
    private final Instant created;

    public SupplyDropMeta(@Nonnull String name, @Nonnull Instant created) {
        this.name = name;
        this.created = created;
    }

    @Nonnull
    public String name() {
        return this.name;
    }

    public void name(@Nonnull String name) {
        this.name = name;
    }

    @Nonnull
    public Instant created() {
        return this.created;
    }

    @Nonnull
    public Map<String, Object> serialize() {
        Map<String, Object> tree = new HashMap<>(2);
        tree.put("name", Text.replace(this.name, Character.toString((char) 167), "&"));
        tree.put("created", Long.valueOf(this.created.toEpochMilli()));
        return tree;
    }

    @Nonnull
    public static SupplyDropMeta deserialize(@Nonnull Map<String, Object> tree) {
        return new SupplyDropMeta((String) tree.get("name"), Instant.ofEpochMilli(((Number) tree.get("created")).longValue()));
    }
}

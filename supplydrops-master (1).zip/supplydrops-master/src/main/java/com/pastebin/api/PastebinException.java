package com.pastebin.api;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/PastebinException.class */
public class PastebinException extends RuntimeException {
    public PastebinException(String message) {
        super(message);
    }

    public PastebinException(String message, Throwable cause) {
        super(message, cause);
    }
}

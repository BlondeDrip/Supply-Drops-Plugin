package me.atilt.supplydrops.util;

import java.math.BigDecimal;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/BigDecimals.class */
public class BigDecimals {
    private static final BigDecimal ONE_HUNDRED = BigDecimal.valueOf(100.0d);

    @Nonnull
    public static BigDecimal oneHundred() {
        return ONE_HUNDRED;
    }

    public static BigDecimal max(BigDecimal a, BigDecimal b) {
        return a.compareTo(b) >= 0 ? a : b;
    }

    public static BigDecimal min(BigDecimal a, BigDecimal b) {
        return a.compareTo(b) <= 0 ? a : b;
    }
}

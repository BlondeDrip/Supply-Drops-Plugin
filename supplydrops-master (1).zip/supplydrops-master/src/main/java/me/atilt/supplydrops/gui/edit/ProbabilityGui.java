package me.atilt.supplydrops.gui.edit;

import java.math.BigDecimal;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.gui.SupplyDropGui;
import me.atilt.supplydrops.gui.edit.LootTableGui;
import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.Icon;
import me.atilt.supplydrops.loot.probability.DynamicProbability;
import me.atilt.supplydrops.loot.probability.Probability;
import me.atilt.supplydrops.loot.probability.StaticProbability;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.ItemStackBuilder;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/ProbabilityGui.class */
public class ProbabilityGui extends Gui {
    private final SupplyDrop supplyDrop;
    private Integer model;
    private final LootTableGui.LootEntryGui.ProbabilityAdjuster probabilityAdjuster;
    private final SupplyDropsPlugin plugin;

    public ProbabilityGui(@Nonnull Player player, @Nonnull SupplyDrop supplyDrop, Integer model, @Nonnull SupplyDropsPlugin plugin) {
        super(player, "supplydrops-probability-gui", Text.color("Editing &lprobability&r for " + supplyDrop.meta().name()), 6);
        this.model = null;
        this.supplyDrop = supplyDrop;
        Probability probability = supplyDrop.probability();
        if (probability instanceof DynamicProbability) {
            this.probabilityAdjuster = new LootTableGui.LootEntryGui.ProbabilityAdjuster(true, ((DynamicProbability) probability).min(), ((DynamicProbability) probability).max(), this.supplyDrop.rolls());
        } else {
            this.probabilityAdjuster = new LootTableGui.LootEntryGui.ProbabilityAdjuster(false, probability.get(), BigDecimal.ZERO, this.supplyDrop.rolls());
        }
        this.model = model;
        this.plugin = plugin;
    }

    @Override // mc.obliviate.inventory.Gui
    public void onOpen(InventoryOpenEvent event) {
        fillRow(SupplyDropGui.PLACEHOLDER, 4);
        addItem(49, new Icon(Material.BARRIER).setName(Text.color("&cBack to editor")).onClick(clickEvent -> {
            new SupplyDropEditorGui(this.player, this.supplyDrop, this.model, this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        build();
    }

    @Override // mc.obliviate.inventory.Gui
    public void onClose(InventoryCloseEvent event) {
        Probability probability = this.probabilityAdjuster.dynamic() ? new DynamicProbability(this.probabilityAdjuster.getMin(), this.probabilityAdjuster.getMax()) : new StaticProbability(this.probabilityAdjuster.getMin());
        this.supplyDrop.probability(probability);
        this.supplyDrop.rolls(this.probabilityAdjuster.rolls());
    }

    private void build() {
        if (!this.probabilityAdjuster.dynamic()) {
            Icon name = new Icon(Material.EXPERIENCE_BOTTLE).setName(Text.color("&aProbability"));
            String[] strArr = new String[9];
            strArr[0] = Text.color("&7Determines the chance of the supply drop spawning");
            strArr[1] = Text.color("&7in the world. Supply drop probabilities are independent of");
            strArr[2] = Text.color("&7one another.");
            strArr[3] = " ";
            strArr[4] = Text.color("&aCurrent probability: &e" + (this.probabilityAdjuster.dynamic() ? this.probabilityAdjuster.getMin().multiply(BigDecimal.valueOf(100.0d)) + "% to " + this.probabilityAdjuster.getMax().multiply(BigDecimal.valueOf(100.0d)) + "%" : this.probabilityAdjuster.getMin().multiply(BigDecimal.valueOf(100.0d)) + "%"));
            strArr[5] = " ";
            strArr[6] = Text.color("&aMode: &e" + this.probabilityAdjuster);
            strArr[7] = " ";
            strArr[8] = Text.color("&eLeft-Click &ato change modes");
            addItem(11, name.setLore(strArr).onClick(clickEvent -> {
                this.probabilityAdjuster.flip();
                build();
                this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
            }));
        } else {
            Icon name2 = new Icon(Material.EXPERIENCE_BOTTLE).setName(Text.color("&aProbability"));
            String[] strArr2 = new String[11];
            strArr2[0] = Text.color("&7Determines the chance of the supply drop spawning");
            strArr2[1] = Text.color("&7in the world. Supply drop probabilities are independent of");
            strArr2[2] = Text.color("&7one another.");
            strArr2[3] = " ";
            strArr2[4] = Text.color("&aCurrent probability: &e" + (this.probabilityAdjuster.dynamic() ? this.probabilityAdjuster.getMin().multiply(BigDecimal.valueOf(100.0d)) + "% to " + this.probabilityAdjuster.getMax().multiply(BigDecimal.valueOf(100.0d)) + "%" : this.probabilityAdjuster.getMin().multiply(BigDecimal.valueOf(100.0d)) + "%"));
            strArr2[5] = " ";
            strArr2[6] = Text.color("&aBound: &e") + (this.probabilityAdjuster.lowerBound() ? "Low" : "High");
            strArr2[7] = Text.color("&aMode: &e" + this.probabilityAdjuster);
            strArr2[8] = " ";
            strArr2[9] = Text.color("&eShift + Left-Click &ato change bounds.");
            strArr2[10] = Text.color("&eLeft-Click &ato change modes");
            addItem(11, name2.setLore(strArr2).onClick(clickEvent2 -> {
                if (clickEvent2.isLeftClick() && clickEvent2.isShiftClick()) {
                    this.probabilityAdjuster.flipBound();
                } else {
                    this.probabilityAdjuster.flip();
                }
                this.player.playSound(this.player.getLocation(), Sound.ENTITY_BEE_STING, 0.1f, 0.1f);
                build();
            }));
        }
        addItem(19, new Icon(Material.OAK_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&d±0.01%")).setLore(Text.color("&eLeft-Click&7 to add &a+0.01%&7 to the probability"), Text.color("&eRight-Click&7 to remove &c-0.01%&7 from the probability.")).onClick(clickEvent3 -> {
            BigDecimal amount = BigDecimal.valueOf(clickEvent3.isLeftClick() ? 1.0E-4d : -1.0E-4d);
            this.probabilityAdjuster.adjustBounds(amount);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent3.isLeftClick() ? 1.87f : 0.8f);
        }));
        addItem(20, new Icon(Material.STONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&d±0.1%")).setLore(Text.color("&eLeft-Click&7 to add &a+0.1%&7 to the probability"), Text.color("&eRight-Click&7 to remove &c-0.1%&7 from the probability.")).onClick(clickEvent4 -> {
            BigDecimal amount = BigDecimal.valueOf(clickEvent4.isLeftClick() ? 0.001d : -0.001d);
            this.probabilityAdjuster.adjustBounds(amount);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent4.isLeftClick() ? 1.87f : 0.8f);
        }));
        addItem(21, new Icon(Material.POLISHED_BLACKSTONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&d±1%")).setLore(Text.color("&eLeft-Click&7 to add &a+1.0%&7 to the probability"), Text.color("&eRight-Click&7 to remove &c-1.0%&7 from the probability.")).onClick(clickEvent5 -> {
            BigDecimal amount = BigDecimal.valueOf(clickEvent5.isLeftClick() ? 0.01d : -0.01d);
            this.probabilityAdjuster.adjustBounds(amount);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent5.isLeftClick() ? 1.87f : 0.8f);
        }));
        addItem(15, new Icon(Material.CONDUIT).setName(Text.color("&aRolls")).setLore(Text.color("&7Adjust rolls of the item. The roll represents"), Text.color("&7a multiplier for the probability."), " ", Text.color("&bFormula: &dprobability &5* &droll = final probability"), " ", Text.color("&aRolls: &e" + this.probabilityAdjuster.rolls())));
        addItem(24, new Icon(Material.OAK_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&a+1")).setLore(Text.color("&eLeft-Click&7 to add &a+1&7 to the rolls."), Text.color("&eRight-Click&7 to remove &c-1&7 from the rolls.")).onClick(clickEvent6 -> {
            int amount = clickEvent6.isLeftClick() ? 1 : -1;
            this.probabilityAdjuster.adjustRoll(amount);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent6.isLeftClick() ? 1.87f : 0.8f);
        }));
    }
}

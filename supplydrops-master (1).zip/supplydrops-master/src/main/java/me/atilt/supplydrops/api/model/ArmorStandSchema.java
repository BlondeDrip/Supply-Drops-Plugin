package me.atilt.supplydrops.api.model;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.entity.type.ArmorStand;
import me.atilt.supplydrops.api.model.util.Vector3d;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.EulerAngle;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/ArmorStandSchema.class */
public class ArmorStandSchema implements EntitySchema<ArmorStand> {
    private final boolean invisible;
    private final boolean small;
    private final EulerAngle[] angles;
    private final float yaw;
    private final ItemStack[] equipment;
    private Vector3d offset;

    public ArmorStandSchema(boolean invisible, boolean small, EulerAngle[] angles, float yaw, ItemStack[] equipment) {
        this.invisible = invisible;
        this.small = small;
        this.angles = angles;
        this.yaw = yaw;
        this.equipment = equipment;
    }

    public ArmorStandSchema(ArmorStandMockData data) {
        this(data.getInvisible(), data.getSmall(), new EulerAngle[]{new EulerAngle(data.head[0], data.head[1], data.head[2]), new EulerAngle(data.body[0], data.body[1], data.body[2]), new EulerAngle(data.leftArm[0], data.leftArm[1], data.leftArm[2]), new EulerAngle(data.rightArm[0], data.rightArm[1], data.rightArm[2]), new EulerAngle(data.leftLeg[0], data.leftLeg[1], data.leftLeg[2]), new EulerAngle(data.rightLeg[0], data.rightLeg[1], data.rightLeg[2]), new EulerAngle(data.offset[0], data.offset[1], data.offset[2])}, data.yaw, data.toBukkitItems());
    }

    public boolean isInvisible() {
        return this.invisible;
    }

    public boolean isSmall() {
        return this.small;
    }

    public ItemStack[] getEquipment() {
        return this.equipment;
    }

    public float getYaw() {
        return this.yaw;
    }

    public EulerAngle[] getAngles() {
        return this.angles;
    }

    public Vector3d getOffset() {
        return this.offset;
    }

    @Override // me.atilt.supplydrops.api.model.EntitySchema
    @Nonnull
    public EntityType bukkitType() {
        return EntityType.ARMOR_STAND;
    }

    @Override // me.atilt.supplydrops.api.model.Schema
    @Nonnull
    /* renamed from: clone */
    public Schema<ArmorStand> clone() {
        return new ArmorStandSchema(this.invisible, this.small, this.angles, this.yaw, this.equipment);
    }

    @Override // java.util.function.Consumer
    public void accept(ArmorStand armorStand) {
        this.offset = new Vector3d(this.angles[6].getX(), this.angles[6].getY(), this.angles[6].getZ());
        armorStand.setEquipment(this.equipment);
        Location location = armorStand.location();
        location.add(this.angles[6].getX(), this.angles[6].getY(), this.angles[6].getZ());
        location.setYaw(this.yaw);
        armorStand.teleport(location);
        for (int angle = 0; angle < this.angles.length - 1; angle++) {
            armorStand.setPose(ArmorStand.Pose.VALUES[angle], this.angles[angle]);
        }
        armorStand.setInvisible(this.invisible);
        armorStand.setSmall(this.small);
    }
}

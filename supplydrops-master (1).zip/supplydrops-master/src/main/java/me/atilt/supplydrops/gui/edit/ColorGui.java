package me.atilt.supplydrops.gui.edit;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.gui.SupplyDropGui;
import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.Icon;
import mc.obliviate.inventory.pagination.PaginationManager;
import me.atilt.supplydrops.supplydrop.Color;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.ItemStackBuilder;
import me.atilt.supplydrops.util.Text;
import org.apache.commons.lang3.text.WordUtils;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryOpenEvent;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/ColorGui.class */
public class ColorGui extends Gui {
    private final SupplyDrop supplyDrop;
    private Integer model;
    private boolean parachute;
    private final SupplyDropsPlugin plugin;
    private final PaginationManager pagination;

    public ColorGui(@Nonnull Player player, @Nonnull SupplyDrop supplyDrop, Integer model, @Nonnull SupplyDropsPlugin plugin) {
        super(player, "supplydrops-color-gui", Text.color("Editing &ldisplay&r for " + supplyDrop.meta().name()), 6);
        this.model = null;
        this.pagination = new PaginationManager(this);
        this.supplyDrop = supplyDrop;
        this.model = model;
        this.plugin = plugin;
        this.pagination.registerPageSlotsBetween(19, 25);
    }

    @Override // mc.obliviate.inventory.Gui
    public void onOpen(InventoryOpenEvent event) {
        fillRow(SupplyDropGui.PLACEHOLDER, 4);
        addItem(49, new Icon(Material.BARRIER).setName(Text.color("&cBack to editor")).onClick(clickEvent -> {
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
            new SupplyDropEditorGui(this.player, this.supplyDrop, this.model, this.plugin).open();
        }));
        build();
    }

    private void build() {
        Color[] colorArr;
        this.pagination.getItems().clear();
        addItem(13, new Icon(this.parachute ? Material.ELYTRA : Material.BARREL).setName(Text.color(this.parachute ? "&aParachute" : "&aCrate")).setLore(Text.color("&7Switch between the supply crate's parachute"), Text.color("&7and crate."), " ", Text.color("&eClick to edit!")).onClick(clickEvent -> {
            this.parachute = !this.parachute;
            this.pagination.setPage(0);
            build();
        }));
        for (Color color : Color.TYPES) {
            Icon icon = new Icon(color.get(this.parachute ? Color.BlockType.WOOL : Color.BlockType.CONCRETE)).hideFlags(ItemStackBuilder.flags()).setName(Text.color(color.java(), capitalize(color.name()))).onClick(clickEvent2 -> {
                if (this.parachute) {
                    this.supplyDrop.colorData().setParachuteColor(color);
                } else {
                    this.supplyDrop.colorData().setBoxColor(color);
                }
                this.supplyDrop.updateColor();
                this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
                build();
            });
            if (this.parachute) {
                if (this.supplyDrop.colorData().getParachuteColor() == color) {
                    icon.enchant(Enchantment.DURABILITY, 1);
                    icon.setLore(Text.color("&aSelected!"));
                } else {
                    icon.getItem().removeEnchantment(Enchantment.DURABILITY);
                    icon.setLore(Text.color("&eClick to select!"));
                }
            } else if (this.supplyDrop.colorData().getBoxColor() == color) {
                icon.enchant(Enchantment.DURABILITY, 1);
                icon.setLore(Text.color("&aSelected!"));
            } else {
                icon.getItem().removeEnchantment(Enchantment.DURABILITY);
                icon.setLore(Text.color("&eClick to select!"));
            }
            this.pagination.addItem(icon);
        }
        updateNavigation();
    }

    private String capitalize(String text) {
        return WordUtils.capitalizeFully(text.replace("_", " "));
    }

    private void updateNavigation() {
        this.pagination.update();
        if (this.pagination.getItems().size() > 7) {
            addItem(18, new Icon(Material.ARROW).setName(Text.color("&aPrevious Colors")).onClick(clickEvent -> {
                this.pagination.goPreviousPage();
                updateNavigation();
                this.player.playSound(this.player.getLocation(), Sound.BLOCK_MOSS_CARPET_HIT, 0.6f, 0.0f);
            }));
            addItem(26, new Icon(Material.ARROW).setName(Text.color("&aNext Colors")).onClick(clickEvent2 -> {
                this.pagination.goNextPage();
                updateNavigation();
                this.player.playSound(this.player.getLocation(), Sound.BLOCK_MOSS_CARPET_HIT, 0.6f, 0.0f);
            }));
            return;
        }
        addItem(18, (Icon) null);
        addItem(26, (Icon) null);
    }
}

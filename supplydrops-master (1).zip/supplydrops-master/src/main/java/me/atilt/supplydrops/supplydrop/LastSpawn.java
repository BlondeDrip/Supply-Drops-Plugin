package me.atilt.supplydrops.supplydrop;

import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.Map;
import javax.annotation.Nonnull;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/supplydrop/LastSpawn.class */
public class LastSpawn implements ConfigurationSerializable {
    private final Instant last;

    public LastSpawn(Instant last) {
        this.last = last;
    }

    @Nonnull
    public Instant getLast() {
        return this.last;
    }

    @Nonnull
    public Duration sinceLast() {
        return Duration.between(this.last, Instant.now());
    }

    @Nonnull
    public Map<String, Object> serialize() {
        return Collections.singletonMap("last", Long.valueOf(this.last.toEpochMilli()));
    }

    @Nonnull
    public static LastSpawn deserialize(@Nonnull Map<String, Object> tree) {
        return new LastSpawn(Instant.ofEpochMilli(((Number) tree.get("last")).longValue()));
    }
}

package me.atilt.supplydrops.library.paper.lib.features.asyncteleport;

import java.util.concurrent.CompletableFuture;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.event.player.PlayerTeleportEvent;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/asyncteleport/AsyncTeleportSync.class */
public class AsyncTeleportSync implements AsyncTeleport {
    @Override // me.atilt.supplydrops.library.paper.lib.features.asyncteleport.AsyncTeleport
    public CompletableFuture<Boolean> teleportAsync(Entity entity, Location location, PlayerTeleportEvent.TeleportCause cause) {
        return CompletableFuture.completedFuture(Boolean.valueOf(entity.teleport(location, cause)));
    }
}

package me.atilt.supplydrops.util;

import javax.annotation.Nonnull;
import org.bukkit.util.Vector;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Axis.class */
public enum Axis {
    X,
    Y,
    Z;
    
    private static final Axis[] THREE_DIMENSIONAL = {X, Y, Z};
    private static final Axis[] TWO_DIMENSIONAL = {X, Z};

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Axis$Dimension.class */
    public enum Dimension {
        TWO,
        THREE
    }

    public void modify(@Nonnull Vector vector, double amount) {
        switch (this) {
            case X:
                vector.setX(vector.getX() + amount);
                return;
            case Y:
                vector.setY(vector.getY() + amount);
                return;
            case Z:
                vector.setZ(vector.getZ() + amount);
                return;
            default:
                return;
        }
    }

    @Nonnull
    public Axis cycle(Dimension dimension) {
        if (dimension == Dimension.TWO) {
            switch (this) {
                case X:
                    return Z;
                case Z:
                    return X;
            }
        }
        switch (this) {
            case X:
                return Y;
            case Y:
                return Z;
            case Z:
                return X;
        }
        return X;
    }

    @Override // java.lang.Enum
    public String toString() {
        return super.toString() + " axis";
    }
}

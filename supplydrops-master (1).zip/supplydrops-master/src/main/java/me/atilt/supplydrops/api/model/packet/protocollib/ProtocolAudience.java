package me.atilt.supplydrops.api.model.packet.protocollib;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketContainer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import me.atilt.supplydrops.api.model.Builder;
import me.atilt.supplydrops.api.model.TransformablePacketWrapper;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.EntityDestroyPacket;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.PacketAudience;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/ProtocolAudience.class */
public final class ProtocolAudience implements PacketAudience<Player, PacketContainer> {
    private final Set<Player> members;
    private final Map<PacketType, PacketWrapper<PacketContainer>> typedPackets;

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/ProtocolAudience$Builder.class */
    public static class Builder implements me.atilt.supplydrops.api.model.Builder<ProtocolAudience> {
        private final ProtocolAudience audience = new ProtocolAudience();

        private Builder() {
        }

        @Nonnull
        public Builder bind(int entityId) {
            this.audience.typedPackets.put(PacketType.Play.Server.ENTITY_DESTROY, EntityDestroyPacket.newBuilder().entityIds(entityId).buildPacket());
            return this;
        }

        @SafeVarargs
        @Nonnull
        public final Builder packets(@Nonnull PacketWrapper<PacketContainer>... packetWrappers) {
            for (PacketWrapper<PacketContainer> packetWrapper : packetWrappers) {
                this.audience.typedPackets.put(packetWrapper.handle().getType(), packetWrapper);
            }
            return this;
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        @Nonnull
        public Builder adapt(@Nonnull ProtocolAudience other) {
            this.audience.typedPackets.putAll(other.typedPackets);
            this.audience.members.clear();
            this.audience.members.addAll(other.members);
            return this;
        }



        @Override // me.atilt.supplydrops.api.model.Builder
        /* renamed from: copy */
        public me.atilt.supplydrops.api.model.Builder<ProtocolAudience> copy() {
            return new Builder();
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // me.atilt.supplydrops.api.model.Builder
        @Nonnull
        public ProtocolAudience build() {
            return this.audience;
        }
    }

    @Nonnull
    public static Builder builder() {
        return new Builder();
    }

    private ProtocolAudience(@Nonnull Map<PacketType, PacketWrapper<PacketContainer>> typedPackets) {
        this.members = new HashSet();
        this.typedPackets = typedPackets;
    }

    private ProtocolAudience() {
        this(new Object2ObjectLinkedOpenHashMap(3, 0.99f));
    }

    @Nullable
    public PacketWrapper<PacketContainer> trackPacket(@Nonnull PacketWrapper<PacketContainer> packetWrapper) {
        return this.typedPackets.put(packetWrapper.handle().getType(), packetWrapper);
    }

    @Nullable
    public PacketWrapper<PacketContainer> untrackPacket(@Nonnull PacketType type) {
        return this.typedPackets.remove(type);
    }

    public PacketWrapper<PacketContainer> modifyPacket(@Nonnull PacketType type, @Nonnull Function<PacketWrapper<PacketContainer>, PacketWrapper<PacketContainer>> transformer) {
        return this.typedPackets.compute(type, (packetType, packetWrapper) -> transformer.apply(packetWrapper));

    }

    @Override // me.atilt.supplydrops.api.model.packet.Audience
    @Nonnull
    public Set<Player> members() {
        return Collections.unmodifiableSet(this.members);
    }

    @Override // me.atilt.supplydrops.api.model.packet.protocollib.entity.PacketAudience
    @Nonnull
    public List<PacketWrapper<PacketContainer>> packets() {
        return List.copyOf(this.typedPackets.values());
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        this.members.clear();
    }

    @Override // java.util.Set, java.util.Collection
    public int size() {
        return this.members.size();
    }

    @Override // java.util.Set, java.util.Collection
    public boolean isEmpty() {
        return this.members.isEmpty();
    }

    @Override // java.util.Set, java.util.Collection
    public boolean contains(@Nonnull Object object) {
        return this.members.contains(object);
    }

    @Override // java.util.Set, java.util.Collection, java.lang.Iterable
    @Nonnull
    public Iterator<Player> iterator() {
        return members().iterator();
    }

    @Override // java.util.Set, java.util.Collection
    @Nonnull
    public Object[] toArray() {
        return this.members.toArray();
    }

    @Override // java.util.Set, java.util.Collection
    @Nonnull
    public <T> T[] toArray(@Nonnull T[] array) {
        return (T[]) this.members.toArray(array);
    }

    @Override // java.util.Set, java.util.Collection
    public boolean add(Player player) {
        constructorFor(player);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean remove(Object object) {
        if (this.members.remove(object)) {
            deconstructFor((Player) object);
            return true;
        }
        return false;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean containsAll(@Nonnull Collection<?> collection) {
        return this.members.containsAll(collection);
    }

    @Override // java.util.Set, java.util.Collection
    public boolean addAll(@Nonnull Collection<? extends Player> collection) {
        boolean all = true;
        for (Player player : collection) {
            if (!add(player)) {
                all = false;
            }
        }
        return all;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean retainAll(@Nonnull Collection<?> collection) {
        boolean changed = false;
        Iterator<Player> members = this.members.iterator();
        while (members.hasNext()) {
            Player player = members.next();
            if (!collection.contains(player)) {
                members.remove();
                deconstructFor(player);
                changed = true;
            }
        }
        return changed;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean removeAll(@Nonnull Collection<?> collection) {
        boolean all = true;
        for (Object player : collection) {
            if (!remove(player)) {
                all = false;
            }
        }
        return all;
    }

    @Override // java.util.Set, java.util.Collection
    public void clear() {
        Iterator<Map.Entry<PacketType, PacketWrapper<PacketContainer>>> it = this.typedPackets.entrySet().iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Map.Entry<PacketType, PacketWrapper<PacketContainer>> wrapperEntry = it.next();
            PacketType type = wrapperEntry.getKey();
            if (type == PacketType.Play.Server.ENTITY_DESTROY) {
                for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                    sendPacket(onlinePlayer, wrapperEntry.getValue().handle());
                }
            }
        }
        this.members.clear();
    }

    private void sendPacket(@Nonnull Player player, @Nonnull PacketContainer container) {
        ProtocolLibrary.getProtocolManager().sendServerPacket(player, container);
    }

    private void constructorFor(@Nonnull Player player) {
        PacketContainer bundle = new PacketContainer(PacketType.Play.Server.BUNDLE);
        List<PacketContainer> packets = new ArrayList<>(this.typedPackets.size());
        for (Map.Entry<PacketType, PacketWrapper<PacketContainer>> packet : this.typedPackets.entrySet()) {
            if (packet.getKey() != PacketType.Play.Server.ENTITY_DESTROY) {
                PacketWrapper<PacketContainer> packetWrapper = packet.getValue();
                if (packetWrapper instanceof TransformablePacketWrapper) {
                    TransformablePacketWrapper<Player, PacketContainer> transformablePacketWrapper = (TransformablePacketWrapper) packetWrapper;
                    packets.add(transformablePacketWrapper.transformation().apply(player, packetWrapper.deepClone()).handle());
                } else {
                    packets.add(packetWrapper.handle());
                }
            }
        }
        bundle.getPacketBundles().write(0, packets);
        ProtocolLibrary.getProtocolManager().sendServerPacket(player, bundle);
    }

    private void deconstructFor(@Nonnull Player player) {
        PacketWrapper<PacketContainer> packetWrapper = this.typedPackets.get(PacketType.Play.Server.ENTITY_DESTROY);
        if (packetWrapper == null) {
            throw new IllegalStateException("entity removal not specified");
        }
        sendPacket(player, packetWrapper.handle());
    }
}

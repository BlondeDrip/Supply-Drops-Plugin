package me.atilt.supplydrops.api.model.util;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import me.atilt.supplydrops.api.model.packet.ProtocolVersion;
import org.bukkit.Bukkit;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/util/EntityID.class */
public class EntityID {
    private static Class<?> entityClass;
    private static Field entityCountField;
    public static String version;
    private static final AtomicInteger IDS;

    static {
        String name = Bukkit.getServer().getClass().getPackage().getName();
        version = name.substring(name.lastIndexOf(46) + 1) + ".";
        try {
            if (ProtocolVersion.runningVersion().isAtMost(ProtocolVersion.v1_16_R3)) {
                entityClass = Class.forName("net.minecraft.server." + getVersion() + "Entity");
                entityCountField = entityClass.getDeclaredField("entityCount");
                entityCountField.setAccessible(true);
            } else {
                entityClass = Class.forName("net.minecraft.world.entity.Entity");
                Optional<Field> field = Arrays.stream(entityClass.getDeclaredFields()).filter(entry -> {
                    return entry.getType().equals(AtomicInteger.class);
                }).findFirst();
                if (field.isPresent()) {
                    entityCountField = field.get();
                    entityCountField.setAccessible(true);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        IDS = new AtomicInteger(-42000);
    }

    public static int nextEntityIdOld() {
        try {
            int id = entityCountField.getInt(null);
            entityCountField.set(null, Integer.valueOf(id + 1));
            return id;
        } catch (Exception e) {
            return 0;
        }
    }

    public static int nextEntityIdNew() {
        try {
            return ((AtomicInteger) AtomicInteger.class.cast(entityCountField.get(null))).incrementAndGet();
        } catch (Exception e) {
            return 0;
        }
    }

    public static int nextEntityId() {
        return IDS.getAndDecrement();
    }

    public static Class<?> getNMSClass(String className) {
        String fullName = "net.minecraft.server." + getVersion() + className;
        Class<?> clazz = null;
        try {
            clazz = Class.forName(fullName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return clazz;
    }

    public static String getVersion() {
        return version;
    }
}

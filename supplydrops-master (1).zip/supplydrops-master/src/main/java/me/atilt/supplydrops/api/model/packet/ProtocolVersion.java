package me.atilt.supplydrops.api.model.packet;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/ProtocolVersion.class */
public enum ProtocolVersion {
    v1_8_R1(new String[]{"1.8", "1.8.1", "1.8.2"}),
    v1_8_R2(new String[]{"1.8.3"}),
    v1_8_R3(new String[]{"1.8.4", "1.8.5", "1.8.6", "1.8.7", "1.8.8", "1.8.9"}),
    v1_9_R1(new String[]{"1.9", "1.9.1", "1.9.2", "1.9.3"}),
    v1_9_R2(new String[]{"1.9.4"}),
    v1_10_R1(new String[]{"1.10", "1.10.1", "1.10.2"}),
    v1_11_R1(new String[]{"1.11", "1.11.1", "1.11.2"}),
    v1_12_R1(new String[]{"1.12", "1.12.1", "1.12.2"}),
    v1_13_R1(new String[]{"1.13"}),
    v1_13_R2(new String[]{"1.13.1", "1.13.2"}),
    v1_14_R1(new String[]{"1.14", "1.14.1", "1.14.2", "1.14.3", "1.14.4"}),
    v1_15_R1(new String[]{"1.15", "1.15.1", "1.15.2"}),
    v1_16_R1(new String[]{"1.16", "1.16.1"}),
    v1_16_R2(new String[]{"1.16.2", "1.16.3"}),
    v1_16_R3(new String[]{"1.16.4", "1.16.5"}),
    v1_17_R1(new String[]{"1.17", "1.17.1"}),
    v1_18_R1(new String[]{"1.18", "1.18.1"}),
    v1_18_R2(new String[]{"1.18.2"}),
    v1_19_R1(new String[]{"1.19", "1.19.1", "1.19.2"}),
    v1_19_R2(new String[]{"1.19.3"}),
    v1_19_R3(new String[]{"1.19.4"});
    
    private final String[] versions;
    private static ProtocolVersion LATEST;
    private static ProtocolVersion CURRENT;
    private static final Map<String, ProtocolVersion> MC_VERSIONS = new HashMap(50, 1.02f);

    static {
        ProtocolVersion[] values;
        String[] versions;
        for (ProtocolVersion version : values()) {
            for (String value : version.getVersions()) {
                MC_VERSIONS.put(value, version);
            }
        }
    }

    ProtocolVersion(String[] versions) {
        this.versions = versions;
    }

    @Nonnull
    public String[] getVersions() {
        return this.versions;
    }

    @Nonnull
    public static ProtocolVersion latest() {
        if (LATEST == null) {
            ProtocolVersion protocolVersion = values()[values().length - 1];
            LATEST = protocolVersion;
            return protocolVersion;
        }
        return LATEST;
    }

    @Nonnull
    public static ProtocolVersion runningVersion() {
        if (CURRENT != null) {
            return CURRENT;
        }
        String name = Bukkit.getServer().getClass().getPackage().getName();
        String version = name.substring(name.lastIndexOf(46) + 1);
        try {
            ProtocolVersion valueOf = valueOf(version);
            CURRENT = valueOf;
            return valueOf;
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Unsupported MC version: '" + version + "'");
        }
    }

    public boolean contains(@Nonnull String version) {
        String[] strArr;
        for (String supported : this.versions) {
            if (supported.equals(version)) {
                return true;
            }
        }
        return false;
    }

    @Nullable
    public static ProtocolVersion from(@Nonnull String version) {
        return MC_VERSIONS.get(version);
    }

    public boolean isAtLeast(@Nonnull ProtocolVersion other) {
        return compareTo(other) >= 0;
    }

    public boolean isAtMost(@Nonnull ProtocolVersion other) {
        return compareTo(other) <= 0;
    }

    public boolean is(@Nonnull ProtocolVersion other) {
        return this == other;
    }

    @Override // java.lang.Enum
    public String toString() {
        String version = name().substring(1).replace("_R", ".");
        int dotIndex = version.lastIndexOf(46);
        return dotIndex > 0 ? version.substring(0, dotIndex) : version;
    }
}

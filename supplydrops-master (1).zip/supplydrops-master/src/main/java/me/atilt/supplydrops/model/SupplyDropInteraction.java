package me.atilt.supplydrops.model;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.Interaction;
import me.atilt.supplydrops.command.Permission;
import me.atilt.supplydrops.loot.LootEntry;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/SupplyDropInteraction.class */
public final class SupplyDropInteraction implements Interaction<Player, SupplyDrop> {
    private boolean populated = false;
    private final Inventory inventory = Bukkit.createInventory((InventoryHolder) null, 54);

    @Override // java.util.function.BiConsumer
    public void accept(Player player, SupplyDrop supplyDrop) {
        if (!Permission.SUPPLYDROP_OPEN.has(player)) {
            player.sendMessage(SupplyDropsPlugin.self().configMessages().getString("supply-drop.open.no-permission"));
        } else if (supplyDrop.landingData() == null && !SupplyDropsPlugin.self().getConfig().getBoolean("supply-drops.loot.allow-opening-before-land")) {
            player.getWorld().playSound(player.getLocation(), Sound.BLOCK_CHEST_LOCKED, 0.2f, 0.314f);
        } else {
            if (!this.populated) {
                List<LootEntry<?>> lootEntries = supplyDrop.lootTable().get();
                for (LootEntry<?> lootEntry : lootEntries) {
                    int slot = randomSlot();
                    if (slot == -1) {
                        break;
                    }
                    this.inventory.setItem(slot, (ItemStack) lootEntry.get());
                }
                this.populated = true;
            }
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_HORSE_ARMOR, 0.2f, 0.314f);
            player.openInventory(this.inventory);
        }
    }

    @Override // java.util.function.BiFunction
    public Boolean apply(Player player, SupplyDrop supplyDrop) {
        return true;
    }

    private int randomSlot() {
        if (this.inventory.firstEmpty() == -1) {
            return -1;
        }
        int slot = ThreadLocalRandom.current().nextInt(0, this.inventory.getSize());
        if (this.inventory.getItem(slot) == null) {
            return slot;
        }
        return randomSlot();
    }

    public boolean isPopulated() {
        return this.populated;
    }

    public void clear() {
        this.inventory.clear();
        new ArrayList(this.inventory.getViewers()).forEach(player ->((Player) player).closeInventory());
        this.populated = false;
    }
}

package me.atilt.supplydrops.api.model;

import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/Builder.class */
public interface Builder<B> {
    @Nonnull
    Builder<B> adapt(@Nonnull B b);

    Builder<B> copy();

    @Nonnull
    B build();
}

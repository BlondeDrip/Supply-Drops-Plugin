package me.atilt.supplydrops.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Reflections.class */
public final class Reflections {
    public static List<Class<?>> getChildClasses(Class<?> parentClass) throws IOException, ClassNotFoundException {
        List<Class<?>> childClasses = new ArrayList<>();
        String classpath = System.getProperty("java.class.path");
        String[] classpathEntries = classpath.split(File.pathSeparator);
        for (String classpathEntry : classpathEntries) {
            File file = new File(classpathEntry);
            if (file.isDirectory()) {
                addClassesInDirectory(childClasses, file, "", parentClass);
            } else if (file.getName().endsWith(".jar")) {
                addClassesInJar(childClasses, file, parentClass);
            }
        }
        return childClasses;
    }

    private static void addClassesInDirectory(List<Class<?>> classes, File directory, String packageName, Class<?> parentClass) throws ClassNotFoundException {
        File[] listFiles;
        for (File file : directory.listFiles()) {
            String name = file.getName();
            if (file.isDirectory()) {
                addClassesInDirectory(classes, file, packageName + name + ".", parentClass);
            } else if (name.endsWith(".class")) {
                String className = packageName + name.substring(0, name.length() - 6);
                Class<?> clazz = Class.forName(className);
                if (parentClass.isAssignableFrom(clazz) && !parentClass.equals(clazz)) {
                    classes.add(clazz);
                }
            }
        }
    }

    private static void addClassesInJar(List<Class<?>> classes, File jarFile, Class<?> parentClass) throws IOException, ClassNotFoundException {
        JarFile jar = new JarFile(jarFile);
        try {
            Enumeration<? extends JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();
                if (name.endsWith(".class")) {
                    String className = name.substring(0, name.length() - 6).replace('/', '.');
                    Class<?> clazz = Class.forName(className);
                    if (parentClass.isAssignableFrom(clazz) && !parentClass.equals(clazz)) {
                        classes.add(clazz);
                    }
                }
            }
            jar.close();
        } catch (Throwable th) {
            try {
                jar.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }
}

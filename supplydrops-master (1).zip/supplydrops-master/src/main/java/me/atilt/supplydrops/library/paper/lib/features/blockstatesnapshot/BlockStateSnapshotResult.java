package me.atilt.supplydrops.library.paper.lib.features.blockstatesnapshot;

import org.bukkit.block.BlockState;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/blockstatesnapshot/BlockStateSnapshotResult.class */
public class BlockStateSnapshotResult {
    private final boolean isSnapshot;
    private final BlockState state;

    public BlockStateSnapshotResult(boolean isSnapshot, BlockState state) {
        this.isSnapshot = isSnapshot;
        this.state = state;
    }

    public boolean isSnapshot() {
        return this.isSnapshot;
    }

    public BlockState getState() {
        return this.state;
    }
}

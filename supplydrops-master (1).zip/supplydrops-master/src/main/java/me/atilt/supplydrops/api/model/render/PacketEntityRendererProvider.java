package me.atilt.supplydrops.api.model.render;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;
import me.atilt.supplydrops.api.model.EntitySchema;
import me.atilt.supplydrops.api.model.Schema;
import me.atilt.supplydrops.api.model.entity.Entity;
import me.atilt.supplydrops.api.model.entity.living.packet.PacketEntity;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolArmorStand;
import me.atilt.supplydrops.api.model.util.EntityID;
import org.bukkit.entity.EntityType;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/render/PacketEntityRendererProvider.class */
public class PacketEntityRendererProvider implements EntityRendererProvider<PacketEntity<?>> {
    private final Map<EntityType, Supplier<PacketEntity<?>>> mappings = new EnumMap<EntityType, Supplier<PacketEntity<?>>>(EntityType.class) { // from class: me.atilt.supplydrops.api.model.render.PacketEntityRendererProvider.1
        {
            put(EntityType.ARMOR_STAND, () -> new ProtocolArmorStand(EntityID.nextEntityId(), UUID.randomUUID()));
        }
    };

    @Override // me.atilt.supplydrops.api.model.render.EntityRendererProvider
    public Map<EntityType, Supplier<PacketEntity<?>>> mappings() {
        return Collections.unmodifiableMap(this.mappings);
    }

    @Override // java.util.function.Function
    public EntityRenderer<?> apply(Schema<? extends Entity> schema) {
        EntitySchema<PacketEntity<?>> entitySchema = (EntitySchema) schema;
        return new PacketEntityRenderer(this.mappings.get(entitySchema.bukkitType()).get(), entitySchema);
    }
}

package me.atilt.supplydrops.api.model;

import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import okhttp3.internal.ws.WebSocketProtocol;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/IntModelFactory.class */
public interface IntModelFactory extends ModelFactory<Integer> {
    public static final IdGenerator ID_GENERATOR = new IdGenerator();

    @Nullable
    ModelConveyor<? extends Model> submitInt(int i, @Nonnull ModelConveyor<? extends Model> modelConveyor);

    @Nonnull
    Model manufactureInt(int i);

    @Nonnull
    Model manufactureInt(int i, @Nonnull List<SerializedState> list);

    static int newId() {
        return ID_GENERATOR.generateId();
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/IntModelFactory$IdGenerator.class */
    public static class IdGenerator {
        private static final int PREFIX = (int) (System.currentTimeMillis() & WebSocketProtocol.PAYLOAD_SHORT_MAX);
        private static final int C1 = -862048943;
        private static final int C2 = 461845907;

        public int generateId() {
            long timestamp = System.currentTimeMillis();
            return mixHash((PREFIX << 16) | ((int) (timestamp >>> 32)), (int) timestamp);
        }

        private int mixHash(int k1, int k2) {
            int h1 = C1 * k1;
            int h12 = (Integer.rotateLeft(Integer.rotateLeft(h1, 15) ^ C2, 13) * 5) - 430675100;
            int h2 = C1 * k2;
            int h22 = (Integer.rotateLeft(Integer.rotateLeft(h2, 15) ^ C2, 13) * 5) - 430675100;
            int h13 = h12 ^ 8;
            int h23 = h22 ^ 8;
            int h14 = h13 + h23;
            int h24 = h23 + h14;
            int h15 = h14 ^ (h14 >>> 16);
            int h25 = h24 ^ (h24 >>> 16);
            int h16 = h15 * (-2048144789);
            int h26 = h25 * (-2048144789);
            int h17 = h16 ^ (h16 >>> 13);
            int h27 = h26 ^ (h26 >>> 13);
            int h18 = h17 * (-1028477387);
            int h28 = h27 * (-1028477387);
            return (h18 ^ (h18 >>> 16)) + (h28 ^ (h28 >>> 16));
        }
    }
}

package com.pastebin.api.request;

import java.util.HashMap;
import java.util.Map;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/request/ListRequest.class */
public class ListRequest implements Request {
    private final Integer limit;

    public ListRequest() {
        this(null);
    }

    private ListRequest(Integer limit) {
        this.limit = limit;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static ListRequest limit(int limit) {
        return new Builder().limit(limit).build();
    }

    @Override // com.pastebin.api.request.Request
    public Map<String, String> getParameters() {
        Map<String, String> output = new HashMap<>();
        output.put("api_option", "list");
        if (this.limit != null) {
            output.put("api_results_limit", String.valueOf(this.limit));
        }
        return output;
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/request/ListRequest$Builder.class */
    public static class Builder {
        private Integer limit;

        Builder() {
        }

        public Builder limit(int limit) {
            this.limit = Integer.valueOf(limit);
            return this;
        }

        public ListRequest build() {
            if (this.limit != null && this.limit.intValue() < 1) {
                throw new IllegalArgumentException("Limit minimum is 1");
            }
            if (this.limit != null && this.limit.intValue() > 100) {
                throw new IllegalArgumentException("Limit maximum is 100");
            }
            return new ListRequest(this.limit);
        }
    }
}

package me.atilt.supplydrops.library.paper.lib.features.blockstatesnapshot;

import org.bukkit.block.Block;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/blockstatesnapshot/BlockStateSnapshot.class */
public interface BlockStateSnapshot {
    BlockStateSnapshotResult getBlockState(Block block, boolean z);
}

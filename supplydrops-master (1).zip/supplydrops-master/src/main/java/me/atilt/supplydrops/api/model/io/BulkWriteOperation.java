package me.atilt.supplydrops.api.model.io;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/io/BulkWriteOperation.class */
public class BulkWriteOperation<T> {
    private BiConsumer<OutputStream, T> writeOperation;
    private final ConcurrentFileAccessor<T> fileAccessor;

    public BulkWriteOperation(ConcurrentFileAccessor<T> fileAccessor) {
        this.fileAccessor = fileAccessor;
    }

    @Nonnull
    public BulkWriteOperation<T> operation(BiConsumer<OutputStream, T> writeOperation) {
        this.writeOperation = writeOperation;
        return this;
    }

    @Nonnull
    public CompletableFuture<Void> applyAsync(List<Path> paths, T data) {
        return CompletableFuture.runAsync(() -> {
            try {
                apply(paths, data);
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
        });
    }

    public void apply(List<Path> paths, T data) throws IOException {
        this.fileAccessor.getLock().lock();
        try {
            for (Path path : paths) {
                OutputStream outputStream = Files.newOutputStream(path, new OpenOption[0]);
                this.writeOperation.accept(outputStream, data);
                if (outputStream != null) {
                    outputStream.close();
                }
            }
        } finally {
            this.fileAccessor.getLock().unlock();
        }
    }
}

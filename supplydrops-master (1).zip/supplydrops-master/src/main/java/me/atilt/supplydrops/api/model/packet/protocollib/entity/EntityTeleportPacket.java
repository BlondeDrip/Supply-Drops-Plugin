package me.atilt.supplydrops.api.model.packet.protocollib.entity;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketContainer;
import com.google.common.base.Preconditions;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketBuilder;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper;
import org.bukkit.Location;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityTeleportPacket.class */
public final class EntityTeleportPacket implements ProtocolPacketWrapper {
    private final PacketContainer handle;

    public EntityTeleportPacket(@Nonnull PacketContainer handle) {
        Preconditions.checkArgument(handle.getType() == PacketType.Play.Server.ENTITY_TELEPORT, "packet mismatch");
        this.handle = handle;
    }

    public EntityTeleportPacket() {
        this(new PacketContainer(PacketType.Play.Server.ENTITY_TELEPORT));
    }

    @Nonnull
    public static Builder newBuilder(@Nonnull PacketWrapper<PacketContainer> handle) {
        return new Builder(handle.handle());
    }

    @Nonnull
    public static Builder newBuilder() {
        return new Builder();
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    public PacketContainer handle() {
        return this.handle;
    }

    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    /* renamed from: deepClone */
    public PacketWrapper<PacketContainer> deepClone() {
        return new EntityTeleportPacket(this.handle.deepClone());
    }

    @Override // me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper
    @Nonnull
    public PacketType type() {
        return this.handle.getType();
    }

    @Override // java.lang.AutoCloseable
    public void close() {
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/EntityTeleportPacket$Builder.class */
    public static class Builder extends ProtocolPacketBuilder {
        private Builder(@Nonnull PacketContainer handle) {
            super(handle);
        }

        private Builder() {
            this(new PacketContainer(PacketType.Play.Server.ENTITY_TELEPORT));
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        public Builder copy() {
            return new Builder(this.handle.deepClone());
        }

        @Override // me.atilt.supplydrops.api.model.packet.PacketBuilder
        @Nonnull
        /* renamed from: buildPacket */
        public PacketWrapper<PacketContainer> buildPacket() {
            return new EntityTeleportPacket(this.handle);
        }

        @Nonnull
        public Builder entityId(int id) {
            this.handle.getIntegers().write(0, Integer.valueOf(id));
            return this;
        }

        public Builder location(double x, double y, double z) {
            this.handle.getBooleans().writeSafely(0, false);
            this.handle.getDoubles().write(0, Double.valueOf(x)).write(1, Double.valueOf(y)).write(2, Double.valueOf(z));
            return this;
        }

        public Builder location(double x, double y, double z, float yaw, float pitch) {
            this.handle.getBooleans().writeSafely(0, false);
            this.handle.getDoubles().write(0, Double.valueOf(x)).write(1, Double.valueOf(y)).write(2, Double.valueOf(z));
            this.handle.getBytes().write(0, Byte.valueOf((byte) ((yaw * 256.0f) / 360.0f))).write(1, Byte.valueOf((byte) ((pitch * 256.0f) / 360.0f)));
            return this;
        }

        @Nonnull
        public Builder location(@Nonnull Location location) {
            return location(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
        }
    }
}

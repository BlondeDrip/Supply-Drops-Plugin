package me.atilt.supplydrops.model.registry;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import me.atilt.supplydrops.registry.Int2ObjectRegistry;
import me.atilt.supplydrops.supplydrop.ModelData;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/registry/ModelRegistry.class */
public class ModelRegistry implements Int2ObjectRegistry<ModelData> {
    private final ModelMap models = new ModelMap();
    private static final AtomicInteger IDs = new AtomicInteger(1);
    @Override // me.atilt.supplydrops.registry.Int2ObjectRegistry
    @Nonnull
    public ModelData getOrDefault(int id, @Nonnull ModelData modelData) {
        return this.models.getOrDefault(id, modelData);
    }

    @Nonnegative
    public static int nextId() {
        return IDs.getAndIncrement();
    }

    @Nonnull
    public ModelMap modelMap() {
        return this.models;
    }


    @Nullable
    @Override
    public ModelData register(int i, @NotNull ModelData modelData) {
        return this.models.put(i, modelData);

    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.registry.Int2ObjectRegistry
    @Nullable
    public ModelData unregister(int id) {
        return this.models.remove(id);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.registry.Int2ObjectRegistry
    @Nullable
    public ModelData get(int id) {
        return this.models.get(id);
    }


    @Nullable
    @Override
    public ModelData register(@NotNull Integer integer, @NotNull ModelData modelData) {
        return null;
    }

    @Override // me.atilt.supplydrops.registry.Registry
    public void register(@Nonnull Map<? extends Integer, ? extends ModelData> all) {
        this.models.putAll(all);
    }

    @NotNull
    @Override
    public ModelData getOrDefault(@NotNull Integer integer, @NotNull ModelData modelData) {
        return null;
    }

    @Override // me.atilt.supplydrops.registry.Registry
    public int size() {
        return this.models.size();
    }

    @Override // me.atilt.supplydrops.registry.Registry
    @Nonnull
    public Map<Integer, ModelData> all() {
        return Collections.unmodifiableMap(this.models);
    }

    @Override // me.atilt.supplydrops.registry.Int2ObjectRegistry
    public ObjectIterator<Int2ObjectMap.Entry<ModelData>> intIterator() {
        return Int2ObjectMaps.fastIterator(this.models);
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        ObjectIterator<ModelData> it = this.models.values().iterator();
        while (it.hasNext()) {
            ModelData modelData = it.next();
            try {
                modelData.getHandle().close();
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        this.models.clear();
    }
}

package me.atilt.supplydrops.api.model.interpreter;

import java.util.function.Function;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/interpreter/Interpreter.class */
public interface Interpreter<T, U> extends Function<T, U> {
    @Nonnull
    U interpret(@Nonnull T t);

    @Override // java.util.function.Function
    @Nonnull
    default U apply(T t) {
        return interpret(t);
    }
}

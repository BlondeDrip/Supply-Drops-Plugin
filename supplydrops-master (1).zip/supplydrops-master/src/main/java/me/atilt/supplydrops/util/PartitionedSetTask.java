package me.atilt.supplydrops.util;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.function.BooleanSupplier;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/PartitionedSetTask.class */
public class PartitionedSetTask implements Task {
    private final Plugin plugin;
    private final Set<Task> partitions = new HashSet();
    private final int partitionsPerTick;
    private final int per;
    private Iterator<Task> partitionIterator;
    private final BooleanSupplier rerun;
    private boolean allowedToRun;
    private int task;

    public PartitionedSetTask(Plugin plugin, int partitionsPer, int per, BooleanSupplier rerun) {
        this.plugin = plugin;
        this.partitionsPerTick = partitionsPer;
        this.per = per;
        this.rerun = rerun;
    }

    @Override // me.atilt.supplydrops.util.Task
    public boolean running() {
        return this.task != 0;
    }

    public Set<Task> partitions() {
        return java.util.Collections.unmodifiableSet(this.partitions);
    }

    public int size() {
        return this.partitions.size();
    }

    public boolean addPartition(Task task) {
        return this.partitions.add(task);
    }

    public boolean removePartition(Task task) {
        return this.partitions.remove(task);
    }

    public void start() {
        start(false);
    }

    public void start(boolean async) {
        if (async) {
            this.task = Bukkit.getScheduler().runTaskTimerAsynchronously(this.plugin, this, 0L, this.per).getTaskId();
        } else {
            this.task = Bukkit.getScheduler().runTaskTimer(this.plugin, this, 0L, this.per).getTaskId();
        }
    }

    public void stop() {
        Bukkit.getScheduler().cancelTask(this.task);
    }

    public void clear() {
        this.partitions.clear();
    }

    @Override // java.lang.Runnable
    public void run() {
        int totalPartitions = this.partitions.size();
        if (totalPartitions == 0) {
            return;
        }
        if (!this.allowedToRun && this.rerun.getAsBoolean()) {
            this.allowedToRun = true;
        }
        if (this.allowedToRun) {
            int partitionsToProcess = Math.min(this.partitionsPerTick, totalPartitions);
            if (this.partitionIterator == null || !this.partitionIterator.hasNext()) {
                this.partitionIterator = new HashSet(this.partitions).iterator();
            }
            int partitionsProcessedThisTick = 0;
            while (partitionsProcessedThisTick < partitionsToProcess) {
                Task partition = this.partitionIterator.next();
                partition.run();
                partitionsProcessedThisTick++;
                if (!this.partitionIterator.hasNext()) {
                    this.partitionIterator = new HashSet(this.partitions).iterator();
                    this.allowedToRun = false;
                }
            }
        }
    }
}

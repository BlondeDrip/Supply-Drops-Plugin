package me.atilt.supplydrops.util;

import java.lang.reflect.Field;
import java.util.concurrent.Executor;
import javax.annotation.Nonnull;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitScheduler;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/BukkitExecutors.class */
public final class BukkitExecutors {
    private static Executor BUKKIT;

    static {
        BukkitScheduler scheduler = Bukkit.getScheduler();
        Class<?> cls = scheduler.getClass();
        try {
            Field executorField = cls.getDeclaredField("scheduler");
            executorField.setAccessible(true);
            BUKKIT = (Executor) executorField.get(cls);
            executorField.setAccessible(false);
        } catch (IllegalAccessException | NoSuchFieldException exception) {
            exception.printStackTrace();
        }
        if (BUKKIT == null) {
            throw new IllegalStateException("Unable to retrieve BukkitScheduler Executor.");
        }
    }

    @Nonnull
    public static Executor direct() {
        return BUKKIT;
    }

    private BukkitExecutors() {
        throw new UnsupportedOperationException("This class cannot be instantiated");
    }
}

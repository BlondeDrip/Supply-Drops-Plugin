package me.atilt.supplydrops.api.model;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.entity.Entity;
import org.bukkit.entity.EntityType;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/EntitySchema.class */
public interface EntitySchema<E extends Entity> extends Schema<E> {
    public static final Schema<Entity> EMPTY = new Schema<Entity>() { // from class: me.atilt.supplydrops.api.model.EntitySchema.1
        @Override // me.atilt.supplydrops.api.model.Schema
        @Nonnull
        /* renamed from: clone */
        public Schema<Entity> clone() {
            return EntitySchema.EMPTY;
        }

        @Override // java.util.function.Consumer
        public void accept(Entity entity) {
        }
    };

    @Nonnull
    EntityType bukkitType();
}

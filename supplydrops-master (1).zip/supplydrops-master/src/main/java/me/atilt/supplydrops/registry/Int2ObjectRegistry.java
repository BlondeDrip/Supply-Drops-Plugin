package me.atilt.supplydrops.registry;

import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/registry/Int2ObjectRegistry.class */
public interface Int2ObjectRegistry<T> extends Registry<Integer, T> {
    @Nullable
    T register(int i, @Nonnull T t);

    @Nullable
    T unregister(int i);

    @Nullable
    T get(int i);

    @Nonnull
    T getOrDefault(int i, @Nonnull T t);

    ObjectIterator<Int2ObjectMap.Entry<T>> intIterator();

    /* JADX WARN: Multi-variable type inference failed */
    @Override // me.atilt.supplydrops.registry.Registry
    @Nonnull
    @Deprecated
    /* bridge */ /* synthetic */ default Object getOrDefault(@Nonnull Integer num, @Nonnull Object obj) {
        return getOrDefault(num, obj);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // me.atilt.supplydrops.registry.Registry
    @Nullable
    @Deprecated
    /* bridge */ /* synthetic */ default Object register(@Nonnull Integer num, @Nonnull Object obj) {
        return register(num, obj);
    }


    @Override // me.atilt.supplydrops.registry.Registry
    @Nullable
    @Deprecated
    default T unregister(@Nonnull Integer integer) {
        return unregister(integer.intValue());
    }

    @Override // me.atilt.supplydrops.registry.Registry
    @Nullable
    @Deprecated
    default T get(@Nonnull Integer integer) {
        return get(integer.intValue());
    }



    @Override // java.lang.Iterable
    @Nonnull
    @Deprecated
    default Iterator<Map.Entry<Integer, T>> iterator() {
        return all().entrySet().iterator();
    }
}

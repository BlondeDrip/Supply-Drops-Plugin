package me.atilt.supplydrops.api.model;

import java.io.*;
import java.nio.BufferOverflowException;
import java.nio.BufferUnderflowException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.InputMismatchException;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import okio.Segment;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/ArmorStandMockData.class */
public class ArmorStandMockData implements SerializedState, Serializable {
    public static final int colferSizeMax = 16777216;
    public static final int colferListMax = 65536;
    public String entityType;
    public boolean invisible;
    public boolean small;
    public float[] head;
    public float[] body;
    public float[] leftArm;
    public float[] rightArm;
    public float[] leftLeg;
    public float[] rightLeg;
    public String[] equipment;
    public float[] offset;
    public float yaw;
    private static final float[] _zeroHead = new float[0];
    private static final float[] _zeroBody = new float[0];
    private static final float[] _zeroLeftArm = new float[0];
    private static final float[] _zeroRightArm = new float[0];
    private static final float[] _zeroLeftLeg = new float[0];
    private static final float[] _zeroRightLeg = new float[0];
    private static final String[] _zeroEquipment = new String[0];
    private static final float[] _zeroOffset = new float[0];
    private static final long serialVersionUID = 12;

    public ArmorStandMockData() {
        init();
    }

    private void init() {
        this.entityType = "";
        this.head = _zeroHead;
        this.body = _zeroBody;
        this.leftArm = _zeroLeftArm;
        this.rightArm = _zeroRightArm;
        this.leftLeg = _zeroLeftLeg;
        this.rightLeg = _zeroRightLeg;
        this.equipment = _zeroEquipment;
        this.offset = _zeroOffset;
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/ArmorStandMockData$Unmarshaller.class */
    public static class Unmarshaller implements Unmarshallable<ArmorStandMockData> {
        protected InputStream in;
        public byte[] buf;
        protected int offset;
        protected int i;
        static final /* synthetic */ boolean $assertionsDisabled;

        static {
            $assertionsDisabled = !ArmorStandMockData.class.desiredAssertionStatus();
        }

        public Unmarshaller(InputStream in, byte[] buf) {
            this.buf = (buf == null || buf.length == 0) ? new byte[Math.min(16777216, 2048)] : buf;
            reset(in);
        }

        public void reset(InputStream in) {
            if (this.i != this.offset) {
                throw new IllegalStateException("colfer: pending data");
            }
            this.in = in;
            this.offset = 0;
            this.i = 0;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // me.atilt.supplydrops.api.model.Unmarshallable
        public ArmorStandMockData next() throws IOException {
            if (this.in == null) {
                return null;
            }
            while (true) {
                if (this.i > this.offset) {
                    try {
                        ArmorStandMockData o = new ArmorStandMockData();
                        this.offset = o.unmarshal(this.buf, this.offset, this.i);
                        return o;
                    } catch (BufferUnderflowException e) {
                    }
                }
                if (this.i <= this.offset) {
                    this.offset = 0;
                    this.i = 0;
                } else if (this.i == this.buf.length) {
                    byte[] src = this.buf;
                    if (this.offset == 0) {
                        this.buf = new byte[Math.min(16777216, this.buf.length * 4)];
                    }
                    System.arraycopy(src, this.offset, this.buf, 0, this.i - this.offset);
                    this.i -= this.offset;
                    this.offset = 0;
                }
                if (!$assertionsDisabled && this.i >= this.buf.length) {
                    throw new AssertionError();
                }
                int n = this.in.read(this.buf, this.i, this.buf.length - this.i);
                if (n < 0) {
                    if (this.i > this.offset) {
                        throw new InputMismatchException("colfer: pending data with EOF");
                    }
                    return null;
                } else if (!$assertionsDisabled && n <= 0) {
                    throw new AssertionError();
                } else {
                    this.i += n;
                }
            }
        }
    }

    public int marshalFit() {
        int size = 106;
        if (this.equipment != null) {
            size = 106 + 2;
            for (int i = 0; i < 6; i++) {
                if (this.equipment[i] != null) {
                    size += this.equipment[i].length();
                }
            }
        }
        int min = Math.min(16777216, size);
        return min;
    }

    public byte[] marshal(OutputStream out, byte[] buf) throws IOException {
        if (buf == null || buf.length == 0) {
            buf = new byte[Math.min(16777216, 2048)];
        }
        while (true) {
            try {
                int i = marshal(buf, 0);
                out.write(buf, 0, i);
                return buf;
            } catch (BufferOverflowException e) {
                buf = new byte[Math.min(16777216, buf.length * 4)];
            }
        }
    }

    public int marshal(byte[] buf, int offset) {
        int i = offset;
        try {
            if (!this.entityType.isEmpty()) {
                buf[i] = 0;
                i = i + 1 + 1;
                String s = this.entityType;
                int sIndex = 0;
                int sLength = s.length();
                while (sIndex < sLength) {
                    char c = s.charAt(sIndex);
                    if (c < 128) {
                        int i2 = i;
                        i++;
                        buf[i2] = (byte) c;
                    } else if (c < 2048) {
                        int i3 = i;
                        int i4 = i + 1;
                        buf[i3] = (byte) (192 | (c >>> 6));
                        i = i4 + 1;
                        buf[i4] = (byte) (128 | (c & '?'));
                    } else if (c < 55296 || c > 57343) {
                        int i5 = i;
                        int i6 = i + 1;
                        buf[i5] = (byte) (224 | (c >>> '\f'));
                        int i7 = i6 + 1;
                        buf[i6] = (byte) (128 | ((c >>> 6) & 63));
                        i = i7 + 1;
                        buf[i7] = (byte) (128 | (c & '?'));
                    } else {
                        sIndex++;
                        int cp = sIndex < sLength ? Character.toCodePoint(c, s.charAt(sIndex)) : 0;
                        if (cp >= 65536 && cp < 2097152) {
                            int i8 = i;
                            int i9 = i + 1;
                            buf[i8] = (byte) (240 | (cp >>> 18));
                            int i10 = i9 + 1;
                            buf[i9] = (byte) (128 | ((cp >>> 12) & 63));
                            int i11 = i10 + 1;
                            buf[i10] = (byte) (128 | ((cp >>> 6) & 63));
                            i = i11 + 1;
                            buf[i11] = (byte) (128 | (cp & 63));
                        } else {
                            int i12 = i;
                            i++;
                            buf[i12] = 63;
                        }
                    }
                    sIndex++;
                }
                int size = i - i;
                if (size > 16777216) {
                    throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.entityType size %d exceeds %d UTF-8 bytes", Integer.valueOf(size), 16777216));
                }
                int ii = i - 1;
                if (size > 127) {
                    i++;
                    for (int x = size; x >= 16384; x >>>= 7) {
                        i++;
                    }
                    System.arraycopy(buf, i, buf, i - size, size);
                    do {
                        int i13 = ii;
                        ii++;
                        buf[i13] = (byte) (size | 128);
                        size >>>= 7;
                    } while (size > 127);
                    buf[ii] = (byte) size;
                } else {
                    buf[ii] = (byte) size;
                }
            }
            if (this.invisible) {
                int i14 = i;
                i++;
                buf[i14] = 1;
            }
            if (this.small) {
                int i15 = i;
                i++;
                buf[i15] = 2;
            }
            if (this.head.length != 0) {
                int i16 = i;
                int i17 = i + 1;
                buf[i16] = 3;
                float[] a = this.head;
                int l = a.length;
                if (l > 65536) {
                    throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.head length %d exceeds %d elements", Integer.valueOf(l), Integer.valueOf((int) colferListMax)));
                }
                while (l > 127) {
                    int i18 = i17;
                    i17++;
                    buf[i18] = (byte) (l | 128);
                    l >>>= 7;
                }
                int i19 = i17;
                i = i17 + 1;
                buf[i19] = (byte) l;
                for (float f : a) {
                    int x2 = Float.floatToRawIntBits(f);
                    int i20 = i;
                    int i21 = i + 1;
                    buf[i20] = (byte) (x2 >>> 24);
                    int i22 = i21 + 1;
                    buf[i21] = (byte) (x2 >>> 16);
                    int i23 = i22 + 1;
                    buf[i22] = (byte) (x2 >>> 8);
                    i = i23 + 1;
                    buf[i23] = (byte) x2;
                }
            }
            if (this.body.length != 0) {
                int i24 = i;
                int i25 = i + 1;
                buf[i24] = 4;
                float[] a2 = this.body;
                int l2 = a2.length;
                if (l2 > 65536) {
                    throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.body length %d exceeds %d elements", Integer.valueOf(l2), Integer.valueOf((int) colferListMax)));
                }
                while (l2 > 127) {
                    int i26 = i25;
                    i25++;
                    buf[i26] = (byte) (l2 | 128);
                    l2 >>>= 7;
                }
                int i27 = i25;
                i = i25 + 1;
                buf[i27] = (byte) l2;
                for (float f2 : a2) {
                    int x3 = Float.floatToRawIntBits(f2);
                    int i28 = i;
                    int i29 = i + 1;
                    buf[i28] = (byte) (x3 >>> 24);
                    int i30 = i29 + 1;
                    buf[i29] = (byte) (x3 >>> 16);
                    int i31 = i30 + 1;
                    buf[i30] = (byte) (x3 >>> 8);
                    i = i31 + 1;
                    buf[i31] = (byte) x3;
                }
            }
            if (this.leftArm.length != 0) {
                int i32 = i;
                int i33 = i + 1;
                buf[i32] = 5;
                float[] a3 = this.leftArm;
                int l3 = a3.length;
                if (l3 > 65536) {
                    throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.leftArm length %d exceeds %d elements", Integer.valueOf(l3), Integer.valueOf((int) colferListMax)));
                }
                while (l3 > 127) {
                    int i34 = i33;
                    i33++;
                    buf[i34] = (byte) (l3 | 128);
                    l3 >>>= 7;
                }
                int i35 = i33;
                i = i33 + 1;
                buf[i35] = (byte) l3;
                for (float f3 : a3) {
                    int x4 = Float.floatToRawIntBits(f3);
                    int i36 = i;
                    int i37 = i + 1;
                    buf[i36] = (byte) (x4 >>> 24);
                    int i38 = i37 + 1;
                    buf[i37] = (byte) (x4 >>> 16);
                    int i39 = i38 + 1;
                    buf[i38] = (byte) (x4 >>> 8);
                    i = i39 + 1;
                    buf[i39] = (byte) x4;
                }
            }
            if (this.rightArm.length != 0) {
                int i40 = i;
                int i41 = i + 1;
                buf[i40] = 6;
                float[] a4 = this.rightArm;
                int l4 = a4.length;
                if (l4 > 65536) {
                    throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.rightArm length %d exceeds %d elements", Integer.valueOf(l4), Integer.valueOf((int) colferListMax)));
                }
                while (l4 > 127) {
                    int i42 = i41;
                    i41++;
                    buf[i42] = (byte) (l4 | 128);
                    l4 >>>= 7;
                }
                int i43 = i41;
                i = i41 + 1;
                buf[i43] = (byte) l4;
                for (float f4 : a4) {
                    int x5 = Float.floatToRawIntBits(f4);
                    int i44 = i;
                    int i45 = i + 1;
                    buf[i44] = (byte) (x5 >>> 24);
                    int i46 = i45 + 1;
                    buf[i45] = (byte) (x5 >>> 16);
                    int i47 = i46 + 1;
                    buf[i46] = (byte) (x5 >>> 8);
                    i = i47 + 1;
                    buf[i47] = (byte) x5;
                }
            }
            if (this.leftLeg.length != 0) {
                int i48 = i;
                int i49 = i + 1;
                buf[i48] = 7;
                float[] a5 = this.leftLeg;
                int l5 = a5.length;
                if (l5 > 65536) {
                    throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.leftLeg length %d exceeds %d elements", Integer.valueOf(l5), Integer.valueOf((int) colferListMax)));
                }
                while (l5 > 127) {
                    int i50 = i49;
                    i49++;
                    buf[i50] = (byte) (l5 | 128);
                    l5 >>>= 7;
                }
                int i51 = i49;
                i = i49 + 1;
                buf[i51] = (byte) l5;
                for (float f5 : a5) {
                    int x6 = Float.floatToRawIntBits(f5);
                    int i52 = i;
                    int i53 = i + 1;
                    buf[i52] = (byte) (x6 >>> 24);
                    int i54 = i53 + 1;
                    buf[i53] = (byte) (x6 >>> 16);
                    int i55 = i54 + 1;
                    buf[i54] = (byte) (x6 >>> 8);
                    i = i55 + 1;
                    buf[i55] = (byte) x6;
                }
            }
            if (this.rightLeg.length != 0) {
                int i56 = i;
                int i57 = i + 1;
                buf[i56] = 8;
                float[] a6 = this.rightLeg;
                int l6 = a6.length;
                if (l6 > 65536) {
                    throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.rightLeg length %d exceeds %d elements", Integer.valueOf(l6), Integer.valueOf((int) colferListMax)));
                }
                while (l6 > 127) {
                    int i58 = i57;
                    i57++;
                    buf[i58] = (byte) (l6 | 128);
                    l6 >>>= 7;
                }
                int i59 = i57;
                i = i57 + 1;
                buf[i59] = (byte) l6;
                for (float f6 : a6) {
                    int x7 = Float.floatToRawIntBits(f6);
                    int i60 = i;
                    int i61 = i + 1;
                    buf[i60] = (byte) (x7 >>> 24);
                    int i62 = i61 + 1;
                    buf[i61] = (byte) (x7 >>> 16);
                    int i63 = i62 + 1;
                    buf[i62] = (byte) (x7 >>> 8);
                    i = i63 + 1;
                    buf[i63] = (byte) x7;
                }
            }
            if (this.equipment.length != 0) {
                int i64 = i;
                int i65 = i + 1;
                buf[i64] = 9;
                String[] a7 = this.equipment;
                int x8 = a7.length;
                if (x8 > 65536) {
                    throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.equipment length %d exceeds %d elements", Integer.valueOf(x8), Integer.valueOf((int) colferListMax)));
                }
                while (x8 > 127) {
                    int i66 = i65;
                    i65++;
                    buf[i66] = (byte) (x8 | 128);
                    x8 >>>= 7;
                }
                int i67 = i65;
                i = i65 + 1;
                buf[i67] = (byte) x8;
                for (int ai = 0; ai < a7.length; ai++) {
                    String s2 = a7[ai];
                    if (s2 == null) {
                        s2 = "";
                        a7[ai] = s2;
                    }
                    i++;
                    int sIndex2 = 0;
                    int sLength2 = s2.length();
                    while (sIndex2 < sLength2) {
                        char c2 = s2.charAt(sIndex2);
                        if (c2 < 128) {
                            int i68 = i;
                            i++;
                            buf[i68] = (byte) c2;
                        } else if (c2 < 2048) {
                            int i69 = i;
                            int i70 = i + 1;
                            buf[i69] = (byte) (192 | (c2 >>> 6));
                            i = i70 + 1;
                            buf[i70] = (byte) (128 | (c2 & '?'));
                        } else if (c2 < 55296 || c2 > 57343) {
                            int i71 = i;
                            int i72 = i + 1;
                            buf[i71] = (byte) (224 | (c2 >>> '\f'));
                            int i73 = i72 + 1;
                            buf[i72] = (byte) (128 | ((c2 >>> 6) & 63));
                            i = i73 + 1;
                            buf[i73] = (byte) (128 | (c2 & '?'));
                        } else {
                            sIndex2++;
                            int cp2 = sIndex2 < sLength2 ? Character.toCodePoint(c2, s2.charAt(sIndex2)) : 0;
                            if (cp2 >= 65536 && cp2 < 2097152) {
                                int i74 = i;
                                int i75 = i + 1;
                                buf[i74] = (byte) (240 | (cp2 >>> 18));
                                int i76 = i75 + 1;
                                buf[i75] = (byte) (128 | ((cp2 >>> 12) & 63));
                                int i77 = i76 + 1;
                                buf[i76] = (byte) (128 | ((cp2 >>> 6) & 63));
                                i = i77 + 1;
                                buf[i77] = (byte) (128 | (cp2 & 63));
                            } else {
                                int i78 = i;
                                i++;
                                buf[i78] = 63;
                            }
                        }
                        sIndex2++;
                    }
                    int size2 = i - i;
                    if (size2 > 16777216) {
                        throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.equipment[%d] size %d exceeds %d UTF-8 bytes", Integer.valueOf(ai), Integer.valueOf(size2), 16777216));
                    }
                    int ii2 = i - 1;
                    if (size2 > 127) {
                        i++;
                        for (int y = size2; y >= 16384; y >>>= 7) {
                            i++;
                        }
                        System.arraycopy(buf, i, buf, i - size2, size2);
                        do {
                            int i79 = ii2;
                            ii2++;
                            buf[i79] = (byte) (size2 | 128);
                            size2 >>>= 7;
                        } while (size2 > 127);
                    }
                    buf[ii2] = (byte) size2;
                }
            }
            if (this.offset.length != 0) {
                int i80 = i;
                int i81 = i + 1;
                buf[i80] = 10;
                float[] a8 = this.offset;
                int l7 = a8.length;
                if (l7 > 65536) {
                    throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.offset length %d exceeds %d elements", Integer.valueOf(l7), Integer.valueOf((int) colferListMax)));
                }
                while (l7 > 127) {
                    int i82 = i81;
                    i81++;
                    buf[i82] = (byte) (l7 | 128);
                    l7 >>>= 7;
                }
                int i83 = i81;
                i = i81 + 1;
                buf[i83] = (byte) l7;
                for (float f7 : a8) {
                    int x9 = Float.floatToRawIntBits(f7);
                    int i84 = i;
                    int i85 = i + 1;
                    buf[i84] = (byte) (x9 >>> 24);
                    int i86 = i85 + 1;
                    buf[i85] = (byte) (x9 >>> 16);
                    int i87 = i86 + 1;
                    buf[i86] = (byte) (x9 >>> 8);
                    i = i87 + 1;
                    buf[i87] = (byte) x9;
                }
            }
            if (this.yaw != 0.0f) {
                int i88 = i;
                int i89 = i + 1;
                buf[i88] = 11;
                int x10 = Float.floatToRawIntBits(this.yaw);
                int i90 = i89 + 1;
                buf[i89] = (byte) (x10 >>> 24);
                int i91 = i90 + 1;
                buf[i90] = (byte) (x10 >>> 16);
                int i92 = i91 + 1;
                buf[i91] = (byte) (x10 >>> 8);
                i = i92 + 1;
                buf[i92] = (byte) x10;
            }
            int i93 = i;
            int i94 = i + 1;
            buf[i93] = Byte.MAX_VALUE;
            return i94;
        } catch (ArrayIndexOutOfBoundsException e) {
            if (i - offset > 16777216) {
                throw new IllegalStateException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData exceeds %d bytes", 16777216));
            }
            if (i > buf.length) {
                throw new BufferOverflowException();
            }
            throw e;
        }
    }

    public int unmarshal(byte[] buf, int offset) {
        return unmarshal(buf, offset, buf.length);
    }

    public int unmarshal(byte[] buf, int offset, int end) {
        if (end > buf.length) {
            end = buf.length;
        }
        try {
            int i = offset + 1;
            byte header = buf[offset];
            if (header == 0) {
                int size = 0;
                int shift = 0;
                while (true) {
                    int i2 = i;
                    i++;
                    byte b = buf[i2];
                    size |= (b & 127) << shift;
                    if (shift == 28 || b >= 0) {
                        break;
                    }
                    shift += 7;
                }
                if (size < 0 || size > 16777216) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.entityType size %d exceeds %d UTF-8 bytes", Integer.valueOf(size), 16777216));
                }
                int i3 = i + size;
                this.entityType = new String(buf, i, size, StandardCharsets.UTF_8);
                i = i3 + 1;
                header = buf[i3];
            }
            if (header == 1) {
                this.invisible = true;
                int i4 = i;
                i++;
                header = buf[i4];
            }
            if (header == 2) {
                this.small = true;
                int i5 = i;
                i++;
                header = buf[i5];
            }
            if (header == 3) {
                int length = 0;
                int shift2 = 0;
                while (true) {
                    int i6 = i;
                    i++;
                    byte b2 = buf[i6];
                    length |= (b2 & 127) << shift2;
                    if (shift2 == 28 || b2 >= 0) {
                        break;
                    }
                    shift2 += 7;
                }
                if (length < 0 || length > 65536) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.head length %d exceeds %d elements", Integer.valueOf(length), Integer.valueOf((int) colferListMax)));
                }
                float[] a = new float[length];
                for (int ai = 0; ai < length; ai++) {
                    int i7 = i;
                    int i8 = i + 1;
                    int i9 = i8 + 1;
                    int i10 = i9 + 1;
                    i = i10 + 1;
                    int x = ((buf[i7] & 255) << 24) | ((buf[i8] & 255) << 16) | ((buf[i9] & 255) << 8) | (buf[i10] & 255);
                    a[ai] = Float.intBitsToFloat(x);
                }
                this.head = a;
                int i11 = i;
                i++;
                header = buf[i11];
            }
            if (header == 4) {
                int length2 = 0;
                int shift3 = 0;
                while (true) {
                    int i12 = i;
                    i++;
                    byte b3 = buf[i12];
                    length2 |= (b3 & 127) << shift3;
                    if (shift3 == 28 || b3 >= 0) {
                        break;
                    }
                    shift3 += 7;
                }
                if (length2 < 0 || length2 > 65536) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.body length %d exceeds %d elements", Integer.valueOf(length2), Integer.valueOf((int) colferListMax)));
                }
                float[] a2 = new float[length2];
                for (int ai2 = 0; ai2 < length2; ai2++) {
                    int i13 = i;
                    int i14 = i + 1;
                    int i15 = i14 + 1;
                    int i16 = i15 + 1;
                    i = i16 + 1;
                    int x2 = ((buf[i13] & 255) << 24) | ((buf[i14] & 255) << 16) | ((buf[i15] & 255) << 8) | (buf[i16] & 255);
                    a2[ai2] = Float.intBitsToFloat(x2);
                }
                this.body = a2;
                int i17 = i;
                i++;
                header = buf[i17];
            }
            if (header == 5) {
                int length3 = 0;
                int shift4 = 0;
                while (true) {
                    int i18 = i;
                    i++;
                    byte b4 = buf[i18];
                    length3 |= (b4 & 127) << shift4;
                    if (shift4 == 28 || b4 >= 0) {
                        break;
                    }
                    shift4 += 7;
                }
                if (length3 < 0 || length3 > 65536) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.leftArm length %d exceeds %d elements", Integer.valueOf(length3), Integer.valueOf((int) colferListMax)));
                }
                float[] a3 = new float[length3];
                for (int ai3 = 0; ai3 < length3; ai3++) {
                    int i19 = i;
                    int i20 = i + 1;
                    int i21 = i20 + 1;
                    int i22 = i21 + 1;
                    i = i22 + 1;
                    int x3 = ((buf[i19] & 255) << 24) | ((buf[i20] & 255) << 16) | ((buf[i21] & 255) << 8) | (buf[i22] & 255);
                    a3[ai3] = Float.intBitsToFloat(x3);
                }
                this.leftArm = a3;
                int i23 = i;
                i++;
                header = buf[i23];
            }
            if (header == 6) {
                int length4 = 0;
                int shift5 = 0;
                while (true) {
                    int i24 = i;
                    i++;
                    byte b5 = buf[i24];
                    length4 |= (b5 & 127) << shift5;
                    if (shift5 == 28 || b5 >= 0) {
                        break;
                    }
                    shift5 += 7;
                }
                if (length4 < 0 || length4 > 65536) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.rightArm length %d exceeds %d elements", Integer.valueOf(length4), Integer.valueOf((int) colferListMax)));
                }
                float[] a4 = new float[length4];
                for (int ai4 = 0; ai4 < length4; ai4++) {
                    int i25 = i;
                    int i26 = i + 1;
                    int i27 = i26 + 1;
                    int i28 = i27 + 1;
                    i = i28 + 1;
                    int x4 = ((buf[i25] & 255) << 24) | ((buf[i26] & 255) << 16) | ((buf[i27] & 255) << 8) | (buf[i28] & 255);
                    a4[ai4] = Float.intBitsToFloat(x4);
                }
                this.rightArm = a4;
                int i29 = i;
                i++;
                header = buf[i29];
            }
            if (header == 7) {
                int length5 = 0;
                int shift6 = 0;
                while (true) {
                    int i30 = i;
                    i++;
                    byte b6 = buf[i30];
                    length5 |= (b6 & 127) << shift6;
                    if (shift6 == 28 || b6 >= 0) {
                        break;
                    }
                    shift6 += 7;
                }
                if (length5 < 0 || length5 > 65536) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.leftLeg length %d exceeds %d elements", Integer.valueOf(length5), Integer.valueOf((int) colferListMax)));
                }
                float[] a5 = new float[length5];
                for (int ai5 = 0; ai5 < length5; ai5++) {
                    int i31 = i;
                    int i32 = i + 1;
                    int i33 = i32 + 1;
                    int i34 = i33 + 1;
                    i = i34 + 1;
                    int x5 = ((buf[i31] & 255) << 24) | ((buf[i32] & 255) << 16) | ((buf[i33] & 255) << 8) | (buf[i34] & 255);
                    a5[ai5] = Float.intBitsToFloat(x5);
                }
                this.leftLeg = a5;
                int i35 = i;
                i++;
                header = buf[i35];
            }
            if (header == 8) {
                int length6 = 0;
                int shift7 = 0;
                while (true) {
                    int i36 = i;
                    i++;
                    byte b7 = buf[i36];
                    length6 |= (b7 & 127) << shift7;
                    if (shift7 == 28 || b7 >= 0) {
                        break;
                    }
                    shift7 += 7;
                }
                if (length6 < 0 || length6 > 65536) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.rightLeg length %d exceeds %d elements", Integer.valueOf(length6), Integer.valueOf((int) colferListMax)));
                }
                float[] a6 = new float[length6];
                for (int ai6 = 0; ai6 < length6; ai6++) {
                    int i37 = i;
                    int i38 = i + 1;
                    int i39 = i38 + 1;
                    int i40 = i39 + 1;
                    i = i40 + 1;
                    int x6 = ((buf[i37] & 255) << 24) | ((buf[i38] & 255) << 16) | ((buf[i39] & 255) << 8) | (buf[i40] & 255);
                    a6[ai6] = Float.intBitsToFloat(x6);
                }
                this.rightLeg = a6;
                int i41 = i;
                i++;
                header = buf[i41];
            }
            if (header == 9) {
                int length7 = 0;
                int shift8 = 0;
                while (true) {
                    int i42 = i;
                    i++;
                    byte b8 = buf[i42];
                    length7 |= (b8 & 127) << shift8;
                    if (shift8 == 28 || b8 >= 0) {
                        break;
                    }
                    shift8 += 7;
                }
                if (length7 < 0 || length7 > 65536) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.equipment length %d exceeds %d elements", Integer.valueOf(length7), Integer.valueOf((int) colferListMax)));
                }
                String[] a7 = new String[length7];
                for (int ai7 = 0; ai7 < length7; ai7++) {
                    int size2 = 0;
                    int shift9 = 0;
                    while (true) {
                        int i43 = i;
                        i++;
                        byte b9 = buf[i43];
                        size2 |= (b9 & 127) << shift9;
                        if (shift9 == 28 || b9 >= 0) {
                            break;
                        }
                        shift9 += 7;
                    }
                    if (size2 < 0 || size2 > 16777216) {
                        throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.equipment[%d] size %d exceeds %d UTF-8 bytes", Integer.valueOf(ai7), Integer.valueOf(size2), 16777216));
                    }
                    i += size2;
                    a7[ai7] = new String(buf, i, size2, StandardCharsets.UTF_8);
                }
                this.equipment = a7;
                int i44 = i;
                i++;
                header = buf[i44];
            }
            if (header == 10) {
                int length8 = 0;
                int shift10 = 0;
                while (true) {
                    int i45 = i;
                    i++;
                    byte b10 = buf[i45];
                    length8 |= (b10 & 127) << shift10;
                    if (shift10 == 28 || b10 >= 0) {
                        break;
                    }
                    shift10 += 7;
                }
                if (length8 < 0 || length8 > 65536) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData.offset length %d exceeds %d elements", Integer.valueOf(length8), Integer.valueOf((int) colferListMax)));
                }
                float[] a8 = new float[length8];
                for (int ai8 = 0; ai8 < length8; ai8++) {
                    int i46 = i;
                    int i47 = i + 1;
                    int i48 = i47 + 1;
                    int i49 = i48 + 1;
                    i = i49 + 1;
                    int x7 = ((buf[i46] & 255) << 24) | ((buf[i47] & 255) << 16) | ((buf[i48] & 255) << 8) | (buf[i49] & 255);
                    a8[ai8] = Float.intBitsToFloat(x7);
                }
                this.offset = a8;
                int i50 = i;
                i++;
                header = buf[i50];
            }
            if (header == 11) {
                int i51 = i;
                int i52 = i + 1;
                int i53 = i52 + 1;
                int i54 = i53 + 1;
                int i55 = i54 + 1;
                int x8 = ((buf[i51] & 255) << 24) | ((buf[i52] & 255) << 16) | ((buf[i53] & 255) << 8) | (buf[i54] & 255);
                this.yaw = Float.intBitsToFloat(x8);
                i = i55 + 1;
                header = buf[i55];
            }
            if (header != Byte.MAX_VALUE) {
                throw new InputMismatchException(String.format("colfer: unknown header at byte %d", Integer.valueOf(i - 1)));
            }
            if (i <= end || end - offset >= 16777216) {
                if (i < 0 || i - offset > 16777216) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData exceeds %d bytes", 16777216));
                }
                if (i > end) {
                    throw new BufferUnderflowException();
                }
                return i;
            }
            throw new BufferUnderflowException();
        } catch (Throwable th) {
            if (offset <= end || end - offset >= 16777216) {
                if (offset < 0 || offset - offset > 16777216) {
                    throw new SecurityException(String.format("colfer: me.atilt.supplydrops.colfer/colfer.ArmorStandMockData exceeds %d bytes", 16777216));
                }
                if (offset > end) {
                    throw new BufferUnderflowException();
                }
                throw th;
            }
            throw new BufferUnderflowException();
        }
    }

    @Serial
    private void writeObject(ObjectOutputStream out) throws IOException {
        byte[] buf = new byte[4096];
        while (true) {
            try {
                int n = marshal(buf, 0);
                out.writeInt(n);
                out.write(buf, 0, n);
                return;  // Si hay más lógica para agregar después del bucle, considera mover este retorno.
            } catch (BufferUnderflowException e) {
                buf = new byte[4 * buf.length];  // Expande el tamaño del buffer en caso de BufferUnderflowException
            }
        }
    }

    private void readObject(ObjectInputStream in) throws ClassNotFoundException, IOException {
        init();
        int n = in.readInt();
        byte[] buf = new byte[n];
        in.readFully(buf);
        unmarshal(buf, 0);
    }

    private void readObjectNoData() throws ObjectStreamException {
        init();
    }

    public String getEntityType() {
        return this.entityType;
    }

    public void setEntityType(String value) {
        this.entityType = value;
    }

    public ArmorStandMockData withEntityType(String value) {
        this.entityType = value;
        return this;
    }

    public boolean getInvisible() {
        return this.invisible;
    }

    public void setInvisible(boolean value) {
        this.invisible = value;
    }

    public ArmorStandMockData withInvisible(boolean value) {
        this.invisible = value;
        return this;
    }

    public boolean getSmall() {
        return this.small;
    }

    public void setSmall(boolean value) {
        this.small = value;
    }

    public ArmorStandMockData withSmall(boolean value) {
        this.small = value;
        return this;
    }

    public float[] getHead() {
        return this.head;
    }

    public void setHead(float[] value) {
        this.head = value;
    }

    public ArmorStandMockData withHead(float[] value) {
        this.head = value;
        return this;
    }

    public float[] getBody() {
        return this.body;
    }

    public void setBody(float[] value) {
        this.body = value;
    }

    public ArmorStandMockData withBody(float[] value) {
        this.body = value;
        return this;
    }

    public float[] getLeftArm() {
        return this.leftArm;
    }

    public void setLeftArm(float[] value) {
        this.leftArm = value;
    }

    public ArmorStandMockData withLeftArm(float[] value) {
        this.leftArm = value;
        return this;
    }

    public float[] getRightArm() {
        return this.rightArm;
    }

    public void setRightArm(float[] value) {
        this.rightArm = value;
    }

    public ArmorStandMockData withRightArm(float[] value) {
        this.rightArm = value;
        return this;
    }

    public float[] getLeftLeg() {
        return this.leftLeg;
    }

    public void setLeftLeg(float[] value) {
        this.leftLeg = value;
    }

    public ArmorStandMockData withLeftLeg(float[] value) {
        this.leftLeg = value;
        return this;
    }

    public float[] getRightLeg() {
        return this.rightLeg;
    }

    public void setRightLeg(float[] value) {
        this.rightLeg = value;
    }

    public ArmorStandMockData withRightLeg(float[] value) {
        this.rightLeg = value;
        return this;
    }

    public String[] getEquipment() {
        return this.equipment;
    }

    public void setEquipment(String[] value) {
        this.equipment = value;
    }

    public ArmorStandMockData withEquipment(String[] value) {
        this.equipment = value;
        return this;
    }

    public float[] getOffset() {
        return this.offset;
    }

    public void setOffset(float[] value) {
        this.offset = value;
    }

    public ArmorStandMockData withOffset(float[] value) {
        this.offset = value;
        return this;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setYaw(float value) {
        this.yaw = value;
    }

    public ArmorStandMockData withYaw(float value) {
        this.yaw = value;
        return this;
    }

    public final int hashCode() {
        int h = this.entityType != null ? (31 * 1) + this.entityType.hashCode() : 1;
        int h2 = (31 * ((31 * ((31 * ((31 * ((31 * ((31 * ((31 * ((31 * h) + (this.invisible ? 1231 : 1237))) + (this.small ? 1231 : 1237))) + Arrays.hashCode(this.head))) + Arrays.hashCode(this.body))) + Arrays.hashCode(this.leftArm))) + Arrays.hashCode(this.rightArm))) + Arrays.hashCode(this.leftLeg))) + Arrays.hashCode(this.rightLeg);
        String[] strArr = this.equipment;
        int length = strArr.length;
        for (int i = 0; i < length; i++) {
            String o = strArr[i];
            h2 = (31 * h2) + (o == null ? 0 : o.hashCode());
        }
        return (31 * ((31 * h2) + Arrays.hashCode(this.offset))) + Float.floatToIntBits(this.yaw);
    }

    public final boolean equals(Object o) {
        return (o instanceof ArmorStandMockData) && equals((ArmorStandMockData) o);
    }

    public final boolean equals(ArmorStandMockData o) {
        if (o == null) {
            return false;
        }
        if (o == this) {
            return true;
        }
        return o.getClass() == ArmorStandMockData.class && (this.entityType != null ? this.entityType.equals(o.entityType) : o.entityType == null) && this.invisible == o.invisible && this.small == o.small && Arrays.equals(this.head, o.head) && Arrays.equals(this.body, o.body) && Arrays.equals(this.leftArm, o.leftArm) && Arrays.equals(this.rightArm, o.rightArm) && Arrays.equals(this.leftLeg, o.leftLeg) && Arrays.equals(this.rightLeg, o.rightLeg) && Arrays.equals(this.equipment, o.equipment) && Arrays.equals(this.offset, o.offset) && (this.yaw == o.yaw || !(this.yaw == this.yaw || o.yaw == o.yaw));
    }

    public ItemStack[] toBukkitItems() {
        ItemStack[] itemStacks = new ItemStack[this.equipment.length];
        for (int i = 0; i < this.equipment.length; i++) {
            try {
                String material = this.equipment[i];
                if (material != null && !material.isEmpty()) {
                    itemStacks[i] = new ItemStack(Material.valueOf(material));
                }
            } catch (IllegalArgumentException exception) {
                itemStacks[i] = new ItemStack(Material.STONE);
                exception.printStackTrace();
            }
        }
        return itemStacks;
    }
}

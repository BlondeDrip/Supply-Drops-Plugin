package me.atilt.supplydrops.api.model;

import java.util.Collection;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/Composite.class */
public interface Composite<C> {
    @Nonnull
    Composite<C> bind(@Nonnull C c);

    Composite<C> bindAll(@Nonnull Collection<C> collection);
}

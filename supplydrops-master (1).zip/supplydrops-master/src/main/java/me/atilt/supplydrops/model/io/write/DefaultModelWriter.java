package me.atilt.supplydrops.model.io.write;

import java.nio.file.Path;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.Model;
import me.atilt.supplydrops.api.model.io.ConcurrentFileAccessor;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/io/write/DefaultModelWriter.class */
public final class DefaultModelWriter implements ModelWriter {
    private final Path target;
    private final Collection<Model> models = new LinkedList();
    private final ConcurrentFileAccessor<Model> fileAccessor;

    public DefaultModelWriter(@Nonnull Path target, @Nonnull ConcurrentFileAccessor<Model> fileAccessor) {
        this.target = target;
        this.fileAccessor = fileAccessor;
    }

    @Nonnull
    public Collection<Model> models() {
        return Collections.unmodifiableCollection(this.models);
    }

    @Override // me.atilt.supplydrops.model.io.write.ModelWriter
    @Nonnull
    public Path target() {
        return this.target;
    }

    @Override // me.atilt.supplydrops.model.io.write.ModelWriter
    public void supply(@Nonnull Supplier<Collection<Model>> models) {
        this.models.addAll(models.get());
    }

    public void write() {
    }
}

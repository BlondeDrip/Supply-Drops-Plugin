package me.atilt.supplydrops.model.io;

import java.nio.file.Path;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.model.io.read.ModelReader;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/io/ModelIO.class */
public interface ModelIO extends AutoCloseable {
    @Nonnull
    Path target();

    @Nonnull
    ModelReader newReader();
}

package me.atilt.supplydrops;

import java.util.Collections;
import java.util.Map;
import java.util.function.Consumer;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.distributor.Distributor;
import me.atilt.supplydrops.loot.probability.Probability;
import me.atilt.supplydrops.occurrence.periodicity.Periodicity;
import me.atilt.supplydrops.supplydrop.LandingData;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.PartitionedSetTask;
import me.atilt.supplydrops.util.Task;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.scheduler.BukkitTask;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/DistributorTicker.class */
public final class DistributorTicker implements ConfigurationSerializable, AutoCloseable {
    private PartitionedSetTask expirationSetTask;
    private PartitionedSetTask supplyDropTask;
    private Periodicity occurrence;

    public DistributorTicker(Periodicity occurrence) {
        this.occurrence = occurrence;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/DistributorTicker$ExpirationTask.class */
    public static final class ExpirationTask implements Task {
        private final SupplyDrop supplyDrop;

        public ExpirationTask(SupplyDrop supplyDrop) {
            this.supplyDrop = supplyDrop;
        }

        @Override // java.lang.Runnable
        public void run() {
            LandingData landingData;
            if (this.supplyDrop.canSpawn() && (landingData = this.supplyDrop.landingData()) != null && landingData.isExpired()) {
                for (Chunk chunk : landingData.getChunk()) {
                    chunk.removePluginChunkTicket(SupplyDropsPlugin.self());
                }
                this.supplyDrop.interaction().clear();
                Location location = this.supplyDrop.model().getLocation();
                if (location != null) {
                    location.getWorld().spawnParticle(Particle.EXPLOSION_HUGE, location.clone().add(0.0d, 0.1d, 0.0d), 13, 1.24d, 0.1d, 1.24d, 0.0d);
                    location.getWorld().playSound(location, Sound.BLOCK_BIG_DRIPLEAF_BREAK, 2.0f, 0.5f);
                }
                this.supplyDrop.model().unrender();
                this.supplyDrop.setLandingData(null);
                this.supplyDrop.close();
                SupplyDropsPlugin.self().getTicker().unTickSupplyDrop(this.supplyDrop, 1);
                if (this.supplyDrop.getPlayerOwned() != null) {
                    SupplyDropsPlugin.self().getModelRegistry().unregister(this.supplyDrop.modelData().getId());
                    SupplyDropsPlugin.self().supplyDropRegistry().unregister(this.supplyDrop.id());
                }
            }
        }

        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o instanceof ExpirationTask) {
                ExpirationTask that = (ExpirationTask) o;
                return this.supplyDrop.id() == that.supplyDrop.id();
            }
            return false;
        }

        public int hashCode() {
            return this.supplyDrop.id();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/DistributorTicker$SupplyDropTask.class */
    public final class SupplyDropTask implements Task {
        private final SupplyDrop supplyDrop;

        public SupplyDropTask(SupplyDrop supplyDrop) {
            this.supplyDrop = supplyDrop;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.supplyDrop.getPlayerOwned() == null && !this.supplyDrop.lootTable().empty() && !this.supplyDrop.modelData().empty()) {
                final int rolls = this.supplyDrop.rolls();
                Bukkit.getScheduler().runTaskTimer(SupplyDropsPlugin.self(), new Consumer<BukkitTask>() { // from class: me.atilt.supplydrops.DistributorTicker.SupplyDropTask.1
                    private int current;

                    @Override // java.util.function.Consumer
                    public void accept(BukkitTask task) {
                        if (this.current < rolls) {
                            Probability probability = SupplyDropTask.this.supplyDrop.probability();
                            if (probability.test()) {
                                DistributorTicker.this.distribute(SupplyDropTask.this.supplyDrop.distributor(), SupplyDropTask.this.supplyDrop, 1);
                            }
                            this.current++;
                            return;
                        }
                        task.cancel();
                    }
                }, 0L, 10L);
            }
        }

        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o instanceof SupplyDropTask) {
                SupplyDropTask that = (SupplyDropTask) o;
                return this.supplyDrop.id() == that.supplyDrop.id();
            }
            return false;
        }

        public int hashCode() {
            return this.supplyDrop.id();
        }
    }

    public void tickSupplyDrop(SupplyDrop supplyDrop) {
        this.supplyDropTask.addPartition(new SupplyDropTask(supplyDrop));
        this.expirationSetTask.addPartition(new ExpirationTask(supplyDrop));
    }

    public void unTickSupplyDrop(SupplyDrop supplyDrop, int id) {
        this.supplyDropTask.removePartition(new SupplyDropTask(supplyDrop));
        this.expirationSetTask.removePartition(new ExpirationTask(supplyDrop));
    }

    public void start(@Nonnull SupplyDropsPlugin plugin) {
        this.expirationSetTask = new PartitionedSetTask(plugin, 2, 3, () -> {
            return true;
        });
        this.supplyDropTask = new PartitionedSetTask(plugin, 1, 20, () -> {
            if (this.occurrence.origin() == null) {
                this.occurrence.start();
                return false;
            } else if (this.occurrence.test()) {
                this.occurrence.start();
                return true;
            } else {
                return false;
            }
        });
        this.expirationSetTask.start();
        this.supplyDropTask.start();
    }

    private void distribute(Distributor<SupplyDrop> distributor, SupplyDrop supplyDrop, int attempts) {
        distributor.distribute(supplyDrop, attempts, locationAttempt -> {
            if (!supplyDrop.canSpawn() || locationAttempt.getLast()) {
                return;
            }
            if (locationAttempt.getTotal() >= SupplyDropsPlugin.self().getConfig().getInt("supply-drops.landing-attempts")) {
                SupplyDropsPlugin.self().getLogger().warning(ChatColor.RED + "Spawning exceeded max attempts. Try increasing the value in the config if this issue persists.");
            } else {
                distribute(distributor, supplyDrop, attempts + 1);
            }
        });
    }

    public Periodicity getOccurrence() {
        return this.occurrence;
    }

    public void setOccurrence(Periodicity occurrence) {
        this.occurrence = occurrence;
    }

    @Nonnull
    public Map<String, Object> serialize() {
        return Collections.singletonMap("occurrence", this.occurrence);
    }

    public static DistributorTicker deserialize(@Nonnull Map<String, Object> tree) {
        return new DistributorTicker((Periodicity) tree.get("occurrence"));
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        if (this.expirationSetTask != null) {
            this.expirationSetTask.stop();
        }
        if (this.supplyDropTask != null) {
            this.supplyDropTask.stop();
        }
    }
}

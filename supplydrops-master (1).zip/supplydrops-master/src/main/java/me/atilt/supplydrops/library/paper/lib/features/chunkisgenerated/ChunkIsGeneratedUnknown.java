package me.atilt.supplydrops.library.paper.lib.features.chunkisgenerated;

import org.bukkit.World;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/chunkisgenerated/ChunkIsGeneratedUnknown.class */
public class ChunkIsGeneratedUnknown implements ChunkIsGenerated {
    @Override // me.atilt.supplydrops.library.paper.lib.features.chunkisgenerated.ChunkIsGenerated
    public boolean isChunkGenerated(World world, int x, int z) {
        return true;
    }
}

package me.atilt.supplydrops;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.supplydrop.Color;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/ColorData.class */
public class ColorData implements ConfigurationSerializable {
    private Color parachuteColor;
    private Color boxColor;

    @Nonnull
    public static ColorData defaultDisplay() {
        return new ColorData(Color.LIGHT_GRAY, Color.GRAY);
    }

    public ColorData(Color parachuteColor, Color boxColor) {
        this.parachuteColor = parachuteColor;
        this.boxColor = boxColor;
    }

    public Color getParachuteColor() {
        return this.parachuteColor;
    }

    public Color getBoxColor() {
        return this.boxColor;
    }

    public void setParachuteColor(Color parachuteColor) {
        this.parachuteColor = parachuteColor;
    }

    public void setBoxColor(Color boxColor) {
        this.boxColor = boxColor;
    }

    @Nonnull
    public ColorData duplicate() {
        return new ColorData(this.parachuteColor, this.boxColor);
    }

    @Nonnull
    public Map<String, Object> serialize() {
        Map<String, Object> tree = new HashMap<>(2);
        tree.put("parachute", this.parachuteColor.name());
        tree.put("box", this.boxColor.name());
        return tree;
    }

    @Nonnull
    public static ColorData deserialize(@Nonnull Map<String, Object> tree) {
        return new ColorData(Color.valueOf((String) tree.get("parachute")), Color.valueOf((String) tree.get("box")));
    }
}

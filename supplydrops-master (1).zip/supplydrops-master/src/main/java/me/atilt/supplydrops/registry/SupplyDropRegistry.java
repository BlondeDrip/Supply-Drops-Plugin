package me.atilt.supplydrops.registry;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/registry/SupplyDropRegistry.class */
public final class SupplyDropRegistry implements Int2ObjectRegistry<SupplyDrop> {
    private final Int2ObjectMap<SupplyDrop> supplyDrops = new Int2ObjectOpenHashMap();
    private static AtomicInteger IDs = new AtomicInteger(-100);

    public int freeId() {
        for (int i = 0; i < Integer.MAX_VALUE; i++) {
            if (this.supplyDrops.get(i) == null) {
                return i;
            }
        }
        return -1;
    }

    public static void initIds(int id) {
        IDs = new AtomicInteger(id);
    }

    @Nonnegative
    public static int nextId() {
        AtomicInteger atomicInteger;
        if (IDs == null) {
            atomicInteger = new AtomicInteger(1);
            IDs = atomicInteger;
        } else {
            atomicInteger = IDs;
        }
        return atomicInteger.getAndIncrement();
    }

    public SupplyDrop register2(int id, @Nonnull SupplyDrop supplyDrop) {
        return this.supplyDrops.put(id, supplyDrop);
    }

    @Nullable
    @Override
    public SupplyDrop register(int i, @NotNull SupplyDrop supplyDrop) {
        return this.supplyDrops.put(i, supplyDrop);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.registry.Int2ObjectRegistry
    @Nullable
    public SupplyDrop unregister(int id) {
        return this.supplyDrops.remove(id);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.registry.Int2ObjectRegistry
    @Nullable
    public SupplyDrop get(int id) {
        return this.supplyDrops.get(id);
    }

    @Override // me.atilt.supplydrops.registry.Int2ObjectRegistry
    @Nonnull
    public SupplyDrop getOrDefault(int id, @Nonnull SupplyDrop supplyDrop) {
        return this.supplyDrops.getOrDefault(id, supplyDrop);
    }

    @Nullable
    @Override
    public SupplyDrop register(@NotNull Integer integer, @NotNull SupplyDrop supplyDrop) {
        return null;
    }

    @Override // me.atilt.supplydrops.registry.Registry
    public void register(@Nonnull Map<? extends Integer, ? extends SupplyDrop> all) {
        this.supplyDrops.putAll(all);
    }

    @NotNull
    @Override
    public SupplyDrop getOrDefault(@NotNull Integer integer, @NotNull SupplyDrop supplyDrop) {
        return null;
    }

    @Override // me.atilt.supplydrops.registry.Registry
    public int size() {
        return this.supplyDrops.size();
    }

    @Override // me.atilt.supplydrops.registry.Registry
    @Nonnull
    public Map<Integer, SupplyDrop> all() {
        return Collections.unmodifiableMap(this.supplyDrops);
    }

    @Override // me.atilt.supplydrops.registry.Int2ObjectRegistry
    public ObjectIterator<Int2ObjectMap.Entry<SupplyDrop>> intIterator() {
        return Int2ObjectMaps.fastIterator(this.supplyDrops);
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        this.supplyDrops.clear();
    }
}

package me.atilt.supplydrops.loot;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.loot.probability.Probability;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/loot/ItemLootEntry.class */
public final class ItemLootEntry implements LootEntry<ItemStack> {
    private Probability probability;
    private int rolls;
    private final ItemStack itemStack;

    private ItemLootEntry(@Nonnull Probability probability, @Nonnegative int rolls, @Nonnull ItemStack itemStack) {
        this.probability = probability;
        this.rolls = rolls;
        this.itemStack = itemStack;
    }

    @Nonnull
    public static Builder newBuilder() {
        return new Builder();
    }

    @Override // me.atilt.supplydrops.loot.LootEntry
    @Nonnull
    public Probability probability() {
        return this.probability;
    }

    @Override // me.atilt.supplydrops.loot.LootEntry
    public void probability(@Nonnull Probability probability) {
        this.probability = probability;
    }

    @Override // me.atilt.supplydrops.loot.LootEntry
    public int rolls() {
        return this.rolls;
    }

    @Override // me.atilt.supplydrops.loot.LootEntry
    public void rolls(int rolls) {
        this.rolls = rolls;
    }

    @Override // java.util.function.Supplier
    public ItemStack get() {
        return this.itemStack.clone();
    }

    @Nonnull
    public Map<String, Object> serialize() {
        Map<String, Object> tree = new HashMap<>(3);
        tree.put("probability", this.probability);
        tree.put("rolls", Integer.valueOf(this.rolls));
        tree.put("item", this.itemStack);
        return tree;
    }

    @Nonnull
    public static LootEntry<ItemStack> deserialize(@Nonnull Map<String, Object> tree) {
        Probability probability = (Probability) tree.get("probability");
        int rolls = ((Integer) tree.get("rolls")).intValue();
        ItemStack itemStack = (ItemStack) tree.get("item");
        return new ItemLootEntry(probability, rolls, itemStack);
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/loot/ItemLootEntry$Builder.class */
    public static class Builder {
        private Probability probability;
        private int rolls;
        private ItemStack itemStack;

        private Builder() {
        }

        @Nonnull
        public Builder probability(@Nonnull Probability probability) {
            this.probability = probability;
            return this;
        }

        @Nonnull
        public Builder rolls(@Nonnegative int rolls) {
            this.rolls = rolls;
            return this;
        }

        @Nonnull
        public Builder item(@Nonnull ItemStack itemStack) {
            this.itemStack = itemStack;
            return this;
        }

        @Nonnull
        public LootEntry<ItemStack> build() {
            return new ItemLootEntry(this.probability, this.rolls, this.itemStack);
        }
    }
}

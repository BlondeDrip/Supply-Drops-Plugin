package me.atilt.supplydrops.api.model.packet;

import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/PacketWrapper.class */
public interface PacketWrapper<P> extends AutoCloseable {
    @Nonnull
    P handle();

    @Nonnull
    PacketWrapper<P> deepClone();
}

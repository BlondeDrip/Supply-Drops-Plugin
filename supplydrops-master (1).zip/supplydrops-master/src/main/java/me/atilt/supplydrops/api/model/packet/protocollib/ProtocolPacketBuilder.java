package me.atilt.supplydrops.api.model.packet.protocollib;

import com.comphenix.protocol.events.PacketContainer;
import java.util.List;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.Builder;
import me.atilt.supplydrops.api.model.packet.PacketBuilder;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/ProtocolPacketBuilder.class */
public abstract class ProtocolPacketBuilder implements PacketBuilder<PacketContainer> {
    protected final PacketContainer handle;

    public ProtocolPacketBuilder(@Nonnull PacketContainer handle) {
        this.handle = handle;
        this.handle.getModifier().writeDefaults();
    }

    @Override // me.atilt.supplydrops.api.model.Builder
    @Nonnull
    public Builder<PacketContainer> adapt(@Nonnull PacketContainer other) {
        List<Object> values = other.getModifier().getValues();
        for (int index = 0; index < values.size(); index++) {
            this.handle.getModifier().write(index, values.get(index));
        }
        return this;
    }

    @Override // me.atilt.supplydrops.api.model.Builder
    @Nonnull
    public PacketContainer build() {
        return this.handle;
    }
}

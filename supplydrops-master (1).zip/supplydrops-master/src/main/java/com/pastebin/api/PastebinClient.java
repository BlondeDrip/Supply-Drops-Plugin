package com.pastebin.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.pastebin.api.model.Paste;
import com.pastebin.api.model.User;
import com.pastebin.api.request.DeleteRequest;
import com.pastebin.api.request.ListRequest;
import com.pastebin.api.request.PasteRequest;
import com.pastebin.api.request.ShowPasteRequest;
import com.pastebin.api.request.UserRequest;
import com.pastebin.api.response.ListResponse;
import com.pastebin.api.response.ListResponseItem;
import com.pastebin.api.response.UserResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/PastebinClient.class */
public class PastebinClient {
    private static final String BASE_API_URL = "https://pastebin.com/api";
    private static final String BASE_RAW_URL = "https://pastebin.com/raw";
    private static final MediaType MEDIA_TYPE = MediaType.get("application/x-www-form-urlencoded");
    private final String developerKey;
    private final OkHttpClient client;
    private final XmlMapper mapper;
    private String userKey;

    private PastebinClient(String developerKey, String userKey) {
        this.client = new OkHttpClient();
        this.mapper = new XmlMapper();
        this.developerKey = developerKey;
        this.userKey = userKey;
    }

    public static Builder builder() {
        return new Builder();
    }

    public String login(String username, String password) throws PastebinException {
        if (this.userKey != null) {
            return this.userKey;
        }
        Map<String, String> parameters = new HashMap<>();
        parameters.put("api_user_name", username);
        parameters.put("api_user_password", password);
        this.userKey = post("api_login.php", parameters);
        return this.userKey;
    }

    public User user() throws PastebinException {
        if (this.userKey == null) {
            throw new IllegalStateException("Cannot retrieve user without user key. Please call login method first or provide user key to PastebinClient.");
        }
        String xml = post("api_post.php", new UserRequest().getParameters());
        try {
            UserResponse response = (UserResponse) this.mapper.readValue(xml, UserResponse.class);
            return new UserResponseConverter().convert(response);
        } catch (JsonProcessingException e) {
            throw new PastebinException("Could not parse response from Pastebin API: " + e.getMessage(), e);
        }
    }

    public List<Paste> list() throws PastebinException {
        return list(null);
    }

    public List<Paste> list(Integer limit) throws PastebinException {
        if (this.userKey == null) {
            throw new IllegalStateException("Cannot retrieve list of pastes without user key. Please call login method first or provide user key to PastebinClient.");
        }
        ListRequest request = limit != null ? ListRequest.limit(limit.intValue()) : new ListRequest();
        String xml = post("api_post.php", request.getParameters());
        if (xml.toLowerCase(Locale.ROOT).contains("no pastes found")) {
            return new ArrayList();
        }
        try {
            ListResponse response = (ListResponse) this.mapper.readValue("<response>" + xml + "</response>", ListResponse.class);
            Converter<List<ListResponseItem>, List<Paste>> converter = new ListResponseConverter();
            return converter.convert(response.getItems());
        } catch (JsonProcessingException e) {
            throw new PastebinException("Could not parse response from Pastebin API: " + e.getMessage(), e);
        }
    }

    public String paste(PasteRequest request) throws PastebinException {
        return post("api_post.php", request.getParameters());
    }

    public String getUserPaste(String pasteKey) throws PastebinException {
        if (this.userKey == null) {
            throw new IllegalStateException("Cannot get a user's paste without user key. Please call login method first or provide user key to PastebinClient.");
        }
        return post("api_raw.php", ShowPasteRequest.pasteKey(pasteKey).getParameters());
    }

    public String getPaste(String pasteKey) {
        return raw(pasteKey);
    }

    public void delete(String pasteKey) throws PastebinException {
        if (this.userKey == null) {
            throw new IllegalStateException("Cannot delete paste without user key. Please call login method first or provide user key to PastebinClient.");
        }
        String response = post("api_post.php", DeleteRequest.pasteKey(pasteKey).getParameters());
        if (!response.toLowerCase(Locale.ROOT).contains("paste removed")) {
            throw new PastebinException("Could not delete paste: " + response);
        }
    }

    private String raw(String pasteKey) throws PastebinException {
        String url = "https://pastebin.com/raw/" + pasteKey;
        Request request = new Request.Builder().url(url).build();
        try {
            Response response = this.client.newCall(request).execute();
            ResponseBody responseBody = response.body();
            if (responseBody == null) {
                throw new PastebinException("Could not get response body from " + url);
            }
            String string = responseBody.string();
            if (response != null) {
                if (0 != 0) {
                    response.close();
                } else {
                    response.close();
                }
            }
            return string;
        } catch (IOException e) {
            throw new PastebinException("Unable to make request to to " + url + ": " + e.getMessage(), e);
        }
    }

    private String post(String endpoint, Map<String, String> parameters) {
        StringBuilder postBody = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : parameters.entrySet()) {
            if (!first) {
                postBody.append("&");
            }
            try {
                postBody.append(entry.getKey()).append("=").append(URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8.toString()));
                first = false;
            } catch (UnsupportedEncodingException e) {
                throw new IllegalStateException("Could not find UTF-8 encoding (this should never happen)");
            }
        }
        postBody.append("&api_dev_key=").append(this.developerKey);
        if (this.userKey != null) {
            postBody.append("&api_user_key=").append(this.userKey);
        }
        String url = "https://pastebin.com/api/" + endpoint;
        Request request = new Request.Builder().url(url).post(RequestBody.create(postBody.toString(), MEDIA_TYPE)).build();
        try {
            Response response = this.client.newCall(request).execute();
            ResponseBody responseBody = response.body();
            if (responseBody == null) {
                throw new PastebinException("Could not get response body from " + url);
            }
            String body = responseBody.string();
            if (body.toLowerCase(Locale.ROOT).startsWith("bad api request")) {
                if (body.contains(", ")) {
                    throw new PastebinException(body.substring(body.indexOf(", ") + 2));
                }
                throw new PastebinException(body);
            }
            if (response != null) {
                if (0 != 0) {
                    response.close();
                } else {
                    response.close();
                }
            }
            return body;
        } catch (IOException e2) {
            throw new PastebinException("Unable to make request to to " + url + ": " + e2.getMessage(), e2);
        }
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/PastebinClient$Builder.class */
    public static class Builder {
        private String developerKey;
        private String userKey;

        public Builder developerKey(String developerKey) {
            this.developerKey = developerKey;
            return this;
        }

        public Builder userKey(String userKey) {
            this.userKey = userKey;
            return this;
        }

        public PastebinClient build() {
            if (this.developerKey == null) {
                throw new IllegalStateException("Developer key is required to create Pastebin Client.");
            }
            return new PastebinClient(this.developerKey, this.userKey);
        }
    }
}

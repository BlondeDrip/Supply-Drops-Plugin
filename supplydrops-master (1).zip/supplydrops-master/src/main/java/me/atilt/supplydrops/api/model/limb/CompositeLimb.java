package me.atilt.supplydrops.api.model.limb;

import java.util.List;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.Composite;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/limb/CompositeLimb.class */
public interface CompositeLimb extends Composite<Limb>, Limb {
    @Nonnull
    List<Limb> limbs();
}

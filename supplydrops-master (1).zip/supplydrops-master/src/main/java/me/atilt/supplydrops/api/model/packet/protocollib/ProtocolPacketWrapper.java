package me.atilt.supplydrops.api.model.packet.protocollib;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketContainer;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/ProtocolPacketWrapper.class */
public interface ProtocolPacketWrapper extends PacketWrapper<PacketContainer> {
    @Nonnull
    PacketType type();
}

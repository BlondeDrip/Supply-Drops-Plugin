package me.atilt.supplydrops.api.model.limb.type.entity;

import java.util.function.Function;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.ArmorStandSchema;
import me.atilt.supplydrops.api.model.Interaction;
import me.atilt.supplydrops.api.model.Schema;
import me.atilt.supplydrops.api.model.entity.Entity;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import me.atilt.supplydrops.api.model.util.Vector3d;
import org.bukkit.Location;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/limb/type/entity/ModelLimb.class */
public class ModelLimb implements Limb {
    private Schema<? extends Entity> schema;
    private final EntityRenderer<?> renderer;
    private final Interaction interaction;

    public ModelLimb(EntityRenderer<?> renderer, Schema<? extends Entity> schema, Interaction interaction) {
        this.renderer = renderer;
        this.schema = schema;
        this.interaction = interaction;
    }

    @Override // me.atilt.supplydrops.api.model.limb.Limb
    @Nullable
    public Location getLocation() {
        return (Location) renderThen(entityRenderer -> {
            return entityRenderer.entity().location();
        });
    }

    @Override // me.atilt.supplydrops.api.model.limb.Limb
    @Nullable
    public Vector3d offset() {
        return ((ArmorStandSchema) this.schema).getOffset();
    }

    @Override // me.atilt.supplydrops.api.model.limb.Limb
    @Nonnull
    public EntityRenderer<?> renderer() {
        return this.renderer;
    }

    @Override // me.atilt.supplydrops.api.model.Interactable
    @Nullable
    public Interaction interaction() {
        return this.interaction;
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [me.atilt.supplydrops.api.model.entity.Entity] */
    @Override // java.lang.AutoCloseable
    public void close() {
        if (renderer().rendered()) {
            this.renderer.entity().despawn();
        }
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void move(double x, double y, double z) {
        Entity entity = getSafely();
        entity.move(x, y, z);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void move(double x, double y, double z, float yaw, float pitch) {
        Entity entity = getSafely();
        entity.move(x, y, z, yaw, pitch);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void teleport(@Nonnull Location location) {
        Entity entity = getSafely();
        entity.teleport(location);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void rotate(@Nonnull Location location) {
        Entity entity = getSafely();
        entity.rotate(location);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void rotate(float degrees) {
        Entity entity = getSafely();
        entity.rotate(degrees);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void setVelocity(@Nonnull Vector vector) {
        Entity entity = getSafely();
        entity.setVelocity(vector);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public Vector getVelocity() {
        Entity entity = getSafely();
        return entity.getVelocity();
    }

    private <T> T renderThen(Function<EntityRenderer<?>, T> mapper) {
        if (this.renderer.entity() != null) {
            return mapper.apply(this.renderer);
        }
        return null;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [me.atilt.supplydrops.api.model.entity.Entity] */
    private Entity getSafely() {
        Entity entity = this.renderer.entity();
        if (entity == null) {
            throw new IllegalStateException("unrendered entity");
        }
        return entity;
    }
}

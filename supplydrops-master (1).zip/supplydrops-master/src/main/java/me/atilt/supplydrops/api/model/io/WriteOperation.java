package me.atilt.supplydrops.api.model.io;

import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/io/WriteOperation.class */
public class WriteOperation<T> {
    private BiConsumer<OutputStream, T> writeFunction;
    private CompressionType compressionType = CompressionType.NONE;
    private final ConcurrentFileAccessor<T> fileAccessor;

    public WriteOperation(ConcurrentFileAccessor<T> fileAccessor) {
        this.fileAccessor = fileAccessor;
    }

    public WriteOperation<T> compressionType(CompressionType compressionType) {
        this.compressionType = compressionType;
        return this;
    }

    public WriteOperation<T> operation(BiConsumer<OutputStream, T> writeFunction) {
        this.writeFunction = writeFunction;
        return this;
    }

    public CompletableFuture<Void> applyAsync(OutputStream outputStream, T data) {
        return CompletableFuture.runAsync(() -> {
            try {
                apply(outputStream, data);
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
        }, this.fileAccessor.getExecutorService());
    }

    public void apply(OutputStream outputStream, T data) throws IOException {
        this.fileAccessor.getLock().lock();
        try {
            OutputStream out = this.compressionType.getCompressionStream(outputStream);
            this.writeFunction.accept(out, data);
            if (out != null) {
                out.close();
            }
        } finally {
            this.fileAccessor.getLock().unlock();
        }
    }
}

package me.atilt.supplydrops.gui.edit;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.gui.SupplyDropGui;
import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.Icon;
import me.atilt.supplydrops.occurrence.periodicity.ReoccurringPeriodicity;
import me.atilt.supplydrops.util.Durations;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/OccurrenceGui.class */
public class OccurrenceGui extends Gui {
    private final TimeAdjustment timeAdjustment;
    private final SupplyDropsPlugin plugin;

    public OccurrenceGui(@Nonnull Player player, @Nonnull SupplyDropsPlugin plugin) {
        super(player, "supplydrops-occurrence-gui", Text.color("Editing &lfrequency"), 6);
        this.timeAdjustment = new TimeAdjustment(TimeAdjustment.OccurrenceUnit.HOURS, plugin.getTicker().getOccurrence().every().toMillis());
        this.plugin = plugin;
    }

    @Override // mc.obliviate.inventory.Gui
    public void onOpen(InventoryOpenEvent event) {
        fillRow(SupplyDropGui.PLACEHOLDER, 4);
        addItem(49, new Icon(Material.BARRIER).setName(Text.color("&cBack to supply drops")).onClick(clickEvent -> {
            new SupplyDropGui(this.player, this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        build();
    }

    @Override // mc.obliviate.inventory.Gui
    public void onClose(InventoryCloseEvent event) {
        if (this.plugin.getTicker().getOccurrence().every().toMillis() == this.timeAdjustment.current()) {
            return;
        }
        ReoccurringPeriodicity occurrence = new ReoccurringPeriodicity(Duration.ofMillis(this.timeAdjustment.current()));
        occurrence.start();
        this.plugin.getTicker().setOccurrence(occurrence);
    }

    private void build() {
        addItem(13, new Icon(Material.CLOCK).setName(Text.color("&aFrequency")).setLore(Text.color("&7Adjust how often the supply drop should spawn."), Text.color("&7This does not guarantee a spawn, but rather when a"), Text.color("&7spawn should be attempted."), " ", Text.color("&aSpawns Every: &e" + this.timeAdjustment.toString())));
        addItem(21, new Icon(Material.OAK_BUTTON).setName(Text.color("&d±1")).setLore(Text.color("&eLeft-Click &7to add &a+1 " + this.timeAdjustment.timeUnitFormatted() + "&7 to the time"), Text.color("&eRight-Click &7to add &c-1 " + this.timeAdjustment.timeUnitFormatted() + "&7 to the time")).onClick(clickEvent -> {
            if (clickEvent.isLeftClick()) {
                this.timeAdjustment.modify(1L);
                build();
            }
            if (clickEvent.isRightClick()) {
                this.timeAdjustment.modify(-1L);
                build();
            }
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent.isLeftClick() ? 1.87f : 0.8f);
        }));
        addItem(22, new Icon(Material.STONE_BUTTON).setName(Text.color("&d±5")).setLore(Text.color("&eLeft-Click &7to add &a+5 " + this.timeAdjustment.timeUnitFormatted() + "&7 to the time"), Text.color("&eRight-Click &7to add &c-5 " + this.timeAdjustment.timeUnitFormatted() + "&7 to the time")).onClick(clickEvent2 -> {
            if (clickEvent2.isLeftClick()) {
                this.timeAdjustment.modify(5L);
                build();
            }
            if (clickEvent2.isRightClick()) {
                this.timeAdjustment.modify(-5L);
                build();
            }
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent2.isLeftClick() ? 1.87f : 0.8f);
        }));
        addItem(23, new Icon(Material.POLISHED_BLACKSTONE_BUTTON).setName(Text.color("&d±15")).setLore(Text.color("&eLeft-Click &7to add &a+15 " + this.timeAdjustment.timeUnitFormatted() + "&7 to the time"), Text.color("&eRight-Click &7to add &c-15 " + this.timeAdjustment.timeUnitFormatted() + "&7 to the time")).onClick(clickEvent3 -> {
            if (clickEvent3.isLeftClick()) {
                this.timeAdjustment.modify(15L);
                build();
            }
            if (clickEvent3.isRightClick()) {
                this.timeAdjustment.modify(-15L);
                build();
            }
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent3.isLeftClick() ? 1.87f : 0.8f);
        }));
        addItem(31, new Icon(Material.RESPAWN_ANCHOR).setName(Text.color("&aTime unit")).setLore(Text.color("&7Adjust the time unit for the time added."), " ", Text.color("&aTime unit: &e" + this.timeAdjustment.timeUnitFormatted()), " ", Text.color("&eLeft-Click &ato change units")).onClick(clickEvent4 -> {
            this.timeAdjustment.cycle();
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/OccurrenceGui$TimeAdjustment.class */
    public static final class TimeAdjustment {
        private OccurrenceUnit occurrenceUnit;
        private long current;

        public TimeAdjustment(@Nullable OccurrenceUnit occurrenceUnit, long current) {
            this.occurrenceUnit = OccurrenceUnit.HOURS;
            this.occurrenceUnit = occurrenceUnit;
            this.current = current;
        }

        @Nonnull
        public OccurrenceUnit timeUnit() {
            return this.occurrenceUnit;
        }

        @Nonnegative
        public long current() {
            return this.current;
        }

        public void timeUnit(@Nonnull OccurrenceUnit occurrenceUnit) {
            this.occurrenceUnit = occurrenceUnit;
        }

        public void modify(long amount) {
            long amountMillis = TimeUnit.MILLISECONDS.convert(amount, this.occurrenceUnit.timeUnit());
            this.current = Math.max(180000L, Math.min(31556926000L, this.current + amountMillis));
        }

        public void cycle() {
            this.occurrenceUnit = this.occurrenceUnit.cycle();
        }

        public String timeUnitFormatted() {
            return this.occurrenceUnit.name().toLowerCase();
        }

        public String toString() {
            return Durations.format(this.current);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/OccurrenceGui$TimeAdjustment$OccurrenceUnit.class */
        public enum OccurrenceUnit {
            SECONDS(TimeUnit.SECONDS),
            MINUTES(TimeUnit.MINUTES),
            HOURS(TimeUnit.HOURS),
            DAYS(TimeUnit.DAYS);
            
            private final TimeUnit timeUnit;
            private static final OccurrenceUnit[] VALUES = values();

            OccurrenceUnit(@Nonnull TimeUnit timeUnit) {
                this.timeUnit = timeUnit;
            }

            @Nonnull
            public OccurrenceUnit cycle() {
                return VALUES[(ordinal() + 1) % VALUES.length];
            }

            @Nonnull
            public TimeUnit timeUnit() {
                return this.timeUnit;
            }
        }
    }
}

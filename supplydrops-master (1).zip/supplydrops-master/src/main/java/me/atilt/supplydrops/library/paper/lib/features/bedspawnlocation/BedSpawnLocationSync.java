package me.atilt.supplydrops.library.paper.lib.features.bedspawnlocation;

import java.util.concurrent.CompletableFuture;
import org.bukkit.Location;
import org.bukkit.entity.Player;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/bedspawnlocation/BedSpawnLocationSync.class */
public class BedSpawnLocationSync implements BedSpawnLocation {
    @Override // me.atilt.supplydrops.library.paper.lib.features.bedspawnlocation.BedSpawnLocation
    public CompletableFuture<Location> getBedSpawnLocationAsync(Player player, boolean isUrgent) {
        return CompletableFuture.completedFuture(player.getBedSpawnLocation());
    }
}

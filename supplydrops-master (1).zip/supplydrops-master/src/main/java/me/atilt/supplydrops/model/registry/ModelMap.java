package me.atilt.supplydrops.model.registry;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import me.atilt.supplydrops.supplydrop.ModelData;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/registry/ModelMap.class */
public final class ModelMap extends Int2ObjectOpenHashMap<ModelData> {
    private final Int2ObjectMap<EntityTriplet> models = new Int2ObjectOpenHashMap();

    @Override // it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap, it.unimi.dsi.fastutil.ints.Int2ObjectFunction
    public ModelData remove(int k) {
        ModelData removed = (ModelData) super.remove(k);
        if (removed != null) {
            this.models.int2ObjectEntrySet().removeIf(entry -> {
                return ((EntityTriplet) entry.getValue()).getModel().equals(removed.getHandle().get());
            });
        }
        return removed;
    }

    public void putId(int entityId, @Nonnull EntityTriplet entityTriplet) {
        this.models.put(entityId, entityTriplet);
    }

    @Nullable
    public EntityTriplet getId(int entityId) {
        return this.models.get(entityId);
    }

    @Nonnull
    public EntityTriplet getIdSafely(int entityId, @Nonnull EntityTriplet entityTriplet) {
        return this.models.computeIfAbsent(entityId, id -> {
            return entityTriplet;
        });
    }
}

package me.atilt.supplydrops.util;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/ItemStackBuilder.class */
public final class ItemStackBuilder {
    private final ItemStack handle;
    private static final ItemFlag[] VALUES = ItemFlag.values();

    private ItemStackBuilder(@Nonnull ItemStack itemStack) {
        this.handle = itemStack;
    }

    @Nonnull
    public static ItemStackBuilder of(@Nonnull ItemStack itemStack) {
        Objects.requireNonNull(itemStack, "itemStack");
        return new ItemStackBuilder(itemStack);
    }

    @Nonnull
    public static ItemStackBuilder of(@Nonnull Material material) {
        return of(new ItemStack(material));
    }

    @Nonnull
    public static ItemStackBuilder of(@Nonnull ItemStack itemStack, boolean copy) {
        Objects.requireNonNull(itemStack, "itemStack");
        return of(copy ? itemStack.clone() : itemStack);
    }

    @Nonnull
    public static ItemFlag[] flags() {
        return VALUES;
    }

    @Nonnull
    public ItemStackBuilder meta(@Nonnull Function<ItemMeta, ItemMeta> meta) {
        ItemMeta itemMeta = this.handle.getItemMeta();
        this.handle.setItemMeta(meta.apply(itemMeta));
        return this;
    }

    @Nonnull
    public ItemStackBuilder amount(@Nonnegative int amount) {
        this.handle.setAmount(amount);
        return this;
    }

    @Nonnull
    public ItemStackBuilder name(@Nonnull String displayName) {
        return meta(itemMeta -> {
            itemMeta.setDisplayName(displayName);
            return itemMeta;
        });
    }

    @Nonnull
    public ItemStackBuilder lore(@Nonnull List<String> lore) {
        return meta(itemMeta -> {
            itemMeta.setLore(lore);
            return itemMeta;
        });
    }

    @Nonnull
    public ItemStackBuilder lore(@Nonnull String... lore) {
        return lore(Arrays.asList(lore));
    }

    @Nonnull
    public ItemStackBuilder flags(@Nonnull ItemFlag... flags) {
        return meta(itemMeta -> {
            itemMeta.addItemFlags(flags);
            return itemMeta;
        });
    }

    @Nonnull
    public ItemStackBuilder allFlags() {
        return flags(VALUES);
    }

    @Nonnull
    public ItemStackBuilder enchant(@Nonnull Enchantment enchantment, int level, boolean bypass) {
        this.handle.addUnsafeEnchantment(enchantment, level);
        return this;
    }

    @Nonnull
    public ItemStackBuilder persistentDataContainer(@Nonnull Consumer<PersistentDataContainer> persistentDataContainer) {
        return meta(itemMeta -> {
            persistentDataContainer.accept(itemMeta.getPersistentDataContainer());
            return itemMeta;
        });
    }

    @Nonnull
    public ItemStack build() {
        return this.handle;
    }
}

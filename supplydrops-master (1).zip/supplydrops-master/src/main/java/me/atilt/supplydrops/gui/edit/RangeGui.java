package me.atilt.supplydrops.gui.edit;

import java.text.NumberFormat;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.distributor.DefaultDistributionParameters;
import me.atilt.supplydrops.gui.SupplyDropGui;
import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.Icon;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.Axis;
import me.atilt.supplydrops.util.Cuboid;
import me.atilt.supplydrops.util.ItemStackBuilder;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.util.Vector;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/RangeGui.class */
public class RangeGui extends Gui {
    private final SupplyDrop supplyDrop;
    private final Integer model;
    private final SelectedPosition selectedPosition;
    private final SupplyDropsPlugin plugin;

    public RangeGui(@Nonnull Player player, @Nonnull SupplyDrop supplyDrop, @Nonnull Integer model, @Nonnull SupplyDropsPlugin plugin) {
        super(player, "supplydrops-range-gui", Text.color("Editing &lrange&r for " + supplyDrop.meta().name()), 5);
        this.supplyDrop = supplyDrop;
        this.model = model;
        this.selectedPosition = new SelectedPosition(supplyDrop);
        this.plugin = plugin;
    }

    @Override // mc.obliviate.inventory.Gui
    public void onOpen(InventoryOpenEvent event) {
        fillRow(SupplyDropGui.PLACEHOLDER, 3);
        addItem(40, new Icon(Material.BARRIER).setName(Text.color("&cBack to editor")).onClick(clickEvent -> {
            new SupplyDropEditorGui(this.player, this.supplyDrop, this.model, this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        build();
    }

    private void build() {
        addItem(4, new Icon(Material.WOODEN_AXE).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&aSwitch Positions")).setLore(Text.color("&7Click to switch positions."), " ", Text.color("&aSelected: &b" + this.selectedPosition)).onClick(clickEvent -> {
            this.selectedPosition.flip();
            build();
            this.player.playSound(this.player.getLocation(), Sound.ENTITY_BEE_STING, 0.1f, 0.1f);
        }));
        addItem(13, new Icon(Material.FILLED_MAP).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&aRange Information")).setLore(Text.color("&7This determines the range in which the supply drop will spawn."), Text.color("&7The location selected will be a random"), Text.color("&7location that is between &bPosition 1 &7and &bPosition 2&7."), " ", Text.color("&aSelected: &b" + this.selectedPosition), " ", Text.color("&aPosition 1: &e" + NumberFormat.getInstance().format(this.selectedPosition.firstPosition().getX()) + ", " + NumberFormat.getInstance().format(this.selectedPosition.firstPosition().getY()) + ", " + NumberFormat.getInstance().format(this.selectedPosition.firstPosition().getZ())), Text.color("&aPosition 2: &e" + NumberFormat.getInstance().format(this.selectedPosition.secondPosition().getX()) + ", " + NumberFormat.getInstance().format(this.selectedPosition.secondPosition().getY()) + ", " + NumberFormat.getInstance().format(this.selectedPosition.secondPosition().getZ()))));
        addItem(22, new Icon(Material.COMPASS).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&aSwitch Axis")).setLore(Text.color("&7Click to switch the coordinate axis."), " ", Text.color("&aSelected: &b" + this.selectedPosition.axis())).onClick(clickEvent2 -> {
            this.selectedPosition.axis(this.selectedPosition.axis().cycle(Axis.Dimension.TWO));
            build();
        }));
        addItem(9, new Icon(Material.POLISHED_BLACKSTONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&c-1000")).setLore(Text.color("&7Click to remove &c-1000&7 from the &b" + this.selectedPosition.axis())).onClick(clickEvent3 -> {
            this.selectedPosition.axis().modify(this.selectedPosition.selectedPosition(), -1000.0d);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 0.8f);
        }));
        addItem(10, new Icon(Material.STONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&c-100")).setLore(Text.color("&7Click to remove &c-100&7 from the &b" + this.selectedPosition.axis())).onClick(clickEvent4 -> {
            this.selectedPosition.axis().modify(this.selectedPosition.selectedPosition(), -100.0d);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 0.8f);
        }));
        addItem(11, new Icon(Material.SPRUCE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&c-10")).setLore(Text.color("&7Click to remove &c-10&7 from the &b" + this.selectedPosition.axis())).onClick(clickEvent5 -> {
            this.selectedPosition.axis().modify(this.selectedPosition.selectedPosition(), -10.0d);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 0.8f);
        }));
        addItem(12, new Icon(Material.OAK_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&c-1")).setLore(Text.color("&7Click to remove &c-1&7 from the &b" + this.selectedPosition.axis())).onClick(clickEvent6 -> {
            this.selectedPosition.axis().modify(this.selectedPosition.selectedPosition(), -1.0d);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 0.8f);
        }));
        addItem(17, new Icon(Material.POLISHED_BLACKSTONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&a+1000")).setLore(Text.color("&7Click to add &a+1000&7 to the &b" + this.selectedPosition.axis())).onClick(clickEvent7 -> {
            this.selectedPosition.axis().modify(this.selectedPosition.selectedPosition(), 1000.0d);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
        }));
        addItem(16, new Icon(Material.STONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&a+100")).setLore(Text.color("&7Click to add &a+100&7 to the &b" + this.selectedPosition.axis())).onClick(clickEvent8 -> {
            this.selectedPosition.axis().modify(this.selectedPosition.selectedPosition(), 100.0d);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
        }));
        addItem(15, new Icon(Material.SPRUCE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&a+10")).setLore(Text.color("&7Click to add &a+10&7 to the &b" + this.selectedPosition.axis())).onClick(clickEvent9 -> {
            this.selectedPosition.axis().modify(this.selectedPosition.selectedPosition(), 10.0d);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
        }));
        addItem(14, new Icon(Material.OAK_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&a+1")).setLore(Text.color("&7Click to add &a+1&7 to the &b" + this.selectedPosition.axis())).onClick(clickEvent10 -> {
            this.selectedPosition.axis().modify(this.selectedPosition.selectedPosition(), 1.0d);
            build();
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
        }));
    }

    @Override // mc.obliviate.inventory.Gui
    public void onClose(InventoryCloseEvent event) {
        World world;
        Cuboid cuboid = this.supplyDrop.distributor().parameters().cuboid();
        if (cuboid == null) {
            world = (World) Bukkit.getWorlds().get(0);
        } else {
            world = Bukkit.getWorld(cuboid.getWorld());
        }
        this.supplyDrop.distributor().parameters(DefaultDistributionParameters.newBuilder().adapt(this.supplyDrop.distributor().parameters()).range(this.selectedPosition.firstPosition().toLocation(world), this.selectedPosition.secondPosition().toLocation(world)).build());
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/RangeGui$SelectedPosition.class */
    public static class SelectedPosition {
        private final Vector firstPosition;
        private final Vector secondPosition;
        private Axis axis;
        private boolean firstSelected = true;

        public SelectedPosition(@Nonnull SupplyDrop supplyDrop) {
            Cuboid cuboid = supplyDrop.distributor().parameters().cuboid();
            if (cuboid == null) {
                Location loc = new Location((World) Bukkit.getWorlds().get(0), 0.0d, 0.0d, 0.0d);
                cuboid = new Cuboid(loc, loc.clone());
            }
            this.firstPosition = cuboid.getMin().toVector();
            this.secondPosition = cuboid.getMax().toVector();
            this.axis = Axis.X;
        }

        public void flip() {
            this.firstSelected = !this.firstSelected;
        }

        @Nonnull
        public Vector firstPosition() {
            return this.firstPosition;
        }

        @Nonnull
        public Vector secondPosition() {
            return this.secondPosition;
        }

        @Nonnull
        public Vector selectedPosition() {
            return this.firstSelected ? this.firstPosition : this.secondPosition;
        }

        @Nonnull
        public Axis axis() {
            return this.axis;
        }

        public void axis(@Nonnull Axis axis) {
            this.axis = axis;
        }

        public String toString() {
            return this.firstSelected ? "Position 1" : "Position 2";
        }
    }
}

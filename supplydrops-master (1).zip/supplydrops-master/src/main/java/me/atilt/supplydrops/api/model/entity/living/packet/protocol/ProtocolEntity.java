package me.atilt.supplydrops.api.model.entity.living.packet.protocol;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.WrappedDataWatcher;
import java.util.UUID;
import java.util.function.Function;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.entity.living.packet.PacketEntity;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolAudience;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.EntityRelativeMoveLookPacket;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.EntityTeleportPacket;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.PacketAudience;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.SpawnEntityPacket;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/entity/living/packet/protocol/ProtocolEntity.class */
public class ProtocolEntity extends PacketEntity<PacketContainer> {
    protected final WrappedDataWatcher dataWatcher;

    public ProtocolEntity(@Nonnull EntityType type, int id, @Nonnull UUID uuid, @Nonnull PacketAudience<Player, PacketContainer> audience) {
        super(type, id, uuid, audience);
        this.dataWatcher = new WrappedDataWatcher();
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void move(double x, double y, double z) {
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.REL_ENTITY_MOVE_LOOK, packetWrapper -> {
            return (packetWrapper == null ? EntityRelativeMoveLookPacket.newBuilder() : EntityRelativeMoveLookPacket.newBuilder(packetWrapper)).entityId(id()).velocity(x, y, z).ground(false).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), Bukkit.getOnlinePlayers());
        this.location.add(x, y, z);
        this.velocity.setX(x).setY(y).setZ(z);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void move(double x, double y, double z, float yaw, float pitch) {
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.REL_ENTITY_MOVE_LOOK, packetWrapper -> {
            return (packetWrapper == null ? EntityRelativeMoveLookPacket.newBuilder() : EntityRelativeMoveLookPacket.newBuilder(packetWrapper)).entityId(id()).velocity(x, y, z).rotation(yaw, pitch).ground(false).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), Bukkit.getOnlinePlayers());
        this.location.add(x, y, z);
        this.velocity.setX(x).setY(y).setZ(z);
        this.location.setYaw(yaw);
        this.location.setPitch(pitch);
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void teleport(@Nonnull Location location) {
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.ENTITY_TELEPORT, packetWrapper -> {
            return (packetWrapper == null ? EntityTeleportPacket.newBuilder() : EntityTeleportPacket.newBuilder(packetWrapper)).entityId(id()).location(location).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), Bukkit.getOnlinePlayers());
        this.location = location.clone();
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void rotate(@Nonnull Location location) {
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.REL_ENTITY_MOVE_LOOK, packetWrapper -> {
            return (packetWrapper == null ? EntityRelativeMoveLookPacket.newBuilder() : EntityRelativeMoveLookPacket.newBuilder(packetWrapper)).entityId(id()).velocity(0.0d, 0.0d, 0.0d).rotation(location.getYaw(), location.getPitch()).ground(false).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), Bukkit.getOnlinePlayers());
        this.location.setYaw(location.getYaw());
        this.location.setPitch(location.getPitch());
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void rotate(float degrees) {
        this.location.setYaw(clampYaw(this.location.getYaw() + degrees));
        teleport(this.location);
    }

    public static float clampYaw(float yaw) {
        while (yaw < -180.0f) {
            yaw += 360.0f;
        }
        while (yaw >= 180.0f) {
            yaw -= 360.0f;
        }
        return yaw;
    }

    @Override // me.atilt.supplydrops.api.model.Navigable
    public void setVelocity(@Nonnull Vector vector) {
        move(vector.getX(), vector.getY(), vector.getZ());
    }

    @Override // me.atilt.supplydrops.api.model.entity.Entity
    public void spawn(@Nonnull Location location) {
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.SPAWN_ENTITY, packetWrapper -> {
            return (packetWrapper == null ? SpawnEntityPacket.newBuilder() : SpawnEntityPacket.newBuilder(packetWrapper)).entityId(id()).uuid(uuid()).entityType(bukkitType()).location(location).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), Bukkit.getOnlinePlayers());
        this.location = location;
        this.valid = true;
    }

    @Override // me.atilt.supplydrops.api.model.entity.Entity
    public void despawn() {
        this.valid = false;
        audience().clear();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public PacketWrapper<PacketContainer> modifyPacket(PacketType packetType, Function<PacketWrapper<PacketContainer>, PacketWrapper<PacketContainer>> transformer) {
        return ((ProtocolAudience) audience()).modifyPacket(packetType, transformer);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public byte modifyBits(byte value, int bitIndex, boolean set) {
        return set ? (byte) (value | (1 << bitIndex)) : (byte) (value & ((1 << bitIndex) ^ (-1)));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public byte supplyBytes(WrappedDataWatcher dataWatcher, int index) {
        Object data = dataWatcher.getObject(new WrappedDataWatcher.WrappedDataWatcherObject(index, WrappedDataWatcher.Registry.get(Byte.class)));
        if (data != null) {
            return ((Byte) data).byteValue();
        }
        return (byte) 0;
    }
}

package me.atilt.supplydrops.library.paper.lib.features.asyncchunks;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import me.atilt.supplydrops.library.paper.lib.PaperLib;
import org.bukkit.Chunk;
import org.bukkit.World;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/asyncchunks/AsyncChunksPaper_9_12.class */
public class AsyncChunksPaper_9_12 implements AsyncChunks {
    @Override // me.atilt.supplydrops.library.paper.lib.features.asyncchunks.AsyncChunks
    public CompletableFuture<Chunk> getChunkAtAsync(World world, int x, int z, boolean gen, boolean isUrgent) {
        CompletableFuture<Chunk> future = new CompletableFuture<>();
        if (!gen && PaperLib.getMinecraftVersion() >= 12 && !world.isChunkGenerated(x, z)) {
            future.complete(null);
        } else {
            Objects.requireNonNull(future);
            World.ChunkLoadCallback chunkLoadCallback = future::complete;
            world.getChunkAtAsync(x, z, chunkLoadCallback);
        }
        return future;
    }
}

package me.atilt.supplydrops.api.model;

import me.atilt.supplydrops.api.model.util.FastMath;
import org.bukkit.Location;
import org.bukkit.util.Vector;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/Vectors.class */
public final class Vectors {
    private Vectors() {
        throw new UnsupportedOperationException("This class cannot be instantiated");
    }

    public static Location rotateTo(Location from, Location to, double offsetX, double offsetY, double offsetZ) {
        float angle = -to.getYaw();
        double angleCos = FastMath.cosDeg(angle);
        double angleSin = FastMath.sinDeg(angle);
        double x1 = (angleCos * offsetX) + (angleSin * offsetZ);
        double z1 = ((-angleSin) * offsetX) + (angleCos * offsetZ);
        from.setX(x1 + to.getX());
        from.setY(to.getY() + offsetY);
        from.setZ(z1 + to.getZ());
        from.setYaw(to.getYaw());
        from.setPitch(to.getPitch());
        return from;
    }

    public static Vector rotateTo(Vector from, Vector to, double angle, double offsetX, double offsetY, double offsetZ) {
        double angleCos = FastMath.cosDeg((float) angle);
        double angleSin = FastMath.sinDeg((float) angle);
        double x1 = (angleCos * offsetX) + (angleSin * offsetZ);
        double z1 = ((-angleSin) * offsetX) + (angleCos * offsetZ);
        from.setX(x1 + to.getX());
        from.setY(offsetY + to.getY());
        from.setZ(z1 + to.getZ());
        return from;
    }

    public static Vector direction(Location from, Location to) {
        Vector direction = to.subtract(from).toVector();
        to.add(from);
        return direction;
    }
}

package me.atilt.supplydrops.api.model.schema;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/schema/SerializedState.class */
public interface SerializedState {
}

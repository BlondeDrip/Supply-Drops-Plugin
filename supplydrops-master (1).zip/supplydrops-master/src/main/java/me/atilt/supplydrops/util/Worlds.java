package me.atilt.supplydrops.util;

import java.util.Set;
import org.bukkit.Location;
import org.bukkit.World;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Worlds.class */
public final class Worlds {
    private static final int Y_OFFSET = 0;
    private static final int[] MULTIPLY_DE_BRUIJN_BIT_POSITION = {0, 1, 28, 2, 29, 14, 24, 3, 30, 22, 20, 15, 25, 17, 4, 8, 31, 27, 13, 23, 21, 19, 16, 7, 26, 12, 18, 6, 11, 5, 10, 9};
    private static final int PACKED_X_LENGTH = 1 + log2(smallestEncompassingPowerOfTwo(30000000));
    private static final int PACKED_Z_LENGTH = PACKED_X_LENGTH;
    public static final int PACKED_Y_LENGTH = (64 - PACKED_X_LENGTH) - PACKED_Z_LENGTH;
    private static final long PACKED_X_MASK = (1 << PACKED_X_LENGTH) - 1;
    private static final long PACKED_Y_MASK = (1 << PACKED_Y_LENGTH) - 1;
    private static final long PACKED_Z_MASK = (1 << PACKED_Z_LENGTH) - 1;
    private static final int Z_OFFSET = PACKED_Y_LENGTH;
    private static final int X_OFFSET = PACKED_Y_LENGTH + PACKED_Z_LENGTH;

    private Worlds() {
        throw new UnsupportedOperationException("This class cannot be instantiated");
    }

    public static <T> T getLastElement(Set<T> set) {
        T last = null;
        for (T element : set) {
            last = element;
        }
        return last;
    }

    public static int smallestEncompassingPowerOfTwo(int var0) {
        int var1 = var0 - 1;
        int var12 = var1 | (var1 >> 1);
        int var13 = var12 | (var12 >> 2);
        int var14 = var13 | (var13 >> 4);
        int var15 = var14 | (var14 >> 8);
        return (var15 | (var15 >> 16)) + 1;
    }

    public static boolean isPowerOfTwo(int var0) {
        return var0 != 0 && (var0 & (var0 - 1)) == 0;
    }

    public static int ceillog2(int var0) {
        return MULTIPLY_DE_BRUIJN_BIT_POSITION[((int) (((isPowerOfTwo(var0) ? var0 : smallestEncompassingPowerOfTwo(var0)) * 125613361) >> 27)) & 31];
    }

    public static int log2(int var0) {
        return ceillog2(var0) - (isPowerOfTwo(var0) ? 0 : 1);
    }

    public static long locationKey2(int x, int y, int z) {
        long var3 = 0 | ((x & PACKED_X_MASK) << X_OFFSET);
        return var3 | (y & PACKED_Y_MASK) | ((z & PACKED_Z_MASK) << Z_OFFSET);
    }

    public static Location keyLocation2(World world, long combined) {
        int x = (int) ((combined << ((64 - X_OFFSET) - PACKED_X_LENGTH)) >> (64 - PACKED_X_LENGTH));
        int y = (int) ((combined << (64 - PACKED_Y_LENGTH)) >> (64 - PACKED_Y_LENGTH));
        int z = (int) ((combined << ((64 - Z_OFFSET) - PACKED_Z_LENGTH)) >> (64 - PACKED_Z_LENGTH));
        return new Location(world, x, y, z);
    }

    public static long locationKey(int x, int y, int z) {
        return ((x & 67108863) << 38) | ((y & 4095) << 26) | (z & 67108863);
    }

    public static long locationKey(Location location) {
        return locationKey(location.getBlockX(), location.getBlockY(), location.getBlockZ());
    }

    public static Location keyLocation(World world, long combined) {
        int x = (int) (combined >> 38);
        int y = (((int) ((combined >> 26) & 4095)) << 20) >> 20;
        int z = (((int) (combined & 67108863)) << 6) >> 6;
        return new Location(world, x, (y << 20) >> 20, (z << 6) >> 6);
    }

    public static int keyX(long combined) {
        return (int) (combined >> 38);
    }

    public static int keyY(long combined) {
        int y = (((int) ((combined >> 26) & 4095)) << 20) >> 20;
        return (y << 20) >> 20;
    }

    public static int keyZ(long combined) {
        int z = (((int) (combined & 67108863)) << 6) >> 6;
        return (z << 6) >> 6;
    }
}

package me.atilt.supplydrops.model.io;

import java.nio.file.Path;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.io.ConcurrentFileAccessor;
import me.atilt.supplydrops.model.io.read.DefaultModelReader;
import me.atilt.supplydrops.model.io.read.ModelReader;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/io/DefaultModelIO.class */
public class DefaultModelIO implements ModelIO {
    private final Path target;
    private final ConcurrentFileAccessor<ModelReader.ParsedStatesData> fileAccessor = new ConcurrentFileAccessor<>(2);

    public DefaultModelIO(@Nonnull Path target) {
        this.target = target;
    }

    @Override // me.atilt.supplydrops.model.io.ModelIO
    @Nonnull
    public Path target() {
        return this.target;
    }

    @Override // me.atilt.supplydrops.model.io.ModelIO
    @Nonnull
    public ModelReader newReader() {
        return new DefaultModelReader(this.fileAccessor);
    }

    @Override // java.lang.AutoCloseable
    public void close() throws Exception {
    }
}

package me.atilt.supplydrops.api.model.packet.protocollib.entity;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.utility.MinecraftReflection;
import com.comphenix.protocol.wrappers.BukkitConverters;
import com.comphenix.protocol.wrappers.WrappedRegistry;
import com.google.common.base.Preconditions;
import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.ProtocolVersion;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketBuilder;
import me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/SpawnEntityPacket.class */
public final class SpawnEntityPacket implements ProtocolPacketWrapper {
    private final PacketContainer handle;

    public SpawnEntityPacket(@Nonnull PacketContainer handle) {
        Preconditions.checkArgument(handle.getType() == PacketType.Play.Server.SPAWN_ENTITY, "packet mismatch");
        this.handle = handle;
    }

    public SpawnEntityPacket() {
        this(new PacketContainer(PacketType.Play.Server.SPAWN_ENTITY));
    }

    @Nonnull
    public static Builder newBuilder(@Nonnull PacketWrapper<PacketContainer> wrapper) {
        return new Builder(wrapper.handle());
    }

    @Nonnull
    public static Builder newBuilder() {
        return new Builder();
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    public PacketContainer handle() {
        return this.handle;
    }

    @Override // me.atilt.supplydrops.api.model.packet.PacketWrapper
    @Nonnull
    /* renamed from: deepClone */
    public PacketWrapper<PacketContainer> deepClone() {
        return new SpawnEntityPacket(this.handle.deepClone());
    }

    @Override // me.atilt.supplydrops.api.model.packet.protocollib.ProtocolPacketWrapper
    @Nonnull
    public PacketType type() {
        return this.handle.getType();
    }

    @Override // java.lang.AutoCloseable
    public void close() {
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/entity/SpawnEntityPacket$Builder.class */
    public static class Builder extends ProtocolPacketBuilder {
        public static final Map<EntityType, Integer> ENTITY_TYPE = new EnumMap(EntityType.class);

        private Builder(@Nonnull PacketContainer handle) {
            super(handle);
        }

        private Builder() {
            this(new PacketContainer(PacketType.Play.Server.SPAWN_ENTITY));
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        public Builder copy() {
            return new Builder(this.handle.deepClone());
        }

        @Override // me.atilt.supplydrops.api.model.packet.PacketBuilder
        @Nonnull
        /* renamed from: buildPacket */
        public PacketWrapper<PacketContainer> buildPacket() {
            return new SpawnEntityPacket(this.handle);
        }

        @Nonnull
        public Builder entityId(int id) {
            this.handle.getIntegers().write(0, Integer.valueOf(id));
            return this;
        }

        @Nonnull
        public Builder uuid(@Nonnull UUID uuid) {
            this.handle.getUUIDs().write(0, uuid);
            return this;
        }

        static {
            EntityType[] values;
            WrappedRegistry registry = WrappedRegistry.getRegistry(MinecraftReflection.getEntityTypes());
            for (EntityType value : EntityType.values()) {
                if (value.isSpawnable()) {
                    Object nmsEntityType = BukkitConverters.getEntityTypeConverter().getGeneric(value);
                    ENTITY_TYPE.put(value, Integer.valueOf(registry.getId(nmsEntityType)));
                }
            }
        }

        @Nonnull
        public Builder entityType(EntityType type) {
            if (ProtocolVersion.runningVersion().isAtLeast(ProtocolVersion.v1_18_R1)) {
                this.handle.getEntityTypeModifier().write(0, type);
            } else {
                this.handle.getIntegers().write(1, ENTITY_TYPE.get(type));
            }
            return this;
        }

        @Nonnull
        public Builder location(double x, double y, double z) {
            this.handle.getDoubles().write(0, Double.valueOf(x)).write(1, Double.valueOf(y)).write(2, Double.valueOf(z));
            return this;
        }

        @Nonnull
        public Builder location(double x, double y, double z, float yaw, float pitch) {
            this.handle.getDoubles().write(0, Double.valueOf(x)).write(1, Double.valueOf(y)).write(2, Double.valueOf(z));
            this.handle.getBytes().write(0, Byte.valueOf((byte) ((yaw * 256.0f) / 360.0f))).write(1, Byte.valueOf((byte) ((pitch * 256.0f) / 360.0f)));
            return this;
        }

        @Nonnull
        public Builder location(@Nonnull Location location) {
            return location(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
        }

        @Nonnull
        public Builder velocity(double x, double y, double z) {
            this.handle.getIntegers().write(2, Integer.valueOf((int) (x * 8000.0d))).write(3, Integer.valueOf((int) (y * 8000.0d))).write(4, Integer.valueOf((int) (z * 8000.0d)));
            return this;
        }
    }
}

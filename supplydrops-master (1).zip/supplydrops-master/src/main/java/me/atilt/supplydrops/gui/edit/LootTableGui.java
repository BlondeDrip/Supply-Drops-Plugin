package me.atilt.supplydrops.gui.edit;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.gui.SupplyDropGui;
import it.unimi.dsi.fastutil.ints.IntSets;
import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.Icon;
import mc.obliviate.inventory.advancedslot.AdvancedSlot;
import mc.obliviate.inventory.advancedslot.AdvancedSlotManager;
import mc.obliviate.inventory.pagination.PaginationManager;
import me.atilt.supplydrops.loot.ItemLootEntry;
import me.atilt.supplydrops.loot.LootEntry;
import me.atilt.supplydrops.loot.probability.DynamicProbability;
import me.atilt.supplydrops.loot.probability.Probability;
import me.atilt.supplydrops.loot.probability.StaticProbability;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.BigDecimals;
import me.atilt.supplydrops.util.ItemStackBuilder;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/LootTableGui.class */
public class LootTableGui extends Gui {
    private final SupplyDrop supplyDrop;
    private final Integer model;
    private final SupplyDropsPlugin plugin;
    private final PaginationManager pagination;

    public LootTableGui(@Nonnull HumanEntity player, @Nonnull SupplyDrop supplyDrop, @Nonnull Integer model, @Nonnull SupplyDropsPlugin plugin) {
        super((Player) player, "supplydrops-loot-table-gui", Text.color("Editing &lloot table&r for " + supplyDrop.meta().name()), 6);
        this.pagination = new PaginationManager(this);
        this.supplyDrop = supplyDrop;
        this.model = model;
        this.plugin = plugin;
        this.pagination.registerPageSlotsBetween(0, 35);
    }

    @Override // mc.obliviate.inventory.Gui
    public void onOpen(InventoryOpenEvent event) {
        fillRow(new Icon(Material.GRAY_STAINED_GLASS_PANE).setName(" "), 4);
        addItem(49, new Icon(Material.BARRIER).setName(Text.color("&cBack to editor")).onClick(clickEvent -> {
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
            new SupplyDropEditorGui(this.player, this.supplyDrop, this.model, this.plugin).open();
        }));
        build();
    }

    private void build() {
        this.pagination.getItems().clear();
        for (LootEntry<?> lootEntry : this.supplyDrop.lootTable()) {
            ItemStack itemStack = itemize(lootEntry);
            this.pagination.addItem(new Icon(itemStack).onClick(clickEvent -> {
                if (clickEvent.isLeftClick()) {
                    this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
                    new LootEntryGui((Player) clickEvent.getWhoClicked(), this.supplyDrop, this.model, lootEntry, this.plugin).open();
                } else if (clickEvent.isRightClick()) {
                    this.supplyDrop.lootTable().remove(lootEntry);
                    this.player.playSound(this.player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.07f, 1.09f);
                    build();
                }
            }));
        }
        updateNavigation();
        addItem(53, new Icon(Material.CRAFTING_TABLE).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&aCreate")).setLore(Text.color("&7Click to create a new item for"), Text.color("&7this supply drop.")).onClick(clickEvent2 -> {
            this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, 1.87f);
            new LootEntryGui((Player) clickEvent2.getWhoClicked(), this.supplyDrop, this.model, null, this.plugin).open();
        }));
    }

    private void updateNavigation() {
        this.pagination.update();
        if (this.pagination.getItems().size() > 36) {
            addItem(48, new Icon(Material.ARROW).setName(Text.color("&aPrevious Page")).setLore(Text.color("&7Current Page: &a" + (this.pagination.getCurrentPage() + 1))).onClick(clickEvent -> {
                this.pagination.goPreviousPage();
                updateNavigation();
                this.player.playSound(this.player.getLocation(), Sound.BLOCK_MOSS_CARPET_HIT, 0.6f, 0.0f);
            }));
            addItem(50, new Icon(Material.ARROW).setName(Text.color("&aNext Page")).setLore(Text.color("&7Current Page: &a" + (this.pagination.getCurrentPage() + 1))).onClick(clickEvent2 -> {
                this.pagination.goNextPage();
                updateNavigation();
                this.player.playSound(this.player.getLocation(), Sound.BLOCK_MOSS_CARPET_HIT, 0.6f, 0.0f);
            }));
            return;
        }
        addItem(48, (Icon) null);
        addItem(50, (Icon) null);
    }

    private ItemStack itemize(@Nonnull LootEntry<?> entry) {
        return ItemStackBuilder.of(((ItemLootEntry) entry).get()).meta(itemMeta -> {
            List<String> lore = itemMeta.getLore();
            if (lore != null) {
                lore.add(Text.color("&8&m----------------------------------"));
            } else {
                lore = new ArrayList<>(4);
                if (itemMeta.hasEnchants()) {
                    lore.add(Text.color("&8&m----------------------------------"));
                }
            }
            Probability probability = entry.probability();
            if (probability instanceof DynamicProbability) {
                lore.add(Text.color("&aProbability: &e" + ((DynamicProbability) probability).min().multiply(BigDecimal.valueOf(100.0d)) + "% to " + ((DynamicProbability) probability).max().multiply(BigDecimal.valueOf(100.0d)) + "%"));
            } else {
                lore.add(Text.color("&aProbability: &e" + probability.get().multiply(BigDecimal.valueOf(100.0d)) + "%"));
            }
            lore.add(Text.color("&aRolls: &e" + entry.rolls()));
            lore.add(" ");
            lore.add(Text.color("&eLeft-Click to edit"));
            lore.add(Text.color("&eRight-Click to delete"));
            itemMeta.setLore(lore);
            return itemMeta;
        }).build();
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/LootTableGui$LootEntryGui.class */
    public static final class LootEntryGui extends Gui {
        private final SupplyDrop supplyDrop;
        private final Integer model;
        private LootEntry<?> lootEntry;
        private final ProbabilityAdjuster probabilityAdjuster;
        private final SupplyDropsPlugin plugin;
        private final AdvancedSlotManager advancedSlotManager;
        private AdvancedSlot advancedSlot;
        private static final ItemStack INPUT_HEAD = ItemStackBuilder.of(Material.PLAYER_HEAD).name(Text.color("&cInput item")).lore(Text.color("&7Insert the loot item into this slot to begin.")).meta(itemMeta -> {
            SkullMeta skullMeta = (SkullMeta) itemMeta;
            PlayerProfile playerProfile = Bukkit.createPlayerProfile("t");
            try {
                playerProfile.getTextures().setSkin(new URL("http://textures.minecraft.net/texture/7f3ca4f7c92dde3a77ec510a74ba8c2e8d0ec7b80f0e348cc6dddd6b458bd"), PlayerTextures.SkinModel.CLASSIC);
            } catch (MalformedURLException exception) {
                exception.printStackTrace();
            }
            skullMeta.setOwnerProfile(playerProfile);
            return skullMeta;
        }).build();

        public LootEntryGui(@Nonnull Player player, @Nonnull SupplyDrop supplyDrop, @Nonnull Integer model, @Nullable LootEntry<?> lootEntry, @Nonnull SupplyDropsPlugin plugin) {
            super(player, "supplydrops-loot-table-entry-gui", Text.color("Editing &lloot entry&r for ") + supplyDrop.meta().name(), 6);
            this.advancedSlotManager = new AdvancedSlotManager(this);
            this.supplyDrop = supplyDrop;
            this.model = model;
            this.lootEntry = lootEntry;
            if (lootEntry == null) {
                this.probabilityAdjuster = new ProbabilityAdjuster(false, BigDecimal.valueOf(0.1d), BigDecimal.valueOf(0.5d), 1);
            } else {
                Probability probability = lootEntry.probability();
                if (probability instanceof DynamicProbability) {
                    this.probabilityAdjuster = new ProbabilityAdjuster(true, ((DynamicProbability) probability).min(), ((DynamicProbability) probability).max(), lootEntry.rolls());
                } else {
                    this.probabilityAdjuster = new ProbabilityAdjuster(false, probability.get(), BigDecimal.ZERO, lootEntry.rolls());
                }
            }
            this.plugin = plugin;
        }

        @Override // mc.obliviate.inventory.Gui
        public void onOpen(InventoryOpenEvent event) {
            fillGui(SupplyDropGui.PLACEHOLDER, IntSets.fromTo(45, 54));
            build();
            addItem(49, new Icon(Material.BARRIER).setName(Text.color("&cBack to loot table")).onClick(clickEvent -> {
                this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
                new LootTableGui(this.player, this.supplyDrop, this.model, this.plugin).open();
            }));
        }

        @Override // mc.obliviate.inventory.Gui
        public void onClose(InventoryCloseEvent event) {
            Probability probability = this.probabilityAdjuster.dynamic() ? new DynamicProbability(this.probabilityAdjuster.getMin(), this.probabilityAdjuster.getMax()) : new StaticProbability(this.probabilityAdjuster.getMin());
            if (this.lootEntry == null) {
                if (this.advancedSlot.getItemStack() == null || INPUT_HEAD.isSimilar(this.advancedSlot.getItemStack())) {
                    return;
                }
                this.lootEntry = ItemLootEntry.newBuilder().item(this.advancedSlot.getItemStack()).rolls(this.probabilityAdjuster.rolls()).probability(probability).build();
                this.supplyDrop.lootTable().add(this.lootEntry);
                return;
            }
            this.lootEntry.probability(probability);
            this.lootEntry.rolls(this.probabilityAdjuster.rolls());
        }

        private void build() {
            List<String> singletonList;
            boolean dynamic = this.probabilityAdjuster.dynamic();
            Icon name = new Icon(Material.EXPERIENCE_BOTTLE).setName(Text.color("&aProbability"));
            String[] strArr = new String[6];
            strArr[0] = Text.color("&7Adjust the probability of the item");
            strArr[1] = Text.color("&7appearing in the supply drop.");
            strArr[2] = " ";
            strArr[3] = Text.color("&aProbability: &e" + (dynamic ? this.probabilityAdjuster.getMin().multiply(BigDecimal.valueOf(100.0d)) + "% to " + this.probabilityAdjuster.getMax().multiply(BigDecimal.valueOf(100.0d)) + "%" : this.probabilityAdjuster.getMin().multiply(BigDecimal.valueOf(100.0d)) + "%"));
            strArr[4] = Text.color("&aMode: &e" + this.probabilityAdjuster);
            strArr[5] = " ";
            Icon lore = name.setLore(strArr);
            if (dynamic) {
                String[] strArr2 = new String[5];
                strArr2[0] = Text.color("&aBound: &e") + (this.probabilityAdjuster.lowerBound() ? "Low" : "High");
                strArr2[1] = " ";
                strArr2[2] = Text.color("&eShift + Left-Click&a to change bounds");
                strArr2[3] = " ";
                strArr2[4] = Text.color("&eLeft-Click&a to change modes");
                singletonList = Arrays.asList(strArr2);
            } else {
                singletonList = Collections.singletonList(Text.color("&eLeft-Click&a to change modes"));
            }
            addItem(19, lore.appendLore(singletonList).onClick(clickEvent -> {
                if (clickEvent.isLeftClick()) {
                    if (this.probabilityAdjuster.dynamic() && clickEvent.isShiftClick()) {
                        this.probabilityAdjuster.flipBound();
                    } else if (!clickEvent.isShiftClick()) {
                        this.probabilityAdjuster.flip();
                    }
                    build();
                    this.player.playSound(this.player.getLocation(), Sound.ENTITY_BEE_STING, 0.1f, 0.1f);
                }
            }));
            addItem(27, new Icon(Material.OAK_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&d±0.01%")).setLore(Text.color("&eLeft-Click&7 to add &a+0.01%&7 to the probability"), Text.color("&eRight-Click&7 to remove &c-0.01%&7 from the probability.")).onClick(clickEvent2 -> {
                BigDecimal amount = BigDecimal.valueOf(clickEvent2.isLeftClick() ? 1.0E-4d : -1.0E-4d);
                this.probabilityAdjuster.adjustBounds(amount);
                build();
                this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent2.isLeftClick() ? 1.87f : 0.8f);
            }));
            addItem(28, new Icon(Material.STONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&d±0.1%")).setLore(Text.color("&eLeft-Click&7 to add &a+0.1%&7 to the probability"), Text.color("&eRight-Click&7 to remove &c-0.1%&7 from the probability.")).onClick(clickEvent3 -> {
                BigDecimal amount = BigDecimal.valueOf(clickEvent3.isLeftClick() ? 0.001d : -0.001d);
                this.probabilityAdjuster.adjustBounds(amount);
                build();
                this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent3.isLeftClick() ? 1.87f : 0.8f);
            }));
            addItem(29, new Icon(Material.POLISHED_BLACKSTONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&d±1%")).setLore(Text.color("&eLeft-Click&7 to add &a+1.0%&7 to the probability"), Text.color("&eRight-Click&7 to remove &c-1.0%&7 from the probability.")).onClick(clickEvent4 -> {
                BigDecimal amount = BigDecimal.valueOf(clickEvent4.isLeftClick() ? 0.01d : -0.01d);
                this.probabilityAdjuster.adjustBounds(amount);
                build();
                this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent4.isLeftClick() ? 1.87f : 0.8f);
            }));
            addItem(25, new Icon(Material.CONDUIT).setName(Text.color("&aRolls")).setLore(Text.color("&7Adjust rolls of the item. The roll represents"), Text.color("&7a multiplier for the probability."), " ", Text.color("&bFormula: &dprobability &5* &droll = final probability"), " ", Text.color("&aRolls: &e" + this.probabilityAdjuster.rolls())));
            addItem(33, new Icon(Material.OAK_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&a+1")).setLore(Text.color("&eLeft-Click&7 to add &a+1&7 to the rolls."), Text.color("&eRight-Click&7 to remove &c-1&7 from the rolls.")).onClick(clickEvent5 -> {
                int amount = clickEvent5.isLeftClick() ? 1 : -1;
                this.probabilityAdjuster.adjustRoll(amount);
                build();
                this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent5.isLeftClick() ? 1.87f : 0.8f);
            }));
            addItem(34, new Icon(Material.STONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&a+10")).setLore(Text.color("&eLeft-Click&7 to add &a+10&7 to the rolls."), Text.color("&eRight-Click&7 to remove &c-10&7 from the rolls.")).onClick(clickEvent6 -> {
                int amount = clickEvent6.isLeftClick() ? 10 : -10;
                this.probabilityAdjuster.adjustRoll(amount);
                build();
                this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent6.isLeftClick() ? 1.87f : 0.8f);
            }));
            addItem(35, new Icon(Material.POLISHED_BLACKSTONE_BUTTON).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&a+100")).setLore(Text.color("&eLeft-Click&7 to add &a+100&7 to the rolls."), Text.color("&eRight-Click&7 to remove &c-100&7 from the rolls.")).onClick(clickEvent7 -> {
                int amount = clickEvent7.isLeftClick() ? 100 : -100;
                this.probabilityAdjuster.adjustRoll(amount);
                build();
                this.player.playSound(this.player.getLocation(), Sound.UI_BUTTON_CLICK, 0.3f, clickEvent7.isLeftClick() ? 1.87f : 0.8f);
            }));
            Icon inputIcon = new Icon(INPUT_HEAD.clone());
            this.advancedSlot = this.advancedSlotManager.addAdvancedIcon(22, inputIcon);
            if (this.lootEntry != null) {
                this.advancedSlotManager.putIconToAdvancedSlot(this.advancedSlot, ItemStackBuilder.of((ItemStack) this.lootEntry.get()).build());
            } else if (this.probabilityAdjuster.original() != null) {
                this.advancedSlotManager.putIconToAdvancedSlot(this.advancedSlot, this.probabilityAdjuster.original());
            }
            this.advancedSlot.onPrePickupClick((event, item) -> {
                return event.isShiftClick();
            });
            this.advancedSlot.onPrePutClick((event2, itemStack )-> {
                return false;
            });
            this.advancedSlot.onPut((event3, itemStack2) -> {
                if (itemStack2.getType() == Material.AIR || INPUT_HEAD.isSimilar(itemStack2)) {
                    this.probabilityAdjuster.original(null);
                } else {
                    this.probabilityAdjuster.original(itemStack2);
                }
            });
        }

        /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/LootTableGui$LootEntryGui$ProbabilityAdjuster.class */
        public static final class ProbabilityAdjuster {
            private boolean dynamic;
            private boolean lowerBound = true;
            private BigDecimal min;
            private BigDecimal max;
            private int rolls;
            private ItemStack original;

            public ProbabilityAdjuster(boolean dynamic, BigDecimal min, BigDecimal max, int rolls) {
                this.rolls = 1;
                this.dynamic = dynamic;
                this.min = min;
                this.max = max;
                this.rolls = rolls;
            }

            public boolean dynamic() {
                return this.dynamic;
            }

            public boolean lowerBound() {
                return this.lowerBound;
            }

            public void flip() {
                this.dynamic = !this.dynamic;
            }

            public void flipBound() {
                this.lowerBound = !this.lowerBound;
            }

            public void original(@Nonnull ItemStack original) {
                this.original = original;
            }

            public void adjustBounds(BigDecimal amount) {
                if (!this.dynamic) {
                    this.min = BigDecimals.max(BigDecimal.ZERO, BigDecimals.min(BigDecimals.oneHundred(), this.min.add(amount)));
                } else if (this.lowerBound) {
                    this.min = BigDecimals.max(BigDecimal.ZERO, BigDecimals.min(BigDecimals.oneHundred(), this.min.add(amount)));
                } else {
                    this.max = BigDecimals.min(BigDecimal.ONE, BigDecimals.min(BigDecimals.oneHundred(), this.max.add(amount)));
                }
            }

            public void adjustRoll(int rolls) {
                this.rolls = Math.max(1, Math.min(100, this.rolls + rolls));
            }

            @Nonnegative
            public BigDecimal getMin() {
                return this.min;
            }

            @Nonnegative
            public BigDecimal getMax() {
                return this.max;
            }

            @Nonnegative
            public int rolls() {
                return this.rolls;
            }

            @Nullable
            public ItemStack original() {
                return this.original;
            }

            public BigDecimal combined() {
                return (this.dynamic ? this.min.add(this.max).divide(BigDecimal.valueOf(2.0d), 2, RoundingMode.CEILING) : this.min).multiply(BigDecimal.valueOf(this.rolls));
            }

            public String toString() {
                return this.dynamic ? "Range" : "Single";
            }
        }
    }
}

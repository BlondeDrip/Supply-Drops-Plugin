package com.pastebin.api;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/AccountType.class */
public enum AccountType {
    NORMAL(0, "Normal"),
    PRO(1, "Pro");
    
    private final int code;
    private final String name;

    AccountType(int code, String name) {
        this.code = code;
        this.name = name;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static AccountType find(int code) {
        AccountType[] values;
        for (AccountType value : values()) {
            if (value.getCode() == code) {
                return value;
            }
        }
        return null;
    }

    public int getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}

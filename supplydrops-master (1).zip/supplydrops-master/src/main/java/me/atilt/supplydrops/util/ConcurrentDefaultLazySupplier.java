package me.atilt.supplydrops.util;

import java.util.function.Supplier;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/ConcurrentDefaultLazySupplier.class */
public final class ConcurrentDefaultLazySupplier<T> implements LazySupplier<T> {
    private final Supplier<T> handle;
    private volatile T value;

    public ConcurrentDefaultLazySupplier(@Nonnull Supplier<T> supplier) {
        this.handle = supplier;
    }

    @Override // me.atilt.supplydrops.util.LazySupplier
    public Supplier<T> handle() {
        return this.handle;
    }

    @Override // java.util.function.Supplier
    public synchronized T get() {
        if (this.value == null) {
            this.value = this.handle.get();
        }
        return this.value;
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        this.value = null;
    }
}

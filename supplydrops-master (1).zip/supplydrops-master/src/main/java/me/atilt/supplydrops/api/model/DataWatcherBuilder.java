package me.atilt.supplydrops.api.model;

import com.comphenix.protocol.wrappers.WrappedDataValue;
import com.comphenix.protocol.wrappers.WrappedDataWatcher;
import com.comphenix.protocol.wrappers.WrappedWatchableObject;
import java.lang.invoke.MethodType;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/DataWatcherBuilder.class */
public class DataWatcherBuilder implements Builder<WrappedDataWatcher> {
    private final WrappedDataWatcher dataWatcher;

    private DataWatcherBuilder(WrappedDataWatcher dataWatcher) {
        this.dataWatcher = dataWatcher;
    }

    private DataWatcherBuilder() {
        this(new WrappedDataWatcher());
    }

    @Nonnull
    public static DataWatcherBuilder newBuilder() {
        return new DataWatcherBuilder();
    }

    @Nonnull
    public static DataWatcherBuilder newBuilder(WrappedDataWatcher dataWatcher) {
        return new DataWatcherBuilder(dataWatcher);
    }

    @Override // me.atilt.supplydrops.api.model.Builder
    @Nonnull
    public Builder<WrappedDataWatcher> adapt(@Nonnull WrappedDataWatcher other) {
        for (WrappedWatchableObject watchableObject : other.getWatchableObjects()) {
            this.dataWatcher.setObject(watchableObject.getIndex(), watchableObject.getWatcherObject().getSerializer(), watchableObject.getRawValue());
        }
        return this;
    }

    @Override // me.atilt.supplydrops.api.model.Builder
    public Builder<WrappedDataWatcher> copy() {
        return new DataWatcherBuilder(this.dataWatcher.deepClone());
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.api.model.Builder
    @Nonnull
    public WrappedDataWatcher build() {
        return this.dataWatcher;
    }

    @Nonnull
    public <T> DataWatcherBuilder addObject(@Nonnegative int index, WrappedDataWatcher.Serializer serializer, @Nonnull T object) {
        this.dataWatcher.setObject(new WrappedDataWatcher.WrappedDataWatcherObject(index, serializer), object);
        return this;
    }

    @Nonnull
    public <T> DataWatcherBuilder addObject(@Nonnegative int index, @Nonnull T object) {
        return addObject(index, WrappedDataWatcher.Registry.get(wrap(object.getClass())), object);
    }

    @Nonnull
    public List<WrappedDataValue> toDataValues() {
        return objectsToValues(this.dataWatcher);
    }

    @Nonnull
    public static List<WrappedDataValue> objectsToValues(WrappedDataWatcher dataWatcher) {
        List<WrappedDataValue> dataValues = new ArrayList<>(dataWatcher.size());
        Iterator it = dataWatcher.iterator();
        while (it.hasNext()) {
            WrappedWatchableObject wrappedWatchableObject = (WrappedWatchableObject) it.next();
            WrappedDataWatcher.WrappedDataWatcherObject watcherObject = wrappedWatchableObject.getWatcherObject();
            dataValues.add(new WrappedDataValue(watcherObject.getIndex(), watcherObject.getSerializer(), wrappedWatchableObject.getRawValue()));
        }
        return dataValues;
    }

    private <T> Class<T> wrap(Class<T> clazz) {
        return (Class<T>) MethodType.methodType(clazz).wrap().returnType();
    }
}

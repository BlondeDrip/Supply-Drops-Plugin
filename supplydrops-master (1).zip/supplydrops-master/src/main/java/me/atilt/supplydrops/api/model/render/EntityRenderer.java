package me.atilt.supplydrops.api.model.render;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.api.model.entity.Entity;
import org.bukkit.Location;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/render/EntityRenderer.class */
public interface EntityRenderer<T extends Entity> {
    @Nullable
    T entity();

    boolean rendered();

    void render(@Nonnull Location location);

    void unrender();
}

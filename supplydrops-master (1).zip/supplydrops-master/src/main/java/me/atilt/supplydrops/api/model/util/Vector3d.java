package me.atilt.supplydrops.api.model.util;

import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.util.Vector;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/util/Vector3d.class */
public final class Vector3d {
    public static final Vector3d ZERO = new Vector3d(0.0d, 0.0d, 0.0d);
    private final double x;
    private final double y;
    private final double z;

    public Vector3d(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public double getZ() {
        return this.z;
    }

    @Nonnull
    public Vector3d translate(double x, double y, double z) {
        return new Vector3d(this.x + x, this.y + y, this.z + z);
    }

    @Nonnull
    public Vector3d scale(double factor) {
        return new Vector3d(this.x * factor, this.y * factor, this.z * factor);
    }

    @Nonnegative
    public double distanceSquared(@Nonnull Vector3d other) {
        return Math.pow(this.x - other.getX(), 2.0d) + Math.pow(this.y - other.getY(), 2.0d) + Math.pow(this.z - other.getZ(), 2.0d);
    }

    @Nonnegative
    public double distance(@Nonnull Vector3d other) {
        return Math.sqrt(distanceSquared(other));
    }

    @Nonnull
    public Vector3d rotateY(float angle) {
        double angleCos = FastMath.cosDeg(-angle);
        double angleSin = FastMath.sinDeg(-angle);
        double x = (angleCos * this.x) + (angleSin * this.z);
        double z = ((-angleSin) * this.x) + (angleCos * this.z);
        return new Vector3d(x, this.y, z);
    }

    public Vector3d rotate(float angle, Vector3d axis) {
        double cosAngle = FastMath.cos(angle);
        double sinAngle = FastMath.sin(angle);
        double oneMinusCosAngle = 1.0d - cosAngle;
        double x = (this.x * (cosAngle + (axis.getX() * axis.getX() * oneMinusCosAngle))) + (this.y * (((axis.getX() * axis.getY()) * oneMinusCosAngle) - (axis.getZ() * sinAngle))) + (this.z * ((axis.getX() * axis.getZ() * oneMinusCosAngle) + (axis.getY() * sinAngle)));
        double y = (this.x * ((axis.getY() * axis.getX() * oneMinusCosAngle) + (axis.getZ() * sinAngle))) + (this.y * (cosAngle + (axis.getY() * axis.getY() * oneMinusCosAngle))) + (this.z * (((axis.getY() * axis.getZ()) * oneMinusCosAngle) - (axis.getX() * sinAngle)));
        double z = (this.x * (((axis.getZ() * axis.getX()) * oneMinusCosAngle) - (axis.getY() * sinAngle))) + (this.y * ((axis.getZ() * axis.getY() * oneMinusCosAngle) + (axis.getX() * sinAngle))) + (this.z * (cosAngle + (axis.getZ() * axis.getZ() * oneMinusCosAngle)));
        return new Vector3d(x, y, z);
    }

    @Nonnull
    public Vector toBukkit() {
        return new Vector(this.x, this.y, this.z);
    }

    @Nonnull
    public Location toLocation(@Nonnull World world) {
        return new Location(world, this.x, this.y, this.z);
    }

    @Nonnull
    public Block toBlock(@Nonnull World world) {
        return world.getBlockAt(FastMath.floor(this.x), FastMath.floor(this.y), FastMath.floor(this.z));
    }
}

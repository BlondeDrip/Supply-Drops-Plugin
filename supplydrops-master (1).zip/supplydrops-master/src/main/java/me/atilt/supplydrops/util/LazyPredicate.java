package me.atilt.supplydrops.util;

import java.util.function.Predicate;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/LazyPredicate.class */
public interface LazyPredicate<T> extends Predicate<T>, AutoCloseable {
}

package me.atilt.supplydrops.loot;

import java.math.BigDecimal;
import java.util.function.Supplier;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.loot.probability.Probability;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/loot/LootEntry.class */
public interface LootEntry<L> extends Supplier<L>, Comparable<LootEntry<?>>, ConfigurationSerializable {
    @Nonnull
    Probability probability();

    void probability(@Nonnull Probability probability);

    @Nonnegative
    int rolls();

    void rolls(@Nonnegative int i);

    @Override // java.lang.Comparable
    default int compareTo(@Nonnull LootEntry<?> other) {
        return other.probability().get().multiply(BigDecimal.valueOf(other.rolls())).compareTo(probability().get().multiply(BigDecimal.valueOf(rolls())));
    }
}

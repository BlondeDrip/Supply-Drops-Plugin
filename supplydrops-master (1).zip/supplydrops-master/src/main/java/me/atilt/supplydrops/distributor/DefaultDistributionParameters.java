package me.atilt.supplydrops.distributor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.distributor.location.SuitableLocation;
import me.atilt.supplydrops.util.Cuboid;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/distributor/DefaultDistributionParameters.class */
public final class DefaultDistributionParameters implements DistributionParameters {
    private final Cuboid cuboid;
    private final List<SuitableLocation> suitableLocations = new ArrayList();

    private DefaultDistributionParameters(@Nonnull Cuboid cuboid, @Nonnull Collection<SuitableLocation> suitableLocations) {
        this.cuboid = cuboid;
        this.suitableLocations.addAll(suitableLocations);
    }

    @Nonnull
    public static Builder newBuilder() {
        return new Builder();
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/distributor/DefaultDistributionParameters$Builder.class */
    public static class Builder implements me.atilt.supplydrops.api.model.Builder<DistributionParameters> {
        private Location min;
        private Location max;
        private List<SuitableLocation> suitableLocations;

        private Builder() {
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        @Nonnull
        public Builder adapt(@Nonnull DistributionParameters other) {
            Cuboid otherCuboid = other.cuboid();
            if (otherCuboid == null) {
                Location loc = new Location((World) Bukkit.getWorlds().get(0), 0.0d, 0.0d, 0.0d);
                otherCuboid = new Cuboid(loc, loc.clone());
            }
            this.min = otherCuboid.getMin();
            this.max = otherCuboid.getMax();
            this.suitableLocations = other.suitableLocations();
            return this;
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        /* renamed from: copy */
        public me.atilt.supplydrops.api.model.Builder<DistributionParameters> copy() {
            return new Builder().range(this.min.clone(), this.max.clone()).suitableLocations(this.suitableLocations);
        }

        @Nonnull
        public Builder range(@Nonnull Location min, Location max) {
            this.min = min;
            this.max = max;
            return this;
        }

        @Nonnull
        public Builder suitableLocations(@Nonnull List<SuitableLocation> suitableLocations) {
            this.suitableLocations = suitableLocations;
            return this;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // me.atilt.supplydrops.api.model.Builder
        @Nonnull
        public DistributionParameters build() {
            return new DefaultDistributionParameters(new Cuboid(this.min, this.max), this.suitableLocations);
        }
    }

    @Override // me.atilt.supplydrops.distributor.DistributionParameters
    @Nonnull
    public Cuboid cuboid() {
        return this.cuboid;
    }

    @Override // me.atilt.supplydrops.distributor.DistributionParameters
    @Nonnull
    public List<SuitableLocation> suitableLocations() {
        return Collections.unmodifiableList(this.suitableLocations);
    }

    @Nonnull
    public Map<String, Object> serialize() {
        Map<String, Object> tree = new HashMap<>(3);
        tree.put("cuboid", this.cuboid);
        tree.put("suitableLocations", this.suitableLocations);
        return tree;
    }

    @Nonnull
    public static DistributionParameters deserialize(@Nonnull Map<String, Object> tree) {
        return new DefaultDistributionParameters((Cuboid) tree.get("cuboid"), (Collection) tree.get("suitableLocations"));
    }
}

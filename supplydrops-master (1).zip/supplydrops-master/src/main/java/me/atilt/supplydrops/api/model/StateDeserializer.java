package me.atilt.supplydrops.api.model;

import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.api.model.schema.SerializedState;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/StateDeserializer.class */
public interface StateDeserializer extends Function<SerializedState, Supplier<EntitySchema<?>>> {
    @Nullable
    <T extends SerializedState> StateDeserializer supply(@Nonnull T t, @Nonnull Function<T, Supplier<EntitySchema<?>>> function);

    @Nullable
    <T extends SerializedState> StateDeserializer supplyAll(@Nonnull List<T> list, @Nonnull Function<T, Supplier<EntitySchema<?>>> function);
}

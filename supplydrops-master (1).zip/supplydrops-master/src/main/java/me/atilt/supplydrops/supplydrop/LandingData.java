package me.atilt.supplydrops.supplydrop;

import java.time.Duration;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.Chunk;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/supplydrop/LandingData.class */
public final class LandingData {
    private Instant instant;
    private final Set<Chunk> chunks = new HashSet();
    private final Duration expiresIn;

    public LandingData(Duration expiresIn) {
        this.expiresIn = expiresIn;
    }

    public void start() {
        this.instant = Instant.now();
    }

    public void setChunk(Chunk chunk) {
        this.chunks.add(chunk);
    }

    public Set<Chunk> getChunk() {
        return this.chunks;
    }

    public Duration getPassed() {
        return Duration.between(this.instant, Instant.now());
    }

    public Duration remaining() {
        return this.expiresIn.minus(getPassed());
    }

    public boolean isExpired() {
        Duration duration = Duration.between(this.instant, Instant.now());
        return duration.compareTo(this.expiresIn) >= 0;
    }
}

package me.atilt.supplydrops.api.model;

import java.util.function.BiFunction;
import me.atilt.supplydrops.api.model.entity.Entity;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/LimbProvider.class */
public interface LimbProvider extends BiFunction<EntityRenderer<?>, Schema<? extends Entity>, Limb> {
}

package me.atilt.supplydrops.library.paper.lib.features.blockstatesnapshot;

import org.bukkit.block.Block;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/features/blockstatesnapshot/BlockStateSnapshotBeforeSnapshots.class */
public class BlockStateSnapshotBeforeSnapshots implements BlockStateSnapshot {
    @Override // me.atilt.supplydrops.library.paper.lib.features.blockstatesnapshot.BlockStateSnapshot
    public BlockStateSnapshotResult getBlockState(Block block, boolean useSnapshot) {
        return new BlockStateSnapshotResult(false, block.getState());
    }
}

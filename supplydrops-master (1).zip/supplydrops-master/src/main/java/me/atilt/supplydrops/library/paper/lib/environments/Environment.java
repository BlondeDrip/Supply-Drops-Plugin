package me.atilt.supplydrops.library.paper.lib.environments;

import java.util.concurrent.CompletableFuture;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.atilt.supplydrops.library.paper.lib.features.asyncchunks.AsyncChunks;
import me.atilt.supplydrops.library.paper.lib.features.asyncchunks.AsyncChunksSync;
import me.atilt.supplydrops.library.paper.lib.features.asyncteleport.AsyncTeleport;
import me.atilt.supplydrops.library.paper.lib.features.asyncteleport.AsyncTeleportSync;
import me.atilt.supplydrops.library.paper.lib.features.bedspawnlocation.BedSpawnLocation;
import me.atilt.supplydrops.library.paper.lib.features.bedspawnlocation.BedSpawnLocationSync;
import me.atilt.supplydrops.library.paper.lib.features.blockstatesnapshot.BlockStateSnapshot;
import me.atilt.supplydrops.library.paper.lib.features.blockstatesnapshot.BlockStateSnapshotBeforeSnapshots;
import me.atilt.supplydrops.library.paper.lib.features.blockstatesnapshot.BlockStateSnapshotNoOption;
import me.atilt.supplydrops.library.paper.lib.features.blockstatesnapshot.BlockStateSnapshotResult;
import me.atilt.supplydrops.library.paper.lib.features.chunkisgenerated.ChunkIsGenerated;
import me.atilt.supplydrops.library.paper.lib.features.chunkisgenerated.ChunkIsGeneratedApiExists;
import me.atilt.supplydrops.library.paper.lib.features.chunkisgenerated.ChunkIsGeneratedUnknown;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/library/paper/lib/environments/Environment.class */
public abstract class Environment {
    private final int minecraftVersion;
    private final int minecraftPatchVersion;
    private final int minecraftPreReleaseVersion;
    protected ChunkIsGenerated isGeneratedHandler;
    protected BlockStateSnapshot blockStateSnapshotHandler;
    protected AsyncChunks asyncChunksHandler = new AsyncChunksSync();
    protected AsyncTeleport asyncTeleportHandler = new AsyncTeleportSync();
    protected BedSpawnLocation bedSpawnLocationHandler = new BedSpawnLocationSync();

    public abstract String getName();

    public Environment() {
        this.isGeneratedHandler = new ChunkIsGeneratedUnknown();
        Pattern versionPattern = Pattern.compile("(?i)\\(MC: (\\d)\\.(\\d+)\\.?(\\d+?)?(?: Pre-Release )?(\\d)?\\)");
        Matcher matcher = versionPattern.matcher(Bukkit.getVersion());
        int version = 0;
        int patchVersion = 0;
        int preReleaseVersion = 0;
        if (matcher.find()) {
            MatchResult matchResult = matcher.toMatchResult();
            try {
                version = Integer.parseInt(matchResult.group(2), 10);
            } catch (Exception e) {
            }
            if (matchResult.groupCount() >= 3) {
                try {
                    patchVersion = Integer.parseInt(matchResult.group(3), 10);
                } catch (Exception e2) {
                }
            }
            if (matchResult.groupCount() >= 4) {
                try {
                    preReleaseVersion = Integer.parseInt(matcher.group(4));
                } catch (Exception e3) {
                }
            }
        }
        this.minecraftVersion = version;
        this.minecraftPatchVersion = patchVersion;
        this.minecraftPreReleaseVersion = preReleaseVersion;
        if (isVersion(13, 1)) {
            this.isGeneratedHandler = new ChunkIsGeneratedApiExists();
        }
        if (!isVersion(12)) {
            this.blockStateSnapshotHandler = new BlockStateSnapshotBeforeSnapshots();
        } else {
            this.blockStateSnapshotHandler = new BlockStateSnapshotNoOption();
        }
    }

    public CompletableFuture<Chunk> getChunkAtAsync(World world, int x, int z, boolean gen) {
        return this.asyncChunksHandler.getChunkAtAsync(world, x, z, gen, false);
    }

    public CompletableFuture<Chunk> getChunkAtAsync(World world, int x, int z, boolean gen, boolean isUrgent) {
        return this.asyncChunksHandler.getChunkAtAsync(world, x, z, gen, isUrgent);
    }

    public CompletableFuture<Chunk> getChunkAtAsyncUrgently(World world, int x, int z, boolean gen) {
        return this.asyncChunksHandler.getChunkAtAsync(world, x, z, gen, true);
    }

    public CompletableFuture<Boolean> teleport(Entity entity, Location location, PlayerTeleportEvent.TeleportCause cause) {
        return this.asyncTeleportHandler.teleportAsync(entity, location, cause);
    }

    public boolean isChunkGenerated(World world, int x, int z) {
        return this.isGeneratedHandler.isChunkGenerated(world, x, z);
    }

    public BlockStateSnapshotResult getBlockState(Block block, boolean useSnapshot) {
        return this.blockStateSnapshotHandler.getBlockState(block, useSnapshot);
    }

    public CompletableFuture<Location> getBedSpawnLocationAsync(Player player, boolean isUrgent) {
        return this.bedSpawnLocationHandler.getBedSpawnLocationAsync(player, isUrgent);
    }

    public boolean isVersion(int minor) {
        return isVersion(minor, 0);
    }

    public boolean isVersion(int minor, int patch) {
        return this.minecraftVersion > minor || (this.minecraftVersion >= minor && this.minecraftPatchVersion >= patch);
    }

    public int getMinecraftVersion() {
        return this.minecraftVersion;
    }

    public int getMinecraftPatchVersion() {
        return this.minecraftPatchVersion;
    }

    public int getMinecraftPreReleaseVersion() {
        return this.minecraftPreReleaseVersion;
    }

    public boolean isSpigot() {
        return false;
    }

    public boolean isPaper() {
        return false;
    }
}

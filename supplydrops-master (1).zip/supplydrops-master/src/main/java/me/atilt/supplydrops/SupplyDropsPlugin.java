package me.atilt.supplydrops;

import com.comphenix.protocol.ProtocolLibrary;
import com.pastebin.api.PastebinClient;
import java.io.IOException;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;
import javax.annotation.Nonnull;

import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.InventoryAPI;
import me.atilt.supplydrops.api.model.ArmorStandMockData;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.api.model.DefaultIntModelFactory;
import me.atilt.supplydrops.api.model.DefaultLimbProvider;
import me.atilt.supplydrops.api.model.DefaultStateDeserializer;
import me.atilt.supplydrops.api.model.IntModelFactory;
import me.atilt.supplydrops.api.model.Model;
import me.atilt.supplydrops.api.model.ModelConveyor;
import me.atilt.supplydrops.api.model.render.PacketEntityRendererProvider;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import me.atilt.supplydrops.command.DebugCommand;
import me.atilt.supplydrops.command.SupplyDropCommand;
import me.atilt.supplydrops.config.ConfigMessages;
import me.atilt.supplydrops.distributor.DefaultDistributionParameters;
import me.atilt.supplydrops.distributor.SupplyDropDistributor;
import me.atilt.supplydrops.distributor.location.AirBoxLocation;
import me.atilt.supplydrops.distributor.location.NoLavaLocation;
import me.atilt.supplydrops.distributor.location.NoLeavesLocation;
import me.atilt.supplydrops.distributor.location.NoWaterLocation;
import me.atilt.supplydrops.listener.PacketListener;
import me.atilt.supplydrops.loot.DefaultLootTable;
import me.atilt.supplydrops.loot.ItemLootEntry;
import me.atilt.supplydrops.loot.LootTable;
import me.atilt.supplydrops.loot.probability.DynamicProbability;
import me.atilt.supplydrops.loot.probability.StaticProbability;
import me.atilt.supplydrops.model.SupplyDropModel;
import me.atilt.supplydrops.model.io.DefaultModelIO;
import me.atilt.supplydrops.model.io.ModelIO;
import me.atilt.supplydrops.model.io.read.ModelReader;
import me.atilt.supplydrops.model.registry.ModelRegistry;
import me.atilt.supplydrops.occurrence.periodicity.ReoccurringPeriodicity;
import me.atilt.supplydrops.registry.SupplyDropRegistry;
import me.atilt.supplydrops.supplydrop.DefaultSupplyDrop;
import me.atilt.supplydrops.supplydrop.LastSpawn;
import me.atilt.supplydrops.supplydrop.ModelData;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.supplydrop.SupplyDropMeta;
import me.atilt.supplydrops.util.Cuboid;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import org.bukkit.entity.HumanEntity;
import org.bukkit.plugin.java.JavaPlugin;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/SupplyDropsPlugin.class */
public final class SupplyDropsPlugin extends JavaPlugin {
    public IntModelFactory factory;
    private ModelRegistry modelRegistry;
    private ConfigMessages configMessages;
    private DistributorTicker ticker;
    private InventoryAPI inventoryAPI;
    public static final int SUPPLY_DROP_MOdEL_FACTORY_ID = 1;
    private static SupplyDropsPlugin INSTANCE;
    private SupplyDropRegistry supplyDropRegistry = new SupplyDropRegistry();
    private final PastebinClient client = PastebinClient.builder().developerKey("Qkx2Z9AbEiG386O_XTxQfyosSWDSrP35").build();
    private boolean loaded = false;

    static {
        ConfigurationSerialization.registerClass(StaticProbability.class);
        ConfigurationSerialization.registerClass(DynamicProbability.class);
        ConfigurationSerialization.registerClass(ItemLootEntry.class);
        ConfigurationSerialization.registerClass(LootTable.class);
        ConfigurationSerialization.registerClass(DefaultLootTable.class);
        ConfigurationSerialization.registerClass(AirBoxLocation.class);
        ConfigurationSerialization.registerClass(NoWaterLocation.class);
        ConfigurationSerialization.registerClass(NoLeavesLocation.class);
        ConfigurationSerialization.registerClass(NoLavaLocation.class);
        ConfigurationSerialization.registerClass(ReoccurringPeriodicity.class);
        ConfigurationSerialization.registerClass(Cuboid.class);
        ConfigurationSerialization.registerClass(DefaultDistributionParameters.class);
        ConfigurationSerialization.registerClass(SupplyDropDistributor.class);
        ConfigurationSerialization.registerClass(ColorData.class);
        ConfigurationSerialization.registerClass(LastSpawn.class);
        ConfigurationSerialization.registerClass(ModelData.class);
        ConfigurationSerialization.registerClass(SupplyDropMeta.class);
        ConfigurationSerialization.registerClass(DefaultSupplyDrop.class);
        ConfigurationSerialization.registerClass(DistributorTicker.class);
    }

    public void onEnable() {
        INSTANCE = this;
        saveDefaultConfig();
        this.configMessages = new ConfigMessages();
        this.configMessages.reload(this);
        this.factory = new DefaultIntModelFactory(this);
        ModelConveyor<Model> conveyor = this.factory.conveyorBuilder().schemas(new DefaultStateDeserializer()).renderers(new PacketEntityRendererProvider()).limbs(new DefaultLimbProvider()).handle(SupplyDropModel::new).build();
        this.factory.submitInt(1, conveyor);
        this.modelRegistry = new ModelRegistry();
        ProtocolLibrary.getProtocolManager().addPacketListener(new PacketListener(this));
        try {
            loadSupplyDrops(supplyDropsState -> {
                try {
                    loadModels(modelsState -> {
                        this.inventoryAPI = new InventoryAPI(this);
                        this.inventoryAPI.init();
                        ChunkModelRenderer chunkModelRenderer = new ChunkModelRenderer(this);
                        Bukkit.getPluginManager().registerEvents(chunkModelRenderer, this);
                        getCommand("supplydrops").setExecutor(new SupplyDropCommand(this));
                        getCommand("refresh").setExecutor(new DebugCommand(this));
                        Object got = getConfig().get("occurrence");
                        if (got == null) {
                            this.ticker = new DistributorTicker(new ReoccurringPeriodicity(Duration.ofHours(4L)));
                            this.ticker.start(this);
                        } else {
                            this.ticker = (DistributorTicker) got;
                            this.ticker.start(this);
                        }
                        for (SupplyDrop supplyDrop : this.supplyDropRegistry.all().values()) {
                            this.ticker.tickSupplyDrop(supplyDrop);
                        }
                        Bukkit.getScheduler().runTaskLater(this, () -> {
                            this.loaded = true;
                        }, 5L);
                    }, this.supplyDropRegistry.size());
                } catch (IOException exception) {
                    exception.printStackTrace();
                }
            });
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    public void onDisable() {
        ProtocolLibrary.getProtocolManager().removePacketListeners(this);
        try {
            saveSupplyDrops();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        this.modelRegistry.close();
        this.supplyDropRegistry.close();
        getConfig().set("occurrence", this.ticker);
        saveConfig();
        for (Gui gui : this.inventoryAPI.getPlayers().values()) {
            new ArrayList(gui.getInventory().getViewers()).forEach((v0) -> {
                ((HumanEntity) v0).closeInventory();
            });
        }
    }

    @Nonnull
    public static SupplyDropsPlugin self() {
        return INSTANCE;
    }

    public boolean isLoaded() {
        return this.loaded;
    }

    public ConfigMessages configMessages() {
        return this.configMessages;
    }

    @Nonnull
    public PastebinClient pastebin() {
        return this.client;
    }

    public IntModelFactory getFactory() {
        return this.factory;
    }

    @Nonnull
    public ModelRegistry getModelRegistry() {
        return this.modelRegistry;
    }

    @Nonnull
    public SupplyDropRegistry supplyDropRegistry() {
        return this.supplyDropRegistry;
    }

    public DistributorTicker getTicker() {
        return this.ticker;
    }

    private void loadSupplyDrops(BooleanConsumer state) throws IOException {
        Path parent = getDataFolder().toPath();
        Path supplyDrops = parent.resolve("supplydrops");
        Files.createDirectories(supplyDrops, new FileAttribute[0]);
        Stream<Path> files = Files.walk(supplyDrops, new FileVisitOption[0]).filter(x$0 -> {
            return Files.isRegularFile(x$0, new LinkOption[0]);
        });
        try {
            List<Path> collect = files.toList();
            for (Path path : collect) {
                if (path.toString().endsWith(".yml")) {
                    Object data = YamlConfiguration.loadConfiguration(path.toFile()).get("data");
                    if (data instanceof SupplyDrop) {
                        SupplyDrop supplyDrop = (SupplyDrop) data;
                        this.supplyDropRegistry.register(supplyDrop.id(), supplyDrop);
                        getLogger().info("Registered: " + Text.stripFlat(supplyDrop.meta().name()) + " (ID: " + supplyDrop.id() + ")");
                    } else if (files != null) {
                        files.close();
                        return;
                    } else {
                        return;
                    }
                } else if (files != null) {
                    files.close();
                    return;
                } else {
                    return;
                }
            }
            state.accept(true);
            SupplyDropRegistry.initIds(this.supplyDropRegistry.freeId());
            if (files != null) {
                files.close();
            }
        } catch (Throwable th) {
            if (files != null) {
                try {
                    files.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private void loadModels(Consumer<Collection<SerializedState>> state, int drops) throws IOException {
        Path parent = getDataFolder().toPath();
        Path models = parent.resolve("models");
        ModelIO modelIO = new DefaultModelIO(parent);
        Files.createDirectories(models, new FileAttribute[0]);
        Path path = models.resolve("model.txt");
        if (Files.notExists(path, new LinkOption[0])) {
            throw new IllegalStateException("model file not found: model.txt");
        }
        ModelReader modelReader = modelIO.newReader();
        modelReader.supply(() -> {
            return path;
        });
        modelReader.unmarshaller(inputStream -> {
            return new ArmorStandMockData.Unmarshaller(inputStream, new byte[16777216]);
        });
        modelReader.read().whenComplete((parsedStatesData, throwable )-> {
            if (throwable != null) {
                Bukkit.getScheduler().runTask(this, () -> {
                    state.accept(Collections.emptyList());
                    throwable.printStackTrace();
                });
            } else {
                Bukkit.getScheduler().runTask(this, () -> {
                    int d = 0;
                    while (true) {
                        if (d < (drops == 0 ? 1 : drops)) {
                            int id = ModelRegistry.nextId();
                            List<SerializedState> states = (List) new ArrayList(parsedStatesData.states()).clone();
                            ModelData modelData = new ModelData(parsedStatesData.path().getFileName().toString());
                            modelData.storeStates(states);
                            modelData.setId(id);
                            modelData.supply(() -> {
                                return (AudiencedModel) this.factory.manufactureInt(1, states);
                            });
                            getModelRegistry().register(id, modelData);
                            Iterator<Map.Entry<Integer, SupplyDrop>> it = supplyDropRegistry().iterator();
                            while (it.hasNext()) {
                                Map.Entry<Integer, SupplyDrop> supplyDropEntry = it.next();
                                if (supplyDropEntry.getValue().modelData().getFileName().equals(modelData.getFileName())) {
                                    supplyDropEntry.getValue().model(modelData.duplicate());
                                }
                            }
                            d++;
                        } else {
                            state.accept(null);
                            return;
                        }
                    }
                });
            }
        });
    }

    private void saveSupplyDrops() throws IOException {
        Path parent = getDataFolder().toPath();
        Path supplyDrops = parent.resolve("supplydrops");
        Files.createDirectories(supplyDrops, new FileAttribute[0]);
        Stream<Path> pathStream = Files.walk(supplyDrops, new FileVisitOption[0]).filter(x$0 -> {
            return Files.isRegularFile(x$0, new LinkOption[0]);
        });
        try {
            Set<Path> paths = new HashSet<>();
            pathStream.forEach(path -> {
                paths.add(path);
                for (SupplyDrop supplyDrop : supplyDropRegistry().all().values()) {
                    if (Text.stripFlat(supplyDrop.meta().name()).equals(path)) {
                        paths.remove(path);
                    }
                }
            });
            paths.forEach(path2 -> {
                try {
                    renameFile(path2, path2.getFileName().toString() + ".old");
                } catch (IOException exception) {
                    exception.printStackTrace();
                }
            });
            if (pathStream != null) {
                pathStream.close();
            }
            supplyDropRegistry().intIterator().forEachRemaining(entry -> {
                SupplyDrop supplyDrop = (SupplyDrop) entry.getValue();
                if (supplyDrop.getPlayerOwned() != null) {
                    return;
                }
                Path path3 = supplyDrops.resolve(Text.stripFlat(supplyDrop.meta().name()) + ".yml");
                YamlConfiguration loadConfiguration = YamlConfiguration.loadConfiguration(path3.toFile());
                loadConfiguration.set("data", supplyDrop);
                try {
                    loadConfiguration.save(path3.toFile());
                } catch (IOException exception) {
                    exception.printStackTrace();
                }
            });
        } catch (Throwable th) {
            if (pathStream != null) {
                try {
                    pathStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    public static void renameFile(Path filePath, String newFileName) throws IOException {
        String parentDir = filePath.getParent().toString();
        Path target = Path.of(parentDir, new String[]{newFileName});
        Files.move(filePath, target, StandardCopyOption.REPLACE_EXISTING);
    }
}

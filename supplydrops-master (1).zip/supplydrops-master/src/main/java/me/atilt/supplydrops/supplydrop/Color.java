package me.atilt.supplydrops.supplydrop;

import javax.annotation.Nonnull;
import org.bukkit.Material;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/supplydrop/Color.class */
public enum Color {
    WHITE(new java.awt.Color(204, 210, 211)),
    LIGHT_GRAY(new java.awt.Color(124, 124, 114)),
    GRAY(new java.awt.Color(53, 56, 60)),
    BLACK(new java.awt.Color(8, 10, 15)),
    BROWN(new java.awt.Color(95, 58, 31)),
    RED(new java.awt.Color(139, 32, 32)),
    ORANGE(new java.awt.Color(222, 97, 1)),
    YELLOW(new java.awt.Color(238, 173, 21)),
    LIME(new java.awt.Color(94, 168, 25)),
    GREEN(new java.awt.Color(72, 89, 36)),
    CYAN(new java.awt.Color(21, 117, 133)),
    LIGHT_BLUE(new java.awt.Color(35, 135, 197)),
    BLUE(new java.awt.Color(43, 45, 141)),
    PURPLE(new java.awt.Color(100, 32, 155)),
    MAGENTA(new java.awt.Color(165, 46, 155)),
    PINK(new java.awt.Color(211, 100, 141));
    
    public static final Color[] TYPES = values();
    private final java.awt.Color color;
    private final Material[] variations = new Material[BlockType.TYPES.length];

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/supplydrop/Color$BlockType.class */
    public enum BlockType {
        WOOL,
        CARPET,
        TERRACOTTA,
        CONCRETE,
        CONCRETE_POWDER,
        GLAZED_TERRACOTTA,
        STAINED_GLASS,
        STAINED_GLASS_PANE,
        SHULKER_BOX,
        BED,
        CANDLE,
        BANNER,
        DYE;
        
        public static final BlockType[] TYPES = values();
    }

    Color(@Nonnull java.awt.Color color) {
        this.color = color;
    }

    public java.awt.Color java() {
        return this.color;
    }

    @Nonnull
    public Material get(@Nonnull BlockType blockType) {
        int index = blockType.ordinal();
        Material variation = this.variations[index];
        if (variation == null) {
            Material[] materialArr = this.variations;
            Material valueOf = Material.valueOf(name() + "_" + blockType.name());
            variation = valueOf;
            materialArr[index] = valueOf;
        }
        return variation;
    }
}

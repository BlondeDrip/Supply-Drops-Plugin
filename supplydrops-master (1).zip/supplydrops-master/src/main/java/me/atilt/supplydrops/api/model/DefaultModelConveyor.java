package me.atilt.supplydrops.api.model;

import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.entity.Entity;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import me.atilt.supplydrops.api.model.schema.SerializedState;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/DefaultModelConveyor.class */
public final class DefaultModelConveyor<T> implements ModelConveyor<T> {
    private final Supplier<T> handle;
    private final Function<SerializedState, Supplier<EntitySchema<?>>> schemas;
    private final Function<Schema<? extends Entity>, EntityRenderer<?>> renderers;
    private final BiFunction<EntityRenderer<?>, Schema<? extends Entity>, Limb> limbs;
    private final Supplier<List<SerializedState>> defaultSchemas;

    public DefaultModelConveyor(Supplier<T> handle, Function<SerializedState, Supplier<EntitySchema<?>>> schemas, Function<Schema<? extends Entity>, EntityRenderer<?>> renderers, BiFunction<EntityRenderer<?>, Schema<? extends Entity>, Limb> limbs, Supplier<List<SerializedState>> defaultSchemas) {
        this.handle = handle;
        this.schemas = schemas;
        this.renderers = renderers;
        this.limbs = limbs;
        this.defaultSchemas = defaultSchemas;
    }

    @Override // me.atilt.supplydrops.api.model.ModelConveyor
    @Nonnull
    public Supplier<T> handle() {
        return this.handle;
    }

    @Override // me.atilt.supplydrops.api.model.ModelConveyor
    @Nonnull
    public Function<SerializedState, Supplier<EntitySchema<?>>> schemas() {
        return this.schemas;
    }

    @Override // me.atilt.supplydrops.api.model.ModelConveyor
    @Nonnull
    public Function<Schema<? extends Entity>, EntityRenderer<?>> renderers() {
        return this.renderers;
    }

    @Override // me.atilt.supplydrops.api.model.ModelConveyor
    @Nonnull
    public BiFunction<EntityRenderer<?>, Schema<? extends Entity>, Limb> limbs() {
        return this.limbs;
    }

    @Override // me.atilt.supplydrops.api.model.ModelConveyor
    @Nonnull
    public Supplier<List<SerializedState>> defaultStates() {
        return this.defaultSchemas;
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/DefaultModelConveyor$Builder.class */
    public static class Builder<T> implements me.atilt.supplydrops.api.model.Builder<ModelConveyor<T>> {
        private Supplier<T> handle;
        private Function<SerializedState, Supplier<EntitySchema<?>>> schemas;
        private Function<Schema<? extends Entity>, EntityRenderer<?>> renderers;
        private BiFunction<EntityRenderer<?>, Schema<? extends Entity>, Limb> limbs;
        private Supplier<List<SerializedState>> defaultStates;


        @Nonnull
        public Builder<T> handle(@Nonnull Supplier<T> handle) {
            this.handle = handle;
            return this;
        }

        @Nonnull
        public Builder<T> schemas(@Nonnull Function<SerializedState, Supplier<EntitySchema<?>>> schemas) {
            this.schemas = schemas;
            return this;
        }

        @Nonnull
        public Builder<T> renderers(@Nonnull Function<Schema<? extends Entity>, EntityRenderer<?>> renderers) {
            this.renderers = renderers;
            return this;
        }

        @Nonnull
        public Builder<T> limbs(@Nonnull BiFunction<EntityRenderer<?>, Schema<? extends Entity>, Limb> limbs) {
            this.limbs = limbs;
            return this;
        }

        @Nonnull
        public Builder<T> defaultStates(@Nonnull Supplier<List<SerializedState>> defaultStates) {
            this.defaultStates = defaultStates;
            return this;
        }

        @Nonnull
        public Builder<T> adapt(@Nonnull ModelConveyor<T> other) {
            this.handle = other.handle();
            this.schemas = other.schemas();
            this.renderers = other.renderers();
            this.limbs = other.limbs();
            this.defaultStates = other.defaultStates();
            return this;
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        public Builder<T> copy() {
            return new Builder().handle(this.handle).schemas(this.schemas).renderers(this.renderers).limbs(this.limbs).defaultStates(this.defaultStates);
        }

        @Override // me.atilt.supplydrops.api.model.Builder
        @Nonnull
        public ModelConveyor<T> build() {
            return new DefaultModelConveyor(this.handle, this.schemas, this.renderers, this.limbs, this.defaultStates);
        }
    }
}

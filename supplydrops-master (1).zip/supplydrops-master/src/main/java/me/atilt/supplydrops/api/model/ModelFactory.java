package me.atilt.supplydrops.api.model;

import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import me.atilt.supplydrops.api.model.DefaultModelConveyor;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import org.bukkit.plugin.Plugin;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/ModelFactory.class */
public interface ModelFactory<K> {
    @Nonnull
    Plugin plugin();

    @Nonnull
    Map<K, ModelConveyor<? extends Model>> conveyors();

    @Nonnull
    <T extends Model> DefaultModelConveyor.Builder<T> conveyorBuilder();

    @Nullable
    ModelConveyor<? extends Model> submit(@Nonnull K k, @Nonnull ModelConveyor<? extends Model> modelConveyor);

    @Nonnull
    Model manufacture(@Nonnull K k);

    @Nonnull
    Model manufacture(@Nonnull K k, @Nonnull List<SerializedState> list);
}

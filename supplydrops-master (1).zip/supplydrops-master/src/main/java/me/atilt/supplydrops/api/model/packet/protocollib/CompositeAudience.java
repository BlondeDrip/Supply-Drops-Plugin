package me.atilt.supplydrops.api.model.packet.protocollib;

import com.google.common.collect.Iterators;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.Composite;
import me.atilt.supplydrops.api.model.packet.Audience;
import org.bukkit.Bukkit;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/CompositeAudience.class */
public class CompositeAudience<T> implements Composite<Audience<T>>, Audience<T> {
    private final List<Audience<T>> audiences = new ArrayList();

//    @Override // me.atilt.supplydrops.api.model.Composite
//    @Nonnull
//    public /* bridge */ /* synthetic */ Composite bind(@Nonnull Object obj) {
//        return bind(obj);
//    }

    @Nonnull
    public Composite<Audience<T>> bind(@Nonnull Audience<T> composite) {
        this.audiences.add(composite);
        return this;
    }

    @Override // me.atilt.supplydrops.api.model.Composite
    public Composite<Audience<T>> bindAll(@Nonnull Collection<Audience<T>> composites) {
        this.audiences.addAll(composites);
        return this;
    }

    @Override // me.atilt.supplydrops.api.model.packet.Audience
    @Nonnull
    public Set<T> members() {
        Set<T> members = new HashSet<>(this.audiences.size() * Bukkit.getMaxPlayers());
        for (Audience<T> audience : this.audiences) {
            members.addAll(audience);
        }
        return members;
    }

    @Override // java.lang.AutoCloseable
    public void close() throws Exception {
        for (Audience<T> audience : this.audiences) {
            audience.close();
        }
    }

    @Override // java.util.Set, java.util.Collection
    @Nonnegative
    public int size() {
        return this.audiences.size();
    }

    @Nonnegative
    public int innerSize() {
        int size = 0;
        for (Audience<T> audience : this.audiences) {
            size += audience.size();
        }
        return size;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean isEmpty() {
        return this.audiences.isEmpty();
    }

    @Override // java.util.Set, java.util.Collection
    public boolean contains(Object o) {
        for (Audience<T> audience : this.audiences) {
            if (audience.contains(o)) {
                return true;
            }
        }
        return false;
    }

    @Override // java.util.Set, java.util.Collection, java.lang.Iterable
    @Nonnull
    public Iterator<T> iterator() {
        Iterator[] iterators = new Iterator[this.audiences.size()];
        for (int index = 0; index < this.audiences.size(); index++) {
            iterators[index] = this.audiences.iterator();
        }
        return Iterators.concat(iterators);
    }

    @Override // java.util.Set, java.util.Collection
    @Nonnull
    public Object[] toArray() {
        Object[] result = new Object[innerSize()];
        int index = 0;
        for (Audience<T> audience : this.audiences) {
            for (T element : audience) {
                int i = index;
                index++;
                result[i] = element;
            }
        }
        return result;
    }

    @Override // java.util.Set, java.util.Collection
    @Nonnull
    public <T1> T1[] toArray(@Nonnull T1[] a) {
        return (T1[]) this.audiences.toArray(a);
    }

    @Override // java.util.Set, java.util.Collection
    public boolean add(@Nonnull T t) {
        boolean all = true;
        for (Audience<T> audience : this.audiences) {
            if (!audience.add(t)) {
                all = false;
            }
        }
        return all;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean remove(@Nonnull Object o) {
        boolean all = true;
        for (Audience<T> audience : this.audiences) {
            if (!audience.remove(o)) {
                all = false;
            }
        }
        return all;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean containsAll(@Nonnull Collection<?> c) {
        for (Audience<T> audience : this.audiences) {
            if (!audience.containsAll(c)) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean addAll(@Nonnull Collection<? extends T> c) {
        boolean all = true;
        for (Audience<T> audience : this.audiences) {
            if (!audience.addAll(c)) {
                all = false;
            }
        }
        return all;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean retainAll(@Nonnull Collection<?> c) {
        boolean all = true;
        for (Audience<T> audience : this.audiences) {
            if (!audience.retainAll(c)) {
                all = false;
            }
        }
        return all;
    }

    @Override // java.util.Set, java.util.Collection
    public boolean removeAll(@Nonnull Collection<?> c) {
        boolean all = true;
        for (Audience<T> audience : this.audiences) {
            if (!audience.removeAll(c)) {
                all = false;
            }
        }
        return all;
    }

    @Override // java.util.Set, java.util.Collection
    public void clear() {
        for (Audience<T> audience : this.audiences) {
            audience.clear();
        }
        this.audiences.clear();
    }
}

package com.pastebin.api;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/Converter.class */
interface Converter<F, T> {
    T convert(F f);
}

package com.pastebin.api.request;

import java.util.HashMap;
import java.util.Map;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/request/DeleteRequest.class */
public class DeleteRequest implements Request {
    private final String pasteKey;

    private DeleteRequest(String pasteKey) {
        this.pasteKey = pasteKey;
    }

    public static DeleteRequest pasteKey(String pasteKey) {
        return new Builder(pasteKey).build();
    }

    @Override // com.pastebin.api.request.Request
    public Map<String, String> getParameters() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("api_option", "delete");
        parameters.put("api_paste_key", this.pasteKey);
        return parameters;
    }

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:com/pastebin/api/request/DeleteRequest$Builder.class */
    public static class Builder {
        private final String pasteKey;

        public Builder(String pasteKey) {
            this.pasteKey = pasteKey;
        }

        public DeleteRequest build() {
            return new DeleteRequest(this.pasteKey);
        }
    }
}

package me.atilt.supplydrops.occurrence.periodicity;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.TemporalAmount;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nonnull;
import org.jetbrains.annotations.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/occurrence/periodicity/ReoccurringPeriodicity.class */
public class ReoccurringPeriodicity implements Periodicity {
    private Instant origin;
    private Instant current;
    private Instant next;
    private final Duration every;

    public ReoccurringPeriodicity(@Nonnull Duration every) {
        this.every = every;
    }

    private ReoccurringPeriodicity(Instant origin, Instant current, Instant next, Duration every) {
        this.origin = origin;
        this.current = current;
        this.next = next;
        this.every = every;
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.Periodicity
    @Nullable
    public Instant origin() {
        return this.origin;
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.Periodicity
    @Nullable
    public Instant current() {
        return this.current;
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.Periodicity
    @Nullable
    public Instant next() {
        return this.next;
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.Periodicity
    @Nonnull
    public Duration every() {
        return this.every;
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.Periodicity
    @Nonnull
    public Duration until() {
        return Duration.between(Instant.now(), this.next);
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.Periodicity
    public void start() {
        Instant now = Instant.now();
        if (this.origin == null) {
            this.origin = now;
        }
        this.current = now;
        this.next = now.plus((TemporalAmount) this.every);
    }

    @Override // me.atilt.supplydrops.occurrence.periodicity.Periodicity
    public boolean test() {
        return this.origin == null || Instant.now().compareTo(this.next) >= 0;
    }

    @Nonnull
    public Map<String, Object> serialize() {
        Map<String, Object> tree = new HashMap<>(4);
        if (this.origin != null) {
            tree.put("origin", Long.valueOf(this.origin.toEpochMilli()));
            tree.put("current", Long.valueOf(this.current.toEpochMilli()));
            tree.put("next", Long.valueOf(this.next.toEpochMilli()));
        }
        tree.put("every", Long.valueOf(this.every.toMillis()));
        return tree;
    }

    @Nonnull
    public static Periodicity deserialize(@Nonnull Map<String, Object> tree) {
        Object origin = tree.get("origin");
        Duration every = Duration.ofMillis(((Number) tree.get("every")).longValue());
        if (origin == null) {
            return new ReoccurringPeriodicity(every);
        }
        return new ReoccurringPeriodicity(Instant.ofEpochMilli(((Number) origin).longValue()), Instant.ofEpochMilli(((Number) tree.get("current")).longValue()), Instant.ofEpochMilli(((Number) tree.get("next")).longValue()), every);
    }
}

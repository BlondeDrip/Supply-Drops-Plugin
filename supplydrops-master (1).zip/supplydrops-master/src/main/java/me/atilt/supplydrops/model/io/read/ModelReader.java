package me.atilt.supplydrops.model.io.read;

import java.io.InputStream;
import java.nio.file.Path;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.Unmarshallable;
import me.atilt.supplydrops.api.model.schema.SerializedState;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/io/read/ModelReader.class */
public interface ModelReader {
    @Nonnull
    Path target();

    void supply(@Nonnull Supplier<Path> supplier);

    void unmarshaller(@Nonnull Function<InputStream, Unmarshallable<? extends SerializedState>> function);

    @Nonnull
    CompletableFuture<ParsedStatesData> read();

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/io/read/ModelReader$ParsedStatesData.class */
    public static class ParsedStatesData {
        private final Collection<SerializedState> states;
        private final Path path;

        public ParsedStatesData(Collection<SerializedState> states, Path path) {
            this.states = states;
            this.path = path;
        }

        @Nonnull
        public Collection<SerializedState> states() {
            return this.states;
        }

        @Nonnull
        public Path path() {
            return this.path;
        }
    }
}

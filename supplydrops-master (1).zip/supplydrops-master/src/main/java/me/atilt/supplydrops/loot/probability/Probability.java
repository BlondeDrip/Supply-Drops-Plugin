package me.atilt.supplydrops.loot.probability;

import java.math.BigDecimal;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import javax.annotation.Nonnegative;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/loot/probability/Probability.class */
public interface Probability extends Supplier<BigDecimal>, BooleanSupplier, Comparable<Probability>, ConfigurationSerializable {
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.util.function.Supplier
    @Nonnegative
    BigDecimal get();

    boolean test();

    @Override // java.util.function.BooleanSupplier
    default boolean getAsBoolean() {
        return test();
    }
}

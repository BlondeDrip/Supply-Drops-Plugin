package me.atilt.supplydrops;

import java.util.List;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/Descriptable.class */
public interface Descriptable {
    @Nonnull
    Supplier<List<String>> description();
}

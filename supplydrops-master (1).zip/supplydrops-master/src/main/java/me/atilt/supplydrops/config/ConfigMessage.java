package me.atilt.supplydrops.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.bukkit.entity.Entity;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/config/ConfigMessage.class */
public class ConfigMessage implements Message {
    private final String string;
    private final List<Placeholder> placeholders = new ArrayList();

    public ConfigMessage(@Nullable String string) {
        this.string = string;
    }

    @Override // me.atilt.supplydrops.config.Message
    @Nullable
    public String string() {
        return this.string;
    }

    @Override // me.atilt.supplydrops.config.Message
    @Nullable
    public String parse() {
        if (this.string == null) {
            return null;
        }
        String output = this.string;
        for (Placeholder placeholder : this.placeholders) {
            output = this.string.replace(placeholder.key(), placeholder.value().get());
        }
        return output;
    }

    @Override // me.atilt.supplydrops.config.Message
    @Nonnull
    public List<Placeholder> placeholders() {
        return Collections.unmodifiableList(this.placeholders);
    }

    @Override // me.atilt.supplydrops.config.Message
    public void send(@Nonnull Entity entity) {
        String parsed = parse();
        if (parsed == null) {
            return;
        }
        entity.sendMessage(parsed);
    }
}

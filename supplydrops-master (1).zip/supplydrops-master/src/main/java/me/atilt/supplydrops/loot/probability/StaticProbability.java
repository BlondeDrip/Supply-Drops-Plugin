package me.atilt.supplydrops.loot.probability;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import javax.annotation.Nonnegative;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/loot/probability/StaticProbability.class */
public final class StaticProbability implements Probability {
    private final BigDecimal probability;

    public StaticProbability(@Nonnegative BigDecimal probability) {
        this.probability = probability;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // me.atilt.supplydrops.loot.probability.Probability, java.util.function.Supplier
    public BigDecimal get() {
        return this.probability;
    }

    @Override // me.atilt.supplydrops.loot.probability.Probability
    public boolean test() {
        BigDecimal probability = get();
        double generated = ThreadLocalRandom.current().nextDouble();
        return probability.compareTo(BigDecimal.ZERO) > 0 && generated <= probability.doubleValue();
    }

    @Override // java.lang.Comparable
    public int compareTo(@Nonnull Probability other) {
        return other.get().compareTo(this.probability);
    }

    @Nonnull
    public Map<String, Object> serialize() {
        return Collections.singletonMap("probability", this.probability.toString());
    }

    @Nonnull
    public static Probability deserialize(@Nonnull Map<String, Object> tree) {
        return new StaticProbability(new BigDecimal((String) tree.get("probability")));
    }
}

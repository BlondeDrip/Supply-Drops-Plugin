package me.atilt.supplydrops;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Stream;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.api.model.entity.Entity;
import me.atilt.supplydrops.command.Permission;
import me.atilt.supplydrops.supplydrop.ModelData;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.world.ChunkLoadEvent;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/ChunkModelRenderer.class */
public class ChunkModelRenderer implements Listener {
    private final SupplyDropsPlugin plugin;

    public ChunkModelRenderer(SupplyDropsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void on(ChunkLoadEvent event) {
        List<Player> entities = Arrays.stream(event.getChunk().getEntities()).filter(entity -> entity instanceof Player).map(entity -> (Player) entity).toList();
        if (entities.isEmpty()) {
            return;
        }
        for (ModelData modelData : this.plugin.getModelRegistry().all().values()) {
            if (!modelData.empty()) {
                AudiencedModel audiencedModel = modelData.getHandle().get();
                if (audiencedModel.getLocation() != null) {
                    audiencedModel.audience().addAll(entities);
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void on(PlayerJoinEvent event) {
        UUID player = event.getPlayer().getUniqueId();
        if (!this.plugin.isLoaded()) {
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                event.getPlayer().kickPlayer("Server starting... rejoin in a moment.");
            }, 1L);
        } else {
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                for (SupplyDrop supplyDrop : this.plugin.supplyDropRegistry().all().values()) {
                    ModelData modelData = supplyDrop.modelData();
                    if (!modelData.empty() && modelData.getHandle() != null) {
                        AudiencedModel audiencedModel = modelData.getHandle().get();
                        if (audiencedModel.getLocation() != null) {
                            Player online = Bukkit.getPlayer(player);
                            if (online != null) {
                                audiencedModel.audience().add(online);
                            } else {
                                return;
                            }
                        } else {
                            continue;
                        }
                    }
                }
            }, 40L);
        }
    }

    @EventHandler
    public void on(PlayerTeleportEvent event) {
        Location from = event.getFrom();
        Location to = event.getTo();
        if (from.getChunk().equals(to.getChunk())) {
            return;
        }
        for (ModelData modelData : this.plugin.getModelRegistry().all().values()) {
            if (!modelData.empty()) {
                AudiencedModel audiencedModel = modelData.getHandle().get();
                if (audiencedModel.getLocation() != null) {
                    audiencedModel.audience().add(event.getPlayer());
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void on(BlockPlaceEvent event) {
        if (Permission.BUILD_BYPASS.has(event.getPlayer())) {
            return;
        }
        handleBuilding(event);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void on(BlockBreakEvent event) {
        if (Permission.BUILD_BYPASS.has(event.getPlayer())) {
            return;
        }
        handleBuilding(event);
    }

    private void handleBuilding(BlockEvent event) {
        Location modelLocation;
        if ((event instanceof BlockBreakEvent) || (event instanceof BlockPlaceEvent)) {
            Player player = event instanceof BlockBreakEvent ? ((BlockBreakEvent) event).getPlayer() : ((BlockPlaceEvent) event).getPlayer();
            double radius = this.plugin.getConfig().getDouble("supply-drops.blocked-block-placement-radius");
            if (radius <= 0.0d) {
                return;
            }
            for (SupplyDrop supplyDrop : this.plugin.supplyDropRegistry().all().values()) {
                if (!supplyDrop.modelData().empty()) {
                    AudiencedModel audiencedModel = supplyDrop.modelData().getHandle().get();
                    if (audiencedModel.rendered() && (modelLocation = audiencedModel.getLocation()) != null && modelLocation.getWorld().equals(player.getWorld()) && modelLocation.getChunk().equals(player.getLocation().getChunk())) {
                        Location blockLocation = event.getBlock().getLocation();
                        if (blockLocation.distanceSquared(modelLocation) <= radius * radius) {
                            ((Cancellable) event).setCancelled(true);
                            player.sendMessage(this.plugin.configMessages().getString("supply-drop.build.blocked"));
                            return;
                        }
                    }
                }
            }
        }
    }

    private boolean isChunkInRange(int centerX, int centerZ, int checkX, int checkZ) {
        int dx = Math.abs(centerX - checkX);
        int dz = Math.abs(centerZ - checkZ);
        return dx <= 4 && dz <= 4;
    }
}

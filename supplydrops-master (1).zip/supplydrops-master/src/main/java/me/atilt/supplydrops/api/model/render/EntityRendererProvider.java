package me.atilt.supplydrops.api.model.render;

import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;
import me.atilt.supplydrops.api.model.Schema;
import me.atilt.supplydrops.api.model.entity.Entity;
import org.bukkit.entity.EntityType;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/render/EntityRendererProvider.class */
public interface EntityRendererProvider<T extends Entity> extends Function<Schema<? extends Entity>, EntityRenderer<?>> {
    Map<EntityType, Supplier<T>> mappings();
}

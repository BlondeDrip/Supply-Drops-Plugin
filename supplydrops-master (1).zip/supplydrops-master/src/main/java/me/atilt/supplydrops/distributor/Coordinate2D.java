package me.atilt.supplydrops.distributor;

import org.bukkit.World;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/distributor/Coordinate2D.class */
public class Coordinate2D {
    private final World world;
    private final int x;
    private final int z;

    public Coordinate2D(World world, int x, int z) {
        this.world = world;
        this.x = x;
        this.z = z;
    }

    public World getWorld() {
        return this.world;
    }

    public int getX() {
        return this.x;
    }

    public int getZ() {
        return this.z;
    }

    public double distance(int x, int z) {
        int deltaX = x - this.x;
        int deltaZ = z - this.z;
        return (deltaX * deltaX) + (deltaZ * deltaZ);
    }

    public double distance(Coordinate2D other) {
        return distance(other.getX(), other.getZ());
    }
}

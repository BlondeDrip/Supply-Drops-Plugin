package me.atilt.supplydrops.command;

import com.pastebin.api.Expiration;
import com.pastebin.api.Format;
import com.pastebin.api.Visibility;
import com.pastebin.api.request.PasteRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.api.model.packet.ProtocolVersion;
import me.atilt.supplydrops.distributor.DefaultDistributionParameters;
import me.atilt.supplydrops.distributor.DistributionParameters;
import me.atilt.supplydrops.distributor.location.SuitableLocation;
import me.atilt.supplydrops.gui.SupplyDropGui;
import me.atilt.supplydrops.supplydrop.ModelData;
import me.atilt.supplydrops.supplydrop.Ownership;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.Axis;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;
import org.jetbrains.annotations.Nullable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/command/SupplyDropCommand.class */
public class SupplyDropCommand implements CommandExecutor, TabCompleter {
    private final SupplyDropsPlugin plugin;
    private final Function<CommandSender, Supplier<List<CommandArg>>> COMMANDS = sender -> {
        return () -> {
            List<CommandArg> commandArgs = new ArrayList<>(6);
            commandArgs.add(new CommandArg(0, List.of("spawn", "debug", "reload")));
            CommandArg playerArg = new CommandArg(1);
            for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                if ((sender instanceof Player) && ((Player) sender).canSee(onlinePlayer)) {
                    playerArg.addCompletion(onlinePlayer.getName());
                }
            }
            commandArgs.add(playerArg);
            CommandArg supplyDropsArg = new CommandArg(2);
            Iterator<Map.Entry<Integer, SupplyDrop>> it = SupplyDropsPlugin.self().supplyDropRegistry().iterator();
            while (it.hasNext()) {
                Map.Entry<Integer, SupplyDrop> entry = it.next();
                supplyDropsArg.addCompletion(Text.stripFlat(entry.getValue().meta().name().replace(" ", "_")));
            }
            commandArgs.add(supplyDropsArg);
            CommandArg worldArg = new CommandArg(3);
            for (World world : Bukkit.getWorlds()) {
                worldArg.addCompletion(world.getName());
            }
            commandArgs.add(worldArg);
            List<String> coordinate = List.of("0");
            commandArgs.add(new CommandArg(4, sender instanceof Entity ? Arrays.asList("~", Integer.toString(((Entity) sender).getLocation().getBlockX())) : coordinate));
            commandArgs.add(new CommandArg(5, sender instanceof Entity ? Arrays.asList("~", Integer.toString(((Entity) sender).getLocation().getBlockZ())) : coordinate));
            return commandArgs;
        };
    };

    public SupplyDropCommand(SupplyDropsPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(@Nonnull CommandSender commandSender, @Nonnull Command command, @Nonnull String label, @Nonnull String[] arguments) {
        if (!Permission.COMMAND_ADMIN.has(commandSender)) {
            commandSender.sendMessage(this.plugin.configMessages().getString("command.no-permission"));
            return true;
        } else if (arguments.length == 0) {
            if (!(commandSender instanceof Player)) {
                commandSender.sendMessage(this.plugin.configMessages().getString("command.in-game-only"));
                return true;
            }
            new SupplyDropGui((Player) commandSender, this.plugin).open();
            return true;
        } else {
            String option = arguments[0].toLowerCase();
            if (option.equals("spawn")) {
                if (arguments.length == 3) {
                    Player forPlayer = Bukkit.getPlayer(arguments[1]);
                    if (forPlayer == null) {
                        commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.player-not-found", s -> {
                            return s.replace("%name%", arguments[1]);
                        }));
                        return true;
                    }
                    SupplyDrop supplyDrop = null;
                    String name = null;
                    Iterator<SupplyDrop> it = this.plugin.supplyDropRegistry().all().values().iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            break;
                        }
                        SupplyDrop found = it.next();
                        if (found.getPlayerOwned() == null && Text.stripFlat(found.meta().name().replace(" ", "_")).equalsIgnoreCase(arguments[2])) {
                            supplyDrop = found;
                            name = found.meta().name();
                            break;
                        }
                    }
                    if (supplyDrop == null) {
                        commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.not-found", s2 -> {
                            return s2.replace("%name%", arguments[2]);
                        }));
                        return true;
                    } else if (supplyDrop.lootTable().empty()) {
                        commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.missing-loot-table"));
                        return true;
                    } else {
                        Location location = forPlayer.getLocation();
                        Block block = location.getBlock();
                        List<SuitableLocation> suitableLocations = supplyDrop.distributor().parameters().suitableLocations();
                        for (int x = -1; x <= 1; x++) {
                            for (int z = -1; z <= 1; z++) {
                                for (int y = 1; y <= 3; y++) {
                                    Block relative = block.getRelative(x, y, z);
                                    for (SuitableLocation suitableLocation : suitableLocations) {
                                        if (!suitableLocation.test(relative)) {
                                            commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.unsuitable-location"));
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                        SupplyDrop created = supplyDrop.newPlayer(commandSender instanceof Entity ? new Ownership(((Entity) commandSender).getUniqueId(), forPlayer.getUniqueId(), location) : Ownership.console(forPlayer.getUniqueId(), location));
                        String finalName = name;
                        DistributionParameters parameters = created.distributor().parameters();
                        DistributionParameters managed = DefaultDistributionParameters.newBuilder().adapt(parameters).range(location, location).build();
                        created.distributor().parameters(managed);
                        created.distributor().distribute(created, 1, locationAttempt -> {
                            if (!locationAttempt.getLast()) {
                                commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.unsuitable-location"));
                                this.plugin.supplyDropRegistry().unregister(created.id());
                                return;
                            }
                            commandSender.sendMessage(Text.color(this.plugin.configMessages().getString("command.supply-drop.spawned", s3 -> {
                                return s3.replace("%name%", Text.color(finalName));
                            })));
                            created.model().audience().addAll(Bukkit.getOnlinePlayers());
                        });
                        return true;
                    }
                } else if (arguments.length == 6) {
                    Player forPlayer2 = Bukkit.getPlayer(arguments[1]);
                    if (forPlayer2 == null) {
                        commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.player-not-found", s3 -> {
                            return s3.replace("%name%", arguments[1]);
                        }));
                        return true;
                    }
                    SupplyDrop supplyDrop2 = null;
                    String name2 = null;
                    Iterator<SupplyDrop> it2 = this.plugin.supplyDropRegistry().all().values().iterator();
                    while (true) {
                        if (!it2.hasNext()) {
                            break;
                        }
                        SupplyDrop found2 = it2.next();
                        if (found2.getPlayerOwned() == null && Text.stripFlat(found2.meta().name().replace(" ", "_")).equalsIgnoreCase(arguments[2])) {
                            supplyDrop2 = found2;
                            name2 = found2.meta().name();
                            break;
                        }
                    }
                    if (supplyDrop2 == null) {
                        commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.not-found", s4 -> {
                            return s4.replace("%name%", arguments[2]);
                        }));
                        return true;
                    } else if (supplyDrop2.lootTable().empty()) {
                        commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.missing-loot-table"));
                        return true;
                    } else {
                        try {
                            World world = Bukkit.getWorld(arguments[3]);
                            if (world == null) {
                                commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.world-not-exist"));
                                return true;
                            }
                            int xCoordinate = getInt(commandSender, arguments[4], Axis.X);
                            int yCoordinate = getInt(commandSender, arguments[5], Axis.Z);
                            Location location2 = new Location(world, xCoordinate, 64.0d, yCoordinate);
                            Block block2 = location2.getBlock();
                            List<SuitableLocation> suitableLocations2 = supplyDrop2.distributor().parameters().suitableLocations();
                            for (int x2 = -1; x2 <= 1; x2++) {
                                for (int z2 = -1; z2 <= 1; z2++) {
                                    for (int y2 = 1; y2 <= 3; y2++) {
                                        Block relative2 = block2.getRelative(x2, y2, z2);
                                        for (SuitableLocation suitableLocation2 : suitableLocations2) {
                                            if (!suitableLocation2.test(relative2)) {
                                                commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.unsuitable-location"));
                                                return true;
                                            }
                                        }
                                    }
                                }
                            }
                            SupplyDrop created2 = supplyDrop2.newPlayer(commandSender instanceof Entity ? new Ownership(((Entity) commandSender).getUniqueId(), forPlayer2.getUniqueId(), location2) : Ownership.console(forPlayer2.getUniqueId(), location2));
                            String finalName2 = name2;
                            DistributionParameters parameters2 = created2.distributor().parameters();
                            DistributionParameters managed2 = DefaultDistributionParameters.newBuilder().adapt(parameters2).range(location2, location2).build();
                            created2.distributor().parameters(managed2);
                            created2.distributor().distribute(created2, 1, locationAttempt2 -> {
                                if (!locationAttempt2.getLast()) {
                                    commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.unsuitable-location"));
                                    this.plugin.supplyDropRegistry().unregister(created2.id());
                                    return;
                                }
                                commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.spawned", s5 -> {
                                    return s5.replace("%name%", Text.color(finalName2));
                                }));
                                created2.model().audience().addAll(Bukkit.getOnlinePlayers());
                            });
                            return true;
                        } catch (NumberFormatException e) {
                            commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.invalid-coordinates"));
                            return true;
                        }
                    }
                } else {
                    commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.invalid-arguments"));
                    return true;
                }
            } else if (option.equals("debug")) {
                if (commandSender instanceof Entity) {
                    for (SupplyDrop supplyDrop3 : this.plugin.supplyDropRegistry().all().values()) {
                        ModelData modelData = supplyDrop3.modelData();
                        if (!modelData.empty()) {
                            AudiencedModel audiencedModel = modelData.getHandle().get();
                            audiencedModel.audience().addAll(Bukkit.getOnlinePlayers());
                        }
                    }
                }
                StringBuilder supplyDrops = new StringBuilder();
                Iterator<Map.Entry<Integer, SupplyDrop>> it3 = this.plugin.supplyDropRegistry().iterator();
                while (it3.hasNext()) {
                    Map.Entry<Integer, SupplyDrop> entry = it3.next();
                    SupplyDrop value = entry.getValue();
                    supplyDrops.append(entry.getKey()).append(":").append(" ").append(value.meta().name()).append("\n").append(" ").append(" ").append(" ").append("Player owned:").append(" ").append(value.getPlayerOwned() != null).append("\n").append(" ").append(" ").append(" ").append("Can spawn:").append(" ").append(value.canSpawn()).append("\n").append(" ").append(" ").append(" ").append("Loot table:").append(" ").append(!value.lootTable().empty()).append("\n").append("\n");
                }
                String version = this.plugin.getDescription().getVersion();
                String replace = ProtocolVersion.runningVersion().toString().replace("_", ".");
                String name3 = ProtocolVersion.runningVersion().name();
                int size = Bukkit.getOnlinePlayers().size();
                int maxPlayers = Bukkit.getMaxPlayers();
                int size2 = this.plugin.getModelRegistry().size();
                long count = this.plugin.supplyDropRegistry().all().values().stream().filter(supplyDrop4 -> {
                    return (supplyDrop4.modelData().empty() || supplyDrop4.modelData().getHandle().get().getLocation() == null || !supplyDrop4.modelData().getHandle().get().rendered()) ? false : true;
                }).count();
                long count2 = this.plugin.supplyDropRegistry().all().values().stream().map((v0) -> {
                    return v0.modelData();
                }).filter((v0) -> {
                    return v0.empty();
                }).count();
                int size3 = this.plugin.supplyDropRegistry().size();
                long count3 = this.plugin.supplyDropRegistry().all().values().stream().filter(supplyDrop5 -> {
                    return supplyDrop5.lastSpawn() != null && supplyDrop5.landingData() == null && !supplyDrop5.modelData().empty() && supplyDrop5.model().rendered();
                }).count();
                this.plugin.supplyDropRegistry().all().values().stream().filter(Predicate.not((v0) -> {
                    return v0.canSpawn();
                })).count();
                supplyDrops.toString();
                String paste = "Plugin Version: " + version + "\nServer Version: " + replace + " (" + name3 + ")\nOnline Players: " + size + "/" + maxPlayers + "\n \nTotal Models: " + size2 + "\nTotal Loaded Models: " + count + "\nEmpty Data: " + version + "\n \nTotal Supply Drops: " + count2 + "\nFlying Supply Drops: " + version + "\nAborted Supply Drops: " + size3 + "\nSupply drops: \n" + count3;
                try {
                    PasteRequest pasteRequest = PasteRequest.content(paste).name("Supply Drops | Debug").expiration(Expiration.ONE_WEEK).visibility(Visibility.UNLISTED).format(Format.YAML).build();
                    commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.debug.generating"));
                    Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
                        String url = this.plugin.pastebin().paste(pasteRequest);
                        Bukkit.getScheduler().runTask(this.plugin, () -> {
                            commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.debug.generated", s5 -> {
                                return s5.replace("%url%", url);
                            }));
                        });
                    });
                    return true;
                } catch (Exception e2) {
                    String replace2 = ProtocolVersion.runningVersion().toString().replace("_", ".");
                    String name4 = ProtocolVersion.runningVersion().name();
                    int size4 = Bukkit.getOnlinePlayers().size();
                    int maxPlayers2 = Bukkit.getMaxPlayers();
                    int size5 = this.plugin.getModelRegistry().size();
                    Stream<SupplyDrop> filter = this.plugin.supplyDropRegistry().all().values().stream().filter(supplyDrop6 -> {
                        return !supplyDrop6.modelData().empty() && supplyDrop6.modelData().getHandle().get().rendered();
                    });
                    long count4 = this.plugin.supplyDropRegistry().all().values().stream().map((v0) -> {
                        return v0.modelData();
                    }).filter((v0) -> {
                        return v0.empty();
                    }).count();
                    int size6 = this.plugin.supplyDropRegistry().size();
                    long count5 = this.plugin.supplyDropRegistry().all().values().stream().filter(supplyDrop7 -> {
                        return supplyDrop7.lastSpawn() != null && supplyDrop7.landingData() == null && !supplyDrop7.modelData().empty() && supplyDrop7.model().rendered();
                    }).count();
                    this.plugin.supplyDropRegistry().all().values().stream().filter(Predicate.not((v0) -> {
                        return v0.canSpawn();
                    })).count();
                    commandSender.sendMessage(Text.color("&8&m----------------------------------------------\n&7Server Version: &b" + replace2 + " (" + name4 + ")\n&7Online Players: &b" + size4 + "/" + maxPlayers2 + "\n \n&7Total Models: &b" + size5 + "\n&7Total Loaded Models: &b" + filter + "\n&7Empty Data: &b" + count4 + "\n \n&7Total Supply Drops: &b" + commandSender + "\n&7Flying Supply Drops: &b" + size6 + "\n&7Aborted Supply Drops: &b" + count5 + "\n&8&m----------------------------------------------"));
                    return true;
                }
            } else if (option.equals("reload")) {
                this.plugin.reloadConfig();
                this.plugin.configMessages().reload(this.plugin);
                commandSender.sendMessage(this.plugin.configMessages().getString("command.reloaded"));
                return true;
            } else {
                commandSender.sendMessage(this.plugin.configMessages().getString("command.supply-drop.invalid-arguments"));
                return true;
            }
        }
    }

    private int getInt(CommandSender commandSender, String text, Axis axis) throws NumberFormatException {
        if (text.equals("~")) {
            if (commandSender instanceof Entity) {
                Location location = ((Entity) commandSender).getLocation();
                switch (axis) {
                    case X:
                        return location.getBlockX();
                    case Z:
                        return location.getBlockZ();
                }
            }
            throw new NumberFormatException();
        } else if (text.contains("~")) {
            if (commandSender instanceof Entity) {
                String[] split = text.split("~");
                if (split.length != 2) {
                    throw new NumberFormatException();
                }
                int offset = Integer.parseInt(split[1]);
                return (axis == Axis.X ? ((Entity) commandSender).getLocation().getBlockX() : ((Entity) commandSender).getLocation().getBlockZ()) + offset;
            }
            throw new NumberFormatException();
        }
        return Integer.parseInt(text);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/command/SupplyDropCommand$CommandArg.class */
    public static class CommandArg {
        int index;
        private final List<String> completions = new ArrayList();

        public CommandArg(int index, @Nonnull List<String> completions) {
            this.index = index;
            this.completions.addAll(completions);
        }

        public CommandArg(int index) {
            this.index = index;
        }

        public int getIndex() {
            return this.index;
        }

        public List<String> getCompletions() {
            return this.completions;
        }

        public void addCompletion(@Nonnull String completion) {
            this.completions.add(completion);
        }
    }

    @Nullable
    public List<String> onTabComplete(@Nonnull CommandSender commandSender, @Nonnull Command command, @Nonnull String s, @Nonnull String[] arguments) {
        if (!Permission.COMMAND_ADMIN.has(commandSender) || arguments.length > 6) {
            return Collections.emptyList();
        }
        List<CommandArg> commandArgs = this.COMMANDS.apply(commandSender).get();
        int argIndex = arguments.length - 1;
        CommandArg commandArg = commandArgs.get(argIndex);
        List<String> calculated = commandArg.getCompletions();
        List<String> completions = new ArrayList<>(calculated.size());
        StringUtil.copyPartialMatches(arguments[argIndex], calculated, completions);
        Collections.sort(completions);
        return completions;
    }
}

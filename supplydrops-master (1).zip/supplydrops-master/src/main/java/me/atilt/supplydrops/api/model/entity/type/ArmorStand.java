package me.atilt.supplydrops.api.model.entity.type;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.entity.living.LivingEntity;
import org.bukkit.util.EulerAngle;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/entity/type/ArmorStand.class */
public interface ArmorStand extends LivingEntity {

    /* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/entity/type/ArmorStand$Pose.class */
    public enum Pose {
        HEAD,
        BODY,
        LEFT_ARM,
        RIGHT_ARM,
        LEFT_LEG,
        RIGHT_LEG;
        
        public static final Pose[] VALUES = values();
    }

    @Nonnull
    EulerAngle getPose(@Nonnull Pose pose);

    void setPose(@Nonnull Pose pose, EulerAngle eulerAngle);

    boolean isSmall();

    void setSmall(boolean z);
}

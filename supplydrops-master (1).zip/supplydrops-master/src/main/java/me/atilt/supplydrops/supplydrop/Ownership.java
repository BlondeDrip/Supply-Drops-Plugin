package me.atilt.supplydrops.supplydrop;

import java.util.UUID;
import javax.annotation.Nonnull;
import org.bukkit.Location;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/supplydrop/Ownership.class */
public class Ownership {
    public static final UUID CONSOLE_ID = UUID.randomUUID();
    private final UUID id;
    private final UUID forId;
    private final Location location;

    public Ownership(UUID id, UUID forId, Location location) {
        this.id = id;
        this.forId = forId;
        this.location = location;
    }

    public static Ownership console(@Nonnull UUID forId, @Nonnull Location location) {
        return new Ownership(CONSOLE_ID, forId, location);
    }

    public UUID getId() {
        return this.id;
    }

    public UUID getForId() {
        return this.forId;
    }

    public Location getLocation() {
        return this.location;
    }

    public boolean isConsoleOwned() {
        return this.id == CONSOLE_ID;
    }
}

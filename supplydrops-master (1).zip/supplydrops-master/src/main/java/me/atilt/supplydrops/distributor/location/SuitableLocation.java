package me.atilt.supplydrops.distributor.location;

import java.util.Set;
import java.util.function.Predicate;
import me.atilt.supplydrops.Descriptable;
import me.atilt.supplydrops.Iconable;
import org.bukkit.block.Block;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/distributor/location/SuitableLocation.class */
public interface SuitableLocation extends Predicate<Block>, Iconable, Descriptable, ConfigurationSerializable {
    public static final Set<SuitableLocation> ALL = Set.of(AirBoxLocation.INSTANCE, NoLavaLocation.INSTANCE, NoLeavesLocation.INSTANCE, NoWaterLocation.INSTANCE);
}

package me.atilt.supplydrops.api.model.packet;

import java.util.Set;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/Audience.class */
public interface Audience<T> extends Set<T>, AutoCloseable {
    @Nonnull
    Set<T> members();
}

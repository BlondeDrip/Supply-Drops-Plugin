package me.atilt.supplydrops.util;

import java.util.concurrent.TimeUnit;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Durations.class */
public class Durations {
    public static String format(long millis) {
        if (millis <= 800) {
            return "now";
        }
        long totalDays = TimeUnit.MILLISECONDS.toDays(millis);
        long years = totalDays / 365;
        long months = (totalDays % 365) / 30;
        long days = totalDays % 30;
        long hours = (millis / 3600000) % 24;
        long minutes = (millis / 60000) % 60;
        long seconds = (millis / 1000) % 60;
        StringBuilder sb = new StringBuilder();
        if (years > 0) {
            sb.append(years).append("y ");
        }
        if (months > 0) {
            sb.append(months).append("M ");
        }
        if (days > 0) {
            sb.append(days).append("d ");
        }
        if (hours > 0) {
            sb.append(hours).append("h ");
        }
        if (minutes > 0) {
            sb.append(minutes).append("m ");
        }
        if (seconds > 0) {
            sb.append(seconds).append("s");
        }
        return sb.toString().trim();
    }
}

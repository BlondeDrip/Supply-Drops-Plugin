package me.atilt.supplydrops.api.model.packet.protocollib;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.Vector3F;
import com.comphenix.protocol.wrappers.WrappedDataWatcher;
import java.util.UUID;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.DataWatcherBuilder;
import me.atilt.supplydrops.api.model.entity.living.packet.protocol.ProtocolLivingEntity;
import me.atilt.supplydrops.api.model.entity.type.ArmorStand;
import me.atilt.supplydrops.api.model.packet.PacketWrapper;
import me.atilt.supplydrops.api.model.packet.protocollib.entity.EntityMetadataPacket;
import org.bukkit.Bukkit;
import org.bukkit.entity.EntityType;
import org.bukkit.util.EulerAngle;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/packet/protocollib/ProtocolArmorStand.class */
public final class ProtocolArmorStand extends ProtocolLivingEntity implements ArmorStand {
    private final EulerAngle[] poses;
    private boolean small;

    public ProtocolArmorStand(int id, @Nonnull UUID uuid) {
        super(EntityType.ARMOR_STAND, id, uuid);
        this.poses = new EulerAngle[6];
    }

    @Override // me.atilt.supplydrops.api.model.entity.type.ArmorStand
    @Nonnull
    public EulerAngle getPose(@Nonnull ArmorStand.Pose pose) {
        EulerAngle angle = this.poses[pose.ordinal()];
        return angle != null ? angle : EulerAngle.ZERO;
    }

    private EulerAngle radToDeg(EulerAngle angle) {
        return new EulerAngle(Math.toDegrees(angle.getX()), Math.toDegrees(angle.getY()), Math.toDegrees(angle.getZ()));
    }

    @Override // me.atilt.supplydrops.api.model.entity.type.ArmorStand
    public void setPose(@Nonnull ArmorStand.Pose pose, @Nonnull EulerAngle angle) {
        this.poses[pose.ordinal()] = radToDeg(angle);
        EulerAngle found = this.poses[pose.ordinal()];
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.ENTITY_METADATA, packetWrapper -> {
            return (packetWrapper == null ? EntityMetadataPacket.newBuilder() : EntityMetadataPacket.newBuilder(packetWrapper)).entityId(id()).dataWatcher(DataWatcherBuilder.newBuilder(this.dataWatcher).addObject(16 + pose.ordinal(), WrappedDataWatcher.Registry.getVectorSerializer(), new Vector3F((float) found.getX(), (float) found.getY(), (float) found.getZ())).build()).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), Bukkit.getOnlinePlayers());
    }

    @Override // me.atilt.supplydrops.api.model.entity.type.ArmorStand
    public boolean isSmall() {
        return this.small;
    }

    @Override // me.atilt.supplydrops.api.model.entity.type.ArmorStand
    public void setSmall(boolean small) {
        this.small = small;
        PacketWrapper<PacketContainer> packet = modifyPacket(PacketType.Play.Server.ENTITY_METADATA, packetWrapper -> {
            return (packetWrapper == null ? EntityMetadataPacket.newBuilder() : EntityMetadataPacket.newBuilder(packetWrapper)).entityId(id()).dataWatcher(DataWatcherBuilder.newBuilder(this.dataWatcher).addObject(15, Byte.valueOf(modifyBits(supplyBytes(this.dataWatcher, 15), 0, small))).build()).buildPacket();
        });
        ProtocolLibrary.getProtocolManager().broadcastServerPacket(packet.handle(), Bukkit.getOnlinePlayers());
    }
}

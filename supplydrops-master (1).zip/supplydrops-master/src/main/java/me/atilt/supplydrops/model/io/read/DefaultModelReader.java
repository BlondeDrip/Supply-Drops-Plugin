package me.atilt.supplydrops.model.io.read;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nonnull;

import it.unimi.dsi.fastutil.io.FastBufferedInputStream;
import me.atilt.supplydrops.api.model.Unmarshallable;
import me.atilt.supplydrops.api.model.io.ConcurrentFileAccessor;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import me.atilt.supplydrops.model.io.read.ModelReader;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/model/io/read/DefaultModelReader.class */
public final class DefaultModelReader implements ModelReader {
    private Path target;
    private Function<InputStream, Unmarshallable<? extends SerializedState>> unmarshallabler;
    private final ConcurrentFileAccessor<ModelReader.ParsedStatesData> fileAccessor;

    public DefaultModelReader(@Nonnull ConcurrentFileAccessor<ModelReader.ParsedStatesData> fileAccessor) {
        this.fileAccessor = fileAccessor;
    }

    @Override // me.atilt.supplydrops.model.io.read.ModelReader
    @Nonnull
    public Path target() {
        return this.target;
    }

    @Override // me.atilt.supplydrops.model.io.read.ModelReader
    public void supply(@Nonnull Supplier<Path> paths) {
        this.target = paths.get();
    }

    @Override // me.atilt.supplydrops.model.io.read.ModelReader
    public void unmarshaller(@Nonnull Function<InputStream, Unmarshallable<? extends SerializedState>> unmarshallable) {
        this.unmarshallabler = unmarshallable;
    }

    @Override // me.atilt.supplydrops.model.io.read.ModelReader
    @Nonnull
    public CompletableFuture<ModelReader.ParsedStatesData> read() {
        try {
            return this.fileAccessor.newRead().operation((path, inputStream) -> {
                Collection<SerializedState> armorStandDataList = new ArrayList<>(112);
                Unmarshallable<? extends SerializedState> unmarshallable = this.unmarshallabler.apply(inputStream);
                while (true) {
                    try {
                        SerializedState serializedState = unmarshallable.next();
                        if (serializedState != null) {
                            armorStandDataList.add(serializedState);
                        } else {
                            return new ModelReader.ParsedStatesData(armorStandDataList, path);
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }).applyAsync(this.target, new FastBufferedInputStream(Files.newInputStream(this.target, new OpenOption[0])));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

package me.atilt.supplydrops.api.model;

import de.Ste3et_C0st.FurnitureLib.Crafting.Project;
import de.Ste3et_C0st.FurnitureLib.ModelLoader.ModelVector;
import de.Ste3et_C0st.FurnitureLib.main.FurnitureManager;
import de.Ste3et_C0st.FurnitureLib.main.entity.fArmorStand;
import de.Ste3et_C0st.FurnitureLib.main.entity.fEntity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.interpreter.Interpreter;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/FurnitureLibInterpreter.class */
public final class FurnitureLibInterpreter implements Interpreter<List<String>, List<SerializedState>> {
    @Override // me.atilt.supplydrops.api.model.interpreter.Interpreter
    @Nonnull
    public List<SerializedState> interpret(@Nonnull List<String> projects) {
        List<SerializedState> schemas = new ArrayList<>(projects.size());
        for (String project : projects) {
            Project balloon = FurnitureManager.getInstance().getProject(project);
            HashMap<ModelVector, fEntity> entityMap = balloon.getModelschematic().getEntityMap();
            for (Map.Entry<ModelVector, fEntity> entry : entityMap.entrySet()) {
                fEntity value = entry.getValue();
                if (value instanceof fArmorStand) {
                    fArmorStand armorStand = (fArmorStand) value;
                    ModelVector vector = entry.getKey();
                    ArmorStandMockData schemaSchemaProvider = new ArmorStandMockData();
                    schemaSchemaProvider.entityType = "ARMOR_STAND";
                    schemaSchemaProvider.offset = new float[]{(float) vector.getX(), (float) vector.getY(), (float) vector.getZ()};
                    schemaSchemaProvider.yaw = vector.getYaw();
                    schemaSchemaProvider.invisible = armorStand.isInvisible();
                    schemaSchemaProvider.head = new float[]{(float) armorStand.getHeadPose().getX(), (float) armorStand.getHeadPose().getY(), (float) armorStand.getHeadPose().getZ()};
                    schemaSchemaProvider.body = new float[]{(float) armorStand.getBodyPose().getX(), (float) armorStand.getBodyPose().getY(), (float) armorStand.getBodyPose().getZ()};
                    schemaSchemaProvider.leftArm = new float[]{(float) armorStand.getLeftArmPose().getX(), (float) armorStand.getLeftArmPose().getY(), (float) armorStand.getLeftArmPose().getZ()};
                    schemaSchemaProvider.rightArm = new float[]{(float) armorStand.getRightArmPose().getX(), (float) armorStand.getRightArmPose().getY(), (float) armorStand.getRightArmPose().getZ()};
                    schemaSchemaProvider.leftLeg = new float[]{(float) armorStand.getLeftLegPose().getX(), (float) armorStand.getLeftLegPose().getY(), (float) armorStand.getLeftLegPose().getZ()};
                    schemaSchemaProvider.rightLeg = new float[]{(float) armorStand.getRightLegPose().getX(), (float) armorStand.getRightLegPose().getY(), (float) armorStand.getRightLegPose().getZ()};
                    schemaSchemaProvider.equipment = toNames(armorStand.getEquipment().getIS());
                    schemas.add(schemaSchemaProvider);
                }
            }
        }
        return schemas;
    }

    @Nonnull
    private String[] toNames(@Nonnull ItemStack[] itemStacks) {
        String[] names = new String[itemStacks.length];
        for (int i = 0; i < itemStacks.length; i++) {
            ItemStack itemStack = itemStacks[i];
            names[i] = itemStack == null ? null : itemStack.getType().name();
        }
        return names;
    }
}

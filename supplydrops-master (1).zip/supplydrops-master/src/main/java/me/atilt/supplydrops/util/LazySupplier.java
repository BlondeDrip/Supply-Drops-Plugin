package me.atilt.supplydrops.util;

import java.util.function.Supplier;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/LazySupplier.class */
public interface LazySupplier<T> extends Supplier<T>, AutoCloseable {
    Supplier<T> handle();
}

package me.atilt.supplydrops.api.model.entity.living;

import javax.annotation.Nonnull;
import me.atilt.supplydrops.api.model.entity.Entity;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/entity/living/LivingEntity.class */
public interface LivingEntity extends Entity {
    @Nonnull
    ItemStack[] getEquipment();

    void setEquipment(@Nonnull EquipmentSlot equipmentSlot, @Nonnull ItemStack itemStack);

    void setEquipment(@Nonnull ItemStack[] itemStackArr);

    boolean isInvisible();

    void setInvisible(boolean z);
}

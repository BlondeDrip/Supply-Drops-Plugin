package me.atilt.supplydrops.util;

import java.util.function.Predicate;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/DefaultLazyPredicate.class */
public class DefaultLazyPredicate<T> implements LazyPredicate<T> {
    private final Predicate<T> handle;
    private Boolean value;

    public DefaultLazyPredicate(@Nonnull Predicate<T> handle) {
        this.handle = handle;
    }

    @Override // java.lang.AutoCloseable
    public void close() {
    }

    @Override // java.util.function.Predicate
    public boolean test(T t) {
        if (this.value == null) {
            this.value = Boolean.valueOf(this.handle.test(t));
        }
        return this.value.booleanValue();
    }
}

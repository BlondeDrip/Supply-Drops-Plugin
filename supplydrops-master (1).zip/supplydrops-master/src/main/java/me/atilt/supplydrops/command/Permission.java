package me.atilt.supplydrops.command;

import javax.annotation.Nonnull;
import org.bukkit.command.CommandSender;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/command/Permission.class */
public enum Permission {
    COMMAND_ADMIN,
    SUPPLYDROP_OPEN,
    BUILD_BYPASS;
    
    private static final String PREFIX = "supplydrops";
    private final String node = "supplydrops." + name().toLowerCase().replace('_', '.');

    Permission() {
    }

    @Nonnull
    public String node() {
        return this.node;
    }

    public boolean has(@Nonnull CommandSender commandSender) {
        return commandSender.isOp() || commandSender.hasPermission(this.node);
    }
}

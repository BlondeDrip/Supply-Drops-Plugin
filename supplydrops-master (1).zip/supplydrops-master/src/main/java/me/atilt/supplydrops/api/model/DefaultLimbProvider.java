package me.atilt.supplydrops.api.model;

import me.atilt.supplydrops.api.model.entity.Entity;
import me.atilt.supplydrops.api.model.limb.Limb;
import me.atilt.supplydrops.api.model.limb.type.entity.ModelLimb;
import me.atilt.supplydrops.api.model.render.EntityRenderer;
import org.bukkit.entity.Player;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/DefaultLimbProvider.class */
public class DefaultLimbProvider implements LimbProvider {
    @Override // java.util.function.BiFunction
    public Limb apply(EntityRenderer<?> entityRenderer, Schema<? extends Entity> schema) {
        return new ModelLimb(entityRenderer, schema, new Interaction<Player, Object>() { // from class: me.atilt.supplydrops.api.model.DefaultLimbProvider.1
            @Override // java.util.function.BiConsumer
            public void accept(Player player, Object o) {
            }

            @Override // java.util.function.BiFunction
            public Boolean apply(Player player, Object o) {
                return null;
            }
        });
    }
}

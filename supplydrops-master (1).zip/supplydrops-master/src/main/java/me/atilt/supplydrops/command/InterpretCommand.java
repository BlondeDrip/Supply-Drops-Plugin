package me.atilt.supplydrops.command;

import de.Ste3et_C0st.FurnitureLib.ModelLoader.ModelVector;
import de.Ste3et_C0st.FurnitureLib.NBT.NBTCompressedStreamTools;
import de.Ste3et_C0st.FurnitureLib.NBT.NBTTagCompound;
import de.Ste3et_C0st.FurnitureLib.main.FurnitureManager;
import de.Ste3et_C0st.FurnitureLib.main.ObjectID;
import de.Ste3et_C0st.FurnitureLib.main.entity.fEntity;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.*;

import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.ArmorStandMockData;
import me.atilt.supplydrops.api.model.FurnitureLibInterpreter;
import me.atilt.supplydrops.api.model.io.CompressionType;
import me.atilt.supplydrops.api.model.io.ConcurrentFileAccessor;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import it.unimi.dsi.fastutil.io.FastBufferedOutputStream;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/command/InterpretCommand.class */
public class InterpretCommand implements CommandExecutor {
    private final SupplyDropsPlugin plugin;

    public InterpretCommand(SupplyDropsPlugin plugin) {
        this.plugin = plugin;
    }

    private Optional<byte[]> decodeBase64toByte(String md5) {
        try {
            return Optional.of(Base64.getDecoder().decode(md5));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }

    public String ok(Optional<byte[]> data) {
        try {
            ByteArrayInputStream bin = new ByteArrayInputStream(data.get());
            NBTTagCompound entityData = NBTCompressedStreamTools.read(bin);
            ModelVector vector = new ModelVector(entityData.getCompound("Location"));
            fEntity entity = readNBTtag(entityData);
            if (Objects.nonNull(vector) && Objects.nonNull(entity)) {
                String nBTTagCompound = entityData.toString();
                bin.close();
                return nBTTagCompound;
            }
            bin.close();
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public fEntity readNBTtag(NBTTagCompound compound) {
        fEntity entity = FurnitureManager.getInstance().readEntity((compound.hasKey("EntityType") ? compound.getString("EntityType") : "armor_stand").toLowerCase(), (Location) null, (ObjectID) null);
        entity.loadMetadata(compound);
        return entity;
    }

    private String[] toNames(ItemStack[] itemStacks) {
        String[] names = new String[itemStacks.length];
        for (int i = 0; i < itemStacks.length; i++) {
            ItemStack itemStack = itemStacks[i];
            names[i] = itemStack == null ? null : itemStack.getType().name();
        }
        return names;
    }

    public boolean onCommand(CommandSender commandSender, Command command, String label, String[] arguments) {
        Path resolve2 = this.plugin.getDataFolder().toPath().resolve("test2.txt");
        if (Files.notExists(resolve2, new LinkOption[0])) {
            try {
                Files.createFile(resolve2, new FileAttribute[0]);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        FurnitureLibInterpreter interpreter = new FurnitureLibInterpreter();
        List<SerializedState> projects = interpreter.interpret(List.of("fixedballoon"));
        ConcurrentFileAccessor<List<SerializedState>> fileAccessor = new ConcurrentFileAccessor<>(2);
        try {
            fileAccessor.newWrite().operation((outputStream, schemaProviders) -> {
                for (SerializedState armorStandData : schemaProviders) {
                    try {
                        ((ArmorStandMockData) armorStandData).marshal(outputStream, new byte[((ArmorStandMockData) armorStandData).marshalFit()]);
                    } catch (IOException e2) {
                        throw new RuntimeException(e2);
                    }
                }
            }).compressionType(CompressionType.NONE).apply(new FastBufferedOutputStream(new FileOutputStream(resolve2.toFile())), projects);
            return true;
        } catch (IOException e3) {
            throw new RuntimeException(e3);
        }
    }
}

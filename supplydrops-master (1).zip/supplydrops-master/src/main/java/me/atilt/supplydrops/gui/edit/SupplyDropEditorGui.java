package me.atilt.supplydrops.gui.edit;

import java.util.Arrays;
import java.util.List;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.gui.SupplyDropGui;
import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.Icon;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.Text;
import net.wesjd.anvilgui.AnvilGUI;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.ItemStack;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/edit/SupplyDropEditorGui.class */
public class SupplyDropEditorGui extends Gui {
    private final SupplyDrop supplyDrop;
    private final Integer model;
    private final SupplyDropsPlugin plugin;

    public SupplyDropEditorGui(@Nonnull Player player, @Nonnull SupplyDrop supplyDrop, @Nonnull Integer model, @Nonnull SupplyDropsPlugin plugin) {
        super(player, "supplydrops-editor-gui", "Editing " + Text.color(supplyDrop.meta().name()), 6);
        this.supplyDrop = supplyDrop;
        this.model = model;
        this.plugin = plugin;
    }

    @Override // mc.obliviate.inventory.Gui
    public void onOpen(InventoryOpenEvent event) {
        List<String> asList;
        fillRow(new Icon(Material.GRAY_STAINED_GLASS_PANE).setName(" "), 4);
        addItem(49, new Icon(Material.BARRIER).setName(Text.color("&cBack to selection")).onClick(clickEvent -> {
            new SupplyDropGui(this.player, this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        addItem(10, new Icon(Material.COMPASS).setName(Text.color("&aRange")).setLore(Text.color("&7Edit the range in which the"), Text.color("&7supply drop should spawn."), " ", Text.color("&eClick to edit!")).onClick(clickEvent2 -> {
            new RangeGui((Player) clickEvent2.getWhoClicked(), this.supplyDrop, this.model, this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        addItem(12, new Icon(Material.HOPPER).setName(Text.color("&aLocation Filters")).setLore(Text.color("&7Edit the filters for the"), Text.color("&7spawn location of the supply drop."), " ", Text.color("&eClick to edit!")).onClick(clickEvent3 -> {
            new LocationFilterGui((Player) clickEvent3.getWhoClicked(), this.supplyDrop, this.model, this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        Icon name = new Icon(Material.CHEST).setName(Text.color("&aLoot Table"));
        if (!this.supplyDrop.lootTable().empty()) {
            asList = Arrays.asList(Text.color("&7Edit the loot table for"), Text.color("&7the supply drop."), " ", Text.color("&eClick to edit!"));
        } else {
            asList = Arrays.asList(Text.color("&7Edit the loot table for"), Text.color("&7the supply drop."), " ", Text.color("&c&lWARNING: &eMissing configuration!"), " ", Text.color("&eClick to edit!"));
        }
        addItem(14, name.setLore(asList).onClick(clickEvent4 -> {
            new LootTableGui(clickEvent4.getWhoClicked(), this.supplyDrop, this.model, this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        addItem(20, new Icon(Material.EXPERIENCE_BOTTLE).setName(Text.color("&aProbability")).setLore(Text.color("&7Edit the probability for the supply drop"), Text.color("&7to spawn in the world."), " ", Text.color("&eClick to edit!")).onClick(clickEvent5 -> {
            new ProbabilityGui((Player) clickEvent5.getWhoClicked(), this.supplyDrop, this.model, this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        addItem(22, new Icon(Material.PAPER).setName(Text.color("&aRename")).setLore(Text.color("&7Edit the name of the supply drop."), Text.color("&7This is the name that will be"), Text.color("&7displayed in messages & announcements."), " ", Text.color("&eClick to edit!")).onClick(clickEvent6 -> {
            new AnvilGUI.Builder().onClose(player -> Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                new SupplyDropEditorGui(this.player, this.supplyDrop, this.model, this.plugin).open();
                player.getPlayer().playSound(player.getPlayer().getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
            }, 2L)).onClick((click,completion) -> {
                for (SupplyDrop all : this.plugin.supplyDropRegistry().all().values()) {
                    if (all.meta().name().equals(Text.color(completion.getText()))) {
                        this.player.playSound(this.player.getLocation(), Sound.ENTITY_ENDER_PEARL_THROW, 0.4f, 2.0f);
                        return List.of(AnvilGUI.ResponseAction.replaceInputText(Text.color("&cThat name is already taken.")));
                    }
                }
                this.player.playSound(this.player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 2.0f, 1.7f);
                this.supplyDrop.meta().name(Text.color(completion.getText()));
                return List.of(AnvilGUI.ResponseAction.close());
            }).text(this.supplyDrop.meta().name()).itemLeft(new ItemStack(Material.PAPER)).title(Text.color("Editing &lname&r for " + this.supplyDrop.meta().name())).plugin(this.plugin).open((Player) clickEvent6.getWhoClicked());
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        addItem(24, new Icon(Material.ORANGE_DYE).setName(Text.color("&aColor")).setLore(Text.color("&7Edit the display model"), Text.color("&7for the supply drop."), " ", Text.color("&eClick to edit!")).onClick(clickEvent7 -> {
            new ColorGui((Player) clickEvent7.getWhoClicked(), this.supplyDrop, this.model, this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        addItem(16, new Icon(Material.TNT).setName(Text.color("&cDelete")).setLore(Text.color("&7Deletes the supply drop including data for range,"), Text.color("&7filters, loot table, & occurrences."), " ", Text.color("&c&lWARNING: &eThis cannot be undone!"), " ", Text.color("&eShift + Left-Click&a to delete.")).onClick(clickEvent8 -> {
            if (clickEvent8.isLeftClick() && clickEvent8.isShiftClick()) {
                SupplyDrop unregister = this.plugin.supplyDropRegistry().unregister(this.supplyDrop.id());
                this.supplyDrop.setCanSpawn(false);
                if (unregister != null) {
                    this.player.playSound(this.player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.07f, 1.09f);
                    unregister.close();
                    if (unregister.modelData() == null || unregister.modelData().empty()) {
                        return;
                    }
                    AudiencedModel internal = unregister.model();
                    if (internal != null) {
                        internal.unrender();
                    }
                    SupplyDropsPlugin.self().getTicker().unTickSupplyDrop(this.supplyDrop, 3911111);
                    this.plugin.getModelRegistry().unregister(unregister.modelData().getId());
                }
                new SupplyDropGui((Player) clickEvent8.getWhoClicked(), this.plugin).open();
                this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
            }
        }));
    }
}

package me.atilt.supplydrops.util;

import java.awt.Color;
import java.util.List;
import java.util.function.Function;
import javax.annotation.Nonnull;
import net.md_5.bungee.api.ChatColor;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/util/Text.class */
public final class Text {
    private static final char[] VALID_CODES = "0123456789AaBbCcDdEeFfKkLlMmNnOoRr".toCharArray();
    private static long VALID_MASK = 0;

    private Text() {
        throw new UnsupportedOperationException("This class cannot be instantiated");
    }

    static {
        char[] cArr;
        for (char c : VALID_CODES) {
            VALID_MASK |= 1 << Character.toLowerCase(c);
        }
    }

    public static String color(char altColorChar, String text) {
        if (text == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder(text.length());
        int len = text.length();
        int i = 0;
        while (i < len) {
            char c = text.charAt(i);
            if (c == altColorChar && (VALID_MASK & (1 << text.charAt(i + 1))) != 0) {
                sb.append((char) 167);
                sb.append(text.charAt(i + 1));
                i++;
            } else {
                sb.append(c);
            }
            i++;
        }
        return sb.toString();
    }

    public static String color(String text) {
        return color('&', text);
    }

    public static String color(Color color, String text) {
        return ChatColor.of(color).toString() + text;
    }

    public static String color(String text, Function<String, String> transformer) {
        return color('&', transformer.apply(text));
    }

    public static List<String> color(@Nonnull List<String> text, Function<String, String> transformer) {
        return Collections.transform(text, s -> {
            return color((String) transformer.apply(s));
        });
    }

    public static List<String> color(@Nonnull List<String> text) {
        return Collections.transform(text, Text::color);
    }

    public static String stripFlat(@Nonnull String text) {
        StringBuilder outputBuilder = new StringBuilder(text.length());
        boolean colorCode = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (colorCode) {
                colorCode = false;
            } else if (c == '&' || c == 167) {
                colorCode = true;
            } else {
                outputBuilder.append(c);
            }
        }
        return outputBuilder.toString().trim();
    }

    @Nonnull
    public static String replace(@Nonnull String text, @Nonnull String search, @Nonnull String replacement) {
        int indexOf;
        if (text.isEmpty() || search.isEmpty()) {
            return text;
        }
        int start = 0;
        int end = text.indexOf(search, 0);
        if (end == -1) {
            return text;
        }
        int replLength = search.length();
        int increase = Math.max(replacement.length() - replLength, 0);
        StringBuilder buf = new StringBuilder(text.length() + increase);
        do {
            buf.append((CharSequence) text, start, end).append(replacement);
            start = end + replLength;
            indexOf = text.indexOf(search, start);
            end = indexOf;
        } while (indexOf != -1);
        buf.append((CharSequence) text, start, text.length());
        return buf.toString();
    }
}

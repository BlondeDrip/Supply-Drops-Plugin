package me.atilt.supplydrops.gui;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import javax.annotation.Nonnull;

import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.pagination.PaginationManager;
import me.atilt.supplydrops.ColorData;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.distributor.DefaultDistributionParameters;
import me.atilt.supplydrops.distributor.SupplyDropDistributor;
import me.atilt.supplydrops.distributor.location.SuitableLocation;
import me.atilt.supplydrops.gui.edit.OccurrenceGui;
import me.atilt.supplydrops.gui.edit.SupplyDropEditorGui;
//import mc.obliviate.inventory.Gui;
import mc.obliviate.inventory.Icon;
import me.atilt.supplydrops.library.paper.lib.PaperLib;
import me.atilt.supplydrops.loot.DefaultLootTable;
import me.atilt.supplydrops.loot.probability.StaticProbability;
import me.atilt.supplydrops.registry.SupplyDropRegistry;
import me.atilt.supplydrops.supplydrop.DefaultSupplyDrop;
import me.atilt.supplydrops.supplydrop.ModelData;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.supplydrop.SupplyDropMeta;
import me.atilt.supplydrops.util.Durations;
import me.atilt.supplydrops.util.ItemStackBuilder;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/gui/SupplyDropGui.class */
public class SupplyDropGui extends Gui {
    private final SupplyDropsPlugin plugin;
    private final PaginationManager pagination;
    private BukkitTask task;
    private boolean teleporting;
    public static final Icon PLACEHOLDER = new Icon(Material.GRAY_STAINED_GLASS_PANE).setName(" ");
    private static final DateTimeFormatter DATE_FORMATTER = new DateTimeFormatterBuilder().append(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)).appendLiteral(" @ ").append(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(Locale.US)).toFormatter().withZone(ZoneId.systemDefault());

    public SupplyDropGui(@Nonnull Player player, @Nonnull SupplyDropsPlugin plugin) {
        super(player, "supplydrops-gui", "SupplyDrops (v" + plugin.getDescription().getVersion() + ")", 6);
        this.pagination = new PaginationManager(this);
        this.teleporting = false;
        this.plugin = plugin;
        this.pagination.registerPageSlotsBetween(0, 35);
    }

    @Override // mc.obliviate.inventory.Gui
    public void onOpen(InventoryOpenEvent event) {
        fillRow(PLACEHOLDER, 4);
        addItem(49, new Icon(Material.BARRIER).setName(Text.color("&cClose")).onClick(clickEvent -> {
            clickEvent.getWhoClicked().closeInventory();
            this.player.playSound(this.player.getLocation(), Sound.UI_TOAST_OUT, 0.3f, 1.8f);
        }));
        this.task = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            Icon name = new Icon(Material.CLOCK).setName(Text.color("&aOccurrence"));
            String[] strArr = new String[6];
            strArr[0] = Text.color("&7Edit how often supply drops");
            strArr[1] = Text.color("&7should spawn in the world.");
            strArr[2] = " ";
            strArr[3] = Text.color("&aNext spawn in: &e" + (this.plugin.supplyDropRegistry().size() == 0 ? "&cNo applicable supply drops" : this.plugin.getTicker().getOccurrence().next() == null ? "n/a" : Durations.format(this.plugin.getTicker().getOccurrence().until().toMillis())));
            strArr[4] = " ";
            strArr[5] = Text.color("&eClick to edit!");
            addItem(45, name.setLore(strArr).onClick(clickEvent2 -> {
                new OccurrenceGui((Player) clickEvent2.getWhoClicked(), this.plugin).open();
                this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
            }));
            build();
        }, 0L, 5L);
        addItem(53, new Icon(Material.CRAFTING_TABLE).hideFlags(ItemStackBuilder.flags()).setName(Text.color("&aCreate")).setLore(Text.color("&7Click to create a new"), Text.color("&7supply drop.")).onClick(clickEvent2 -> {
            int id = SupplyDropRegistry.nextId();
            DefaultSupplyDrop created = new DefaultSupplyDrop(id, new SupplyDropMeta("New Supply Drop " + ThreadLocalRandom.current().nextInt(1, 801), Instant.now()), new DefaultLootTable(Collections.emptyList()), new SupplyDropDistributor(DefaultDistributionParameters.newBuilder().suitableLocations(new ArrayList(SuitableLocation.ALL)).range(new Location(clickEvent2.getWhoClicked().getWorld(), 0.0d, 0.0d, 0.0d), new Location(clickEvent2.getWhoClicked().getWorld(), 0.0d, 0.0d, 0.0d)).build()), new StaticProbability(BigDecimal.valueOf(1.0d)), 1, this.plugin.getModelRegistry().get(1).duplicate(), ColorData.defaultDisplay(), null);
            this.plugin.supplyDropRegistry().register(id, (SupplyDrop) created);
            SupplyDropsPlugin.self().getTicker().tickSupplyDrop(created);
            new SupplyDropEditorGui((Player) clickEvent2.getWhoClicked(), created, Integer.valueOf(id), this.plugin).open();
            this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
        }));
        build();
    }

    @Override // mc.obliviate.inventory.Gui
    public void onClose(InventoryCloseEvent event) {
        if (this.task != null) {
            this.task.cancel();
        }
    }

    private void build() {
        this.pagination.getItems().clear();
        ArrayList<SupplyDrop> supplyDrops = new ArrayList<>(this.plugin.supplyDropRegistry().all().values());
        Collections.sort(supplyDrops, (o1, o2 )-> {
            if (o1.getPlayerOwned() == null && o2.getPlayerOwned() == null) {
                return 0;
            }
            return (o1.getPlayerOwned() != null || o2.getPlayerOwned() == null) ? -1 : 1;
        });
        Iterator<SupplyDrop> it = supplyDrops.iterator();
        while (it.hasNext()) {
            SupplyDrop supplyDrop = it.next();
            this.pagination.addItem(new Icon(itemize(supplyDrop)).onClick(clickEvent -> {
                if (clickEvent.isRightClick()) {
                    if (this.teleporting) {
                        return;
                    }
                    if (!supplyDrop.modelData().empty() && supplyDrop.model().rendered() && supplyDrop.model().getLocation() != null) {
                        this.teleporting = true;
                        Location location = supplyDrop.model().getLocation();
                        PaperLib.teleportAsync(clickEvent.getWhoClicked(), location.clone().add(location.getDirection().multiply(-1)), PlayerTeleportEvent.TeleportCause.PLUGIN).thenAccept(aBoolean -> {
                            this.teleporting = false;
                        });
                        Player whoClicked = (Player) clickEvent.getWhoClicked();
                        whoClicked.playSound(whoClicked.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.03f, 1.44f);
                        return;
                    }
                }
                if (supplyDrop.getPlayerOwned() != null) {
                    if (clickEvent.isLeftClick() && clickEvent.isShiftClick()) {
                        SupplyDrop unregister = this.plugin.supplyDropRegistry().unregister(supplyDrop.id());
                        supplyDrop.setCanSpawn(false);
                        if (unregister != null) {
                            this.player.playSound(this.player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.07f, 1.09f);
                            unregister.close();
                            if (unregister.modelData() == null || unregister.modelData().empty()) {
                                return;
                            }
                            AudiencedModel internal = unregister.model();
                            if (internal != null) {
                                internal.unrender();
                            }
                            this.plugin.getModelRegistry().unregister(unregister.modelData().getId());
                            SupplyDropsPlugin.self().getTicker().unTickSupplyDrop(supplyDrop, 3847833);
                        }
                    }
                    build();
                    return;
                }
                Integer modelId = (Integer) this.plugin.getModelRegistry().all().entrySet().stream().filter(dataEntry -> {
                    ModelData modelData = (ModelData) dataEntry.getValue();
                    return (modelData.empty() || supplyDrop.modelData().empty() || !modelData.getHandle().get().equals(supplyDrop.model())) ? false : true;
                }).map((v0) -> {
                    return v0.getKey();
                }).findAny().orElse(null);
                new SupplyDropEditorGui((Player) clickEvent.getWhoClicked(), supplyDrop, modelId, this.plugin).open();
                this.player.playSound(this.player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.2f, 0.9f);
            }));
        }
        updateNavigation();
    }

    private void updateNavigation() {
        this.pagination.update();
        if (this.pagination.getItems().size() > 36) {
            addItem(48, new Icon(Material.ARROW).setName(Text.color("&aPrevious Page")).setLore(Text.color("&7Current Page: &a" + (this.pagination.getCurrentPage() + 1))).onClick(clickEvent -> {
                this.pagination.goPreviousPage();
                updateNavigation();
            }));
            addItem(50, new Icon(Material.ARROW).setName(Text.color("&aNext Page")).setLore(Text.color("&7Current Page: &a" + (this.pagination.getCurrentPage() + 1))).onClick(clickEvent2 -> {
                this.pagination.goNextPage();
                updateNavigation();
                this.player.playSound(this.player.getLocation(), Sound.BLOCK_MOSS_CARPET_HIT, 0.6f, 0.0f);
            }));
            return;
        }
        addItem(48, (Icon) null);
        addItem(50, (Icon) null);
    }

    private ItemStack itemize(@Nonnull SupplyDrop supplyDrop) {
        List<String> lore = new ArrayList<>(4);
        if (supplyDrop.getPlayerOwned() != null) {
            lore.add(Text.color("&aSpawned by: &e" + (supplyDrop.getPlayerOwned().isConsoleOwned() ? "Server" : Bukkit.getOfflinePlayer(supplyDrop.getPlayerOwned().getId()).getName())));
            lore.add(Text.color("&aSpawned for: &e" + Bukkit.getOfflinePlayer(supplyDrop.getPlayerOwned().getForId()).getName()));
            lore.add(" ");
            lore.add(Text.color("&aSpawned: &e" + (supplyDrop.lastSpawn() == null ? "not spawned" : Durations.format(supplyDrop.lastSpawn().sinceLast().toMillis()) + " ago")));
            lore.add(Text.color("&aDespawns in: &e" + (supplyDrop.landingData() == null ? supplyDrop.lastSpawn() == null ? "not spawned" : "not landed" : Durations.format(supplyDrop.landingData().remaining().toMillis()))));
            lore.add(" ");
            if (!supplyDrop.modelData().empty() && supplyDrop.model().rendered() && supplyDrop.model().getLocation() != null) {
                lore.add(Text.color("&eRight-Click to teleport!"));
                lore.add(" ");
            }
            lore.add(Text.color("&eShift + Left-Click to delete!"));
        } else {
            lore.add(Text.color("&aCreated: &e" + DATE_FORMATTER.format(supplyDrop.meta().created())));
            lore.add(" ");
            lore.add(Text.color("&aSpawned: &e" + (supplyDrop.lastSpawn() == null ? "not spawned" : Durations.format(supplyDrop.lastSpawn().sinceLast().toMillis()) + " ago")));
            lore.add(Text.color("&aDespawns in: &e" + (supplyDrop.landingData() == null ? supplyDrop.lastSpawn() == null ? "not spawned" : "not landed" : Durations.format(supplyDrop.landingData().remaining().toMillis()))));
            lore.add(" ");
            if (!supplyDrop.modelData().empty() && supplyDrop.model().rendered() && supplyDrop.model().getLocation() != null) {
                lore.add(Text.color("&eRight-Click to teleport!"));
                lore.add(" ");
            }
            lore.add(Text.color("&eClick to edit!"));
            if (supplyDrop.lootTable().empty()) {
                lore.set(2, " ");
                lore.add(3, Text.color("&c&lWARNING: &eMissing loot table configuration!"));
            }
        }
        return ItemStackBuilder.of(supplyDrop.lootTable().empty() ? Material.MINECART : supplyDrop.getPlayerOwned() != null ? Material.ENDER_CHEST : Material.CHEST).amount(1).allFlags().name(Text.color("&b" + supplyDrop.meta().name())).lore(lore).build();
    }
}

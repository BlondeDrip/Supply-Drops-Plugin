package me.atilt.supplydrops.supplydrop;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.api.model.Model;
import me.atilt.supplydrops.api.model.schema.SerializedState;
import me.atilt.supplydrops.model.registry.ModelRegistry;
import me.atilt.supplydrops.util.DefaultLazySupplier;
import me.atilt.supplydrops.util.LazySupplier;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/supplydrop/ModelData.class */
public final class ModelData implements ConfigurationSerializable {
    private final String fileName;
    private int id;
    private LazySupplier<AudiencedModel> handle;
    private List<SerializedState> states = new ArrayList();
    private static final ModelData EMPTY = new ModelData("nomodeldata.nonexistent");

    public ModelData(String fileName) {
        this.fileName = fileName;
    }

    public static ModelData ofEmpty() {
        return EMPTY;
    }

    public boolean empty() {
        return this == EMPTY;
    }

    public String getFileName() {
        return this.fileName;
    }

    public LazySupplier<AudiencedModel> getHandle() {
        return this.handle;
    }

    public void supply(@Nonnull Supplier<AudiencedModel> provider) {
        this.handle = new DefaultLazySupplier(provider);
    }

    public void storeStates(@Nonnull Collection<SerializedState> states) {
        this.states.clear();
        this.states.addAll(states);
    }

    public List<SerializedState> getStates() {
        return new ArrayList(this.states);
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }

    public ModelData duplicate() {
        int id = ModelRegistry.nextId();
        ModelData modelData = new ModelData(this.fileName);
        modelData.storeStates(getStates());
        modelData.setId(id);
        modelData.supply(() -> {
            Model model = SupplyDropsPlugin.self().getFactory().manufactureInt(1, getStates());
            return (AudiencedModel) model;
        });
        SupplyDropsPlugin.self().getModelRegistry().register(id, modelData);
        return modelData;
    }

    @Nonnull
    public Map<String, Object> serialize() {
        return Collections.singletonMap("fileName", this.fileName);
    }

    public static ModelData deserialize(@Nonnull Map<String, Object> tree) {
        return new ModelData((String) tree.get("fileName"));
    }
}

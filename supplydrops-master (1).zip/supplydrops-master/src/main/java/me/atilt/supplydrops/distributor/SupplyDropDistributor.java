package me.atilt.supplydrops.distributor;

import java.text.DecimalFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.LocationAttempt;
import me.atilt.supplydrops.SupplyDropsPlugin;
import me.atilt.supplydrops.api.model.AudiencedModel;
import me.atilt.supplydrops.api.model.Model;
import me.atilt.supplydrops.distributor.location.SuitableLocation;
import me.atilt.supplydrops.library.paper.lib.PaperLib;
import me.atilt.supplydrops.supplydrop.LandingData;
import me.atilt.supplydrops.supplydrop.LastSpawn;
import me.atilt.supplydrops.supplydrop.SupplyDrop;
import me.atilt.supplydrops.util.Cuboid;
import me.atilt.supplydrops.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/distributor/SupplyDropDistributor.class */
public final class SupplyDropDistributor implements Distributor<SupplyDrop> {
    private static final DecimalFormat COORDINATE_FORMATTER = new DecimalFormat("#,###");
    private DistributionParameters parameters;
    private Coordinate2D lastLocation;

    @Override // me.atilt.supplydrops.distributor.Distributor
    public /* bridge */ /* synthetic */ void distribute(@Nonnull SupplyDrop supplyDrop, int i, Consumer consumer) {
        distribute2(supplyDrop, i, (Consumer<LocationAttempt>) consumer);
    }

    public SupplyDropDistributor(@Nonnull DistributionParameters parameters) {
        this.parameters = parameters;
    }

    private boolean isLast(World world, int x, int z) {
        return this.lastLocation.getWorld().equals(world) && this.lastLocation.distance(x, z) <= 256.0d;
    }

    public void setLastLocation(Location lastLocation) {
        this.lastLocation = new Coordinate2D(lastLocation.getWorld(), lastLocation.getBlockX(), lastLocation.getBlockZ());
    }

    @Override // me.atilt.supplydrops.distributor.Distributor
    @Nonnull
    public DistributionParameters parameters() {
        return this.parameters;
    }

    @Override // me.atilt.supplydrops.distributor.Distributor
    public void parameters(@Nonnull DistributionParameters parameters) {
        this.parameters = parameters;
    }

    /* renamed from: distribute  reason: avoid collision after fix types in other method */
    public void distribute2(@Nonnull SupplyDrop supplyDrop, int attempts, Consumer<LocationAttempt> callback) {
        World world = Bukkit.getWorld(this.parameters.cuboid().getWorld());
        if (world == null) {
            throw new IllegalStateException("unavailable world");
        }
        if (world.getEnvironment() == World.Environment.NETHER) {
            SupplyDropsPlugin.self().getLogger().warning("Nether world required for: " + supplyDrop.meta().name() + ", but not currently supported.");
            return;
        }
        boolean playerOwned = supplyDrop.getPlayerOwned() != null;
        Cuboid cuboid = this.parameters.cuboid();
        int randomX = playerOwned ? cuboid.getMinBlockX() : cuboid.randomX() + ThreadLocalRandom.current().nextInt(-100, 101);
        int randomZ = playerOwned ? cuboid.getMinBlockZ() : cuboid.randomZ() + ThreadLocalRandom.current().nextInt(-100, 101);
        if (supplyDrop.modelData().empty() || supplyDrop.lootTable().empty()) {
            return;
        }
        AudiencedModel audiencedModel = supplyDrop.modelData().getHandle().get();
        if (audiencedModel.rendered()) {
            audiencedModel.unrender();
        }
        if (this.lastLocation != null && isLast(world, randomX, randomZ)) {
            callback.accept(new LocationAttempt(false, attempts + 1));
            return;
        }
        CompletableFuture<Chunk> asyncChunk = PaperLib.getChunkAtAsyncUrgently(world, randomX >> 4, randomZ >> 4, true);
        asyncChunk.thenAccept(genChunk -> {
            Block found = world.getHighestBlockAt(randomX, randomZ, HeightMap.WORLD_SURFACE);
            setLastLocation(found.getLocation());
            List<SuitableLocation> suitableLocations = this.parameters.suitableLocations();
            for (SuitableLocation suitableLocation : suitableLocations) {
                if (!suitableLocation.test(found)) {
                    callback.accept(new LocationAttempt(false, attempts + 1));
                    return;
                }
            }
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    for (int y = 1; y <= 2; y++) {
                        Block relative = found.getRelative(x, y, z);
                        for (SuitableLocation suitableLocation2 : suitableLocations) {
                            if (!suitableLocation2.test(relative)) {
                                callback.accept(new LocationAttempt(false, attempts + 1));
                                return;
                            }
                        }
                    }
                }
            }
            Material type = found.getType();
            while (true) {
                Material type2 = type;
                if (found.isLiquid() || type2.isSolid()) {
                    break;
                }
                found = found.getRelative(0, -1, 0);
                type = found.getType();
            }
            if (supplyDrop.interaction().isPopulated()) {
                supplyDrop.interaction().clear();
            }
            if (!supplyDrop.canSpawn()) {
                return;
            }
            world.addPluginChunkTicket(randomX >> 4, randomZ >> 4, SupplyDropsPlugin.self());
            if (!playerOwned) {
                Block finalFound = found;
                Bukkit.broadcastMessage(Text.color(SupplyDropsPlugin.self().configMessages().getString("supply-drop.spawned.global", s -> {
                    return s.replace("%name%", Text.color(supplyDrop.meta().name())).replace("%x%", COORDINATE_FORMATTER.format(finalFound.getLocation().getBlockX() + SupplyDropsPlugin.self().getConfig().getInt("supply-drops.offset-display-coordinates.x"))).replace("%y%", COORDINATE_FORMATTER.format(finalFound.getLocation().getBlockY() + SupplyDropsPlugin.self().getConfig().getInt("supply-drops.offset-display-coordinates.y"))).replace("%z%", COORDINATE_FORMATTER.format(finalFound.getLocation().getBlockZ() + SupplyDropsPlugin.self().getConfig().getInt("supply-drops.offset-display-coordinates.z"))).replace("%world%", finalFound.getWorld().getName());
                })));
            } else {
                Block finalFound2 = found;
                Bukkit.broadcastMessage(Text.color(SupplyDropsPlugin.self().configMessages().getString("supply-drop.spawned.player", s2 -> {
                    return s2.replace("%name%", Text.color(supplyDrop.meta().name())).replace("%player%", Bukkit.getOfflinePlayer(supplyDrop.getPlayerOwned().getForId()).getName()).replace("%x%", COORDINATE_FORMATTER.format(finalFound2.getLocation().getBlockX())).replace("%y%", COORDINATE_FORMATTER.format(finalFound2.getLocation().getBlockY())).replace("%z%", COORDINATE_FORMATTER.format(finalFound2.getLocation().getBlockZ())).replace("%world%", finalFound2.getWorld().getName());
                })));
            }
            Bukkit.getOnlinePlayers().forEach(player -> {
                player.playSound(player.getLocation(), Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS_ULTRA_RARE, 2.0f, 2.0f);
            });
            Location landing = found.getLocation().add(0.5d, 0.9d, 0.5d);
            Location origin = found.getLocation().add(ThreadLocalRandom.current().nextDouble(-9.0d, 9.0d), ThreadLocalRandom.current().nextDouble(50.0d, 61.0d), ThreadLocalRandom.current().nextDouble(-9.0d, 9.0d));
            AudiencedModel model = supplyDrop.model();
            model.render(origin);
            supplyDrop.updateColor();
            supplyDrop.lastSpawn(new LastSpawn(Instant.now()));
            Bukkit.getScheduler().runTaskLater(SupplyDropsPlugin.self(), () -> {
                animateFall(model, landing.getChunk(), supplyDrop, landing);
            }, 3L);
            Bukkit.getScheduler().runTaskLater(SupplyDropsPlugin.self(), () -> {
                model.audience().addAll(Bukkit.getOnlinePlayers());
            }, 40L);
            callback.accept(new LocationAttempt(true, attempts + 1));
            SupplyDropsPlugin.self().getTicker().tickSupplyDrop(supplyDrop);
        });
    }

    /* JADX WARN: Type inference failed for: r0v12, types: [me.atilt.supplydrops.distributor.SupplyDropDistributor$1] */
    public void animateFall(final Model model, Chunk chunk, final SupplyDrop supplyDrop, final Location targetLocation) {
        final boolean[] pushed = {false, false};
        final double[] pushedAmount = {0.0d};
        final double[] time = {1.0d, 0.0d};
        final double[] increment = {0.1125d};
        final LandingData landingData = new LandingData(Duration.ofMillis(SupplyDropsPlugin.self().getConfig().getLong("supply-drops.expire-time")));
        landingData.setChunk(chunk);
        model.rotate(targetLocation);
        new BukkitRunnable() { // from class: me.atilt.supplydrops.distributor.SupplyDropDistributor.1
            public void run() {
                double r13 = 10.0; //not sure of that

                if (supplyDrop.modelData().empty()) {
                    cancel();
                    for (Chunk chunk2 : landingData.getChunk()) {
                        chunk2.removePluginChunkTicket(SupplyDropsPlugin.self());
                    }
                    supplyDrop.close();
                } else if (model.getLocation() == null) {
                    cancel();
                    for (Chunk chunk3 : landingData.getChunk()) {
                        chunk3.removePluginChunkTicket(SupplyDropsPlugin.self());
                    }
                    model.unrender();
                    supplyDrop.close();
                    SupplyDropsPlugin.self().getTicker().unTickSupplyDrop(supplyDrop, 400500);
                } else {
                    Location from = model.getLocation().clone();
                    Location to = targetLocation.clone();
                    double distance = from.distanceSquared(to);
                    if (distance <= 37.209999999999994d) {
                        double[] dArr = time;
                        dArr[0] = dArr[0] * 1.01d;
                    }
                    if (distance <= 0.0225d) {
                        cancel();
                        from.getWorld().spawnParticle(Particle.EXPLOSION_NORMAL, from.clone().add(0.0d, 0.1d, 0.0d), 20, 1.24d, 0.1d, 1.24d, 0.0d);
                        from.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, from.clone().add(0.0d, 0.1d, 0.0d), 65, 0.8d, 0.1d, 0.8d, 0.01d);
                        from.getWorld().playSound(from, Sound.BLOCK_TUFF_PLACE, 2.0f, 1.0f);
                        from.getWorld().playSound(from, Sound.BLOCK_TUFF_BREAK, 2.0f, 1.0f);
                        landingData.setChunk(targetLocation.getChunk());
                        landingData.start();
                        supplyDrop.setLandingData(landingData);
                        return;
                    }
                    Vector direction = to.toVector().subtract(from.toVector()).multiply(ThreadLocalRandom.current().nextDouble(1.7E-5d, 2.1E-5d) * time[0]);
                    if (pushed[0]) {
                        if (pushedAmount[0] >= r13) {
                            pushed[0] = false;
                            pushed[1] = true;
                            pushedAmount[0] = 0.0d;
                        } else {
                            float degree = ((float) increment[0]) * ThreadLocalRandom.current().nextFloat(0.0f, 10.0f) * ThreadLocalRandom.current().nextFloat(0.3f, 1.2f);
                            model.rotate(degree);
                            double[] dArr2 = pushedAmount;
                            dArr2[0] = dArr2[0] + Math.abs(degree);
                        }
                    }
                    if (pushed[1]) {
                        if (pushedAmount[0] >= r13) {
                            pushed[1] = false;
                            pushedAmount[0] = 0.0d;
                        } else {
                            float degree2 = (float) (increment[0] * (-1.0d) * ThreadLocalRandom.current().nextFloat(0.0f, 10.0f) * ThreadLocalRandom.current().nextFloat(0.3f, 1.2f));
                            model.rotate(degree2);
                            double[] dArr3 = pushedAmount;
                            dArr3[0] = dArr3[0] + Math.abs(degree2);
                        }
                    }
                    if (!pushed[0] && !pushed[1] && ThreadLocalRandom.current().nextInt(10) <= 2) {
                        pushed[0] = true;
                        increment[0] = ThreadLocalRandom.current().nextBoolean() ? increment[0] : increment[0] * (-1.0d);
                    }
                    model.move(direction.getX(), direction.getY(), direction.getZ(), model.getLocation().getYaw(), model.getLocation().getPitch());
                    if (time[1] % 80.0d == 0.0d) {
                        model.getLocation().getWorld().playSound(model.getLocation(), Sound.ENTITY_VILLAGER_WORK_ARMORER, 2.0f, ThreadLocalRandom.current().nextFloat(1.0f, 3.0f));
                    }
                    double[] dArr4 = time;
                    dArr4[0] = dArr4[0] + 0.0208d;
                    double[] dArr5 = time;
                    dArr5[1] = dArr5[1] + 1.0d;
                }
            }
        }.runTaskTimer(SupplyDropsPlugin.self(), 0L, 1L);
    }

    @Nonnull
    public Map<String, Object> serialize() {
        return Collections.singletonMap("parameters", this.parameters);
    }

    @Nonnull
    public static Distributor<SupplyDrop> deserialize(@Nonnull Map<String, Object> tree) {
        return new SupplyDropDistributor((DistributionParameters) tree.get("parameters"));
    }
}

package me.atilt.supplydrops.config;

import java.util.Map;
import javax.annotation.Nonnull;
import org.bukkit.configuration.ConfigurationSection;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/config/Messages.class */
public interface Messages {
    @Nonnull
    String key();

    Map<String, Message> messages();

    void bind(@Nonnull ConfigurationSection configurationSection);
}

package me.atilt.supplydrops.api.model.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/io/CompressionType.class */
public enum CompressionType {
    NONE(""),
    GZIP(".gz"),
    ZIP(".zip");
    
    private final String extension;

    CompressionType(String extension) {
        this.extension = extension;
    }

    public InputStream getDecompressionStream(InputStream in) throws IOException {
        switch (this) {
            case NONE:
                return in;
            case GZIP:
                return new GZIPInputStream(in);
            case ZIP:
                return new ZipInputStream(in);
            default:
                throw new UnsupportedOperationException("Unsupported compression type: " + name());
        }
    }

    public OutputStream getCompressionStream(OutputStream out) throws IOException {
        switch (this) {
            case NONE:
                return out;
            case GZIP:
                return new GZIPOutputStream(out);
            case ZIP:
                return new ZipOutputStream(out);
            default:
                throw new UnsupportedOperationException("Unsupported compression type: " + name());
        }
    }

    public String getExtension() {
        return this.extension;
    }

    public static CompressionType detect(String path) {
        String extension = Path.of(path, new String[0]).getFileName().toString().toLowerCase();
        if (extension.endsWith(GZIP.extension)) {
            return GZIP;
        }
        if (extension.endsWith(ZIP.extension)) {
            return ZIP;
        }
        return NONE;
    }
}

package me.atilt.supplydrops.api.model.io;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.annotation.Nonnull;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/api/model/io/ConcurrentFileAccessor.class */
public class ConcurrentFileAccessor<T> implements AutoCloseable {
    private final ReentrantLock lock = new ReentrantLock();
    private final ExecutorService executorService;

    public ConcurrentFileAccessor(int threadPoolSize) {
        this.executorService = Executors.newFixedThreadPool(threadPoolSize);
    }

    public ReadOperation<T> newRead() {
        return new ReadOperation<>(this);
    }

    public WriteOperation<T> newWrite() {
        return new WriteOperation<>(this);
    }

    public BulkReadOperation<T> newBulkRead() {
        return new BulkReadOperation<>(this);
    }

    public BulkWriteOperation<T> newBulkWrite() {
        return new BulkWriteOperation<>(this);
    }

    @Nonnull
    public ExecutorService getExecutorService() {
        return this.executorService;
    }

    @Nonnull
    public Lock getLock() {
        return this.lock;
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        this.executorService.shutdown();
    }
}

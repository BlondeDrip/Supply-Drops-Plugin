package me.atilt.supplydrops.lang;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;
import javax.annotation.Nonnull;
import me.atilt.supplydrops.util.Text;
/* loaded from: supplydrops-1.0-SNAPSHOT.jar:me/atilt/supplydrops/lang/Lang.class */
public class Lang {
    @Exclude
    private final Path path;
    @Exclude
    private final Gson gson;
    public static String PREFIX = "supplydrops";
    public static String COMMAND_NO_PERMISSION = "&cYou do not have permission.";
    @Exclude
    private static final ReentrantLock LOCK = new ReentrantLock();
    @Exclude
    private static final ExecutorService THREAD_POOL = Executors.newFixedThreadPool(2);

    public Lang(@Nonnull Path path, @Nonnull GsonBuilder gsonBuilder) {
        this.path = path;
        this.gson = gsonBuilder.setPrettyPrinting().setExclusionStrategies(new ExclusionStrategy[]{new ExclusionStrategy() { // from class: me.atilt.supplydrops.lang.Lang.1
            public boolean shouldSkipField(FieldAttributes fieldAttributes) {
                return fieldAttributes.getAnnotation(Exclude.class) != null;
            }

            public boolean shouldSkipClass(Class<?> aClass) {
                return false;
            }
        }}).create();
    }

    public Lang(@Nonnull Path path) {
        this(path, new GsonBuilder());
    }

    @Nonnull
    public Path getPath() {
        return this.path;
    }

    public static String parse(String text) {
        return Text.color(text);
    }

    public void saveNow() throws IOException {
        LOCK.lock();
        try {
            Writer writer = Files.newBufferedWriter(this.path, StandardCharsets.UTF_8, new OpenOption[0]);
            this.gson.toJson(this, writer);
            if (writer != null) {
                writer.close();
            }
            LOCK.unlock();
        } catch (Throwable th) {
            LOCK.unlock();
            throw th;
        }
    }

    public void loadNow() throws IOException {
        LOCK.lock();
        try {
            Reader reader = Files.newBufferedReader(this.path, StandardCharsets.UTF_8);
            this.gson.fromJson(reader, getClass());
            if (reader != null) {
                reader.close();
            }
            LOCK.unlock();
        } catch (Throwable th) {
            LOCK.unlock();
            throw th;
        }
    }

    public CompletableFuture<Void> save() {
        return CompletableFuture.runAsync(() -> {
            LOCK.lock();
            try {
                try {
                    Writer writer = Files.newBufferedWriter(this.path, StandardCharsets.UTF_8, new OpenOption[0]);
                    try {
                        this.gson.toJson(this, writer);
                        if (writer != null) {
                            writer.close();
                        }
                        LOCK.unlock();
                    } catch (Throwable th) {
                        if (writer != null) {
                            try {
                                writer.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                        }
                        throw th;
                    }
                } catch (IOException exception) {
                    throw new RuntimeException(exception);
                }
            } catch (Throwable th3) {
                LOCK.unlock();
                throw th3;
            }
        }, THREAD_POOL);
    }

    public CompletableFuture<Void> load() {
        return CompletableFuture.runAsync(() -> {
            LOCK.lock();
            try {
                try {
                    Reader reader = Files.newBufferedReader(this.path, StandardCharsets.UTF_8);
                    try {
                        this.gson.fromJson(reader, getClass());
                        if (reader != null) {
                            reader.close();
                        }
                        LOCK.unlock();
                    } catch (Throwable th) {
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                        }
                        throw th;
                    }
                } catch (IOException exception) {
                    throw new RuntimeException(exception);
                }
            } catch (Throwable th3) {
                LOCK.unlock();
                throw th3;
            }
        }, THREAD_POOL);
    }
}
